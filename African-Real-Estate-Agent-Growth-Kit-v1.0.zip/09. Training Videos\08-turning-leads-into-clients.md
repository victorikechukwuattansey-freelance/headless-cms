# Video 8: Turning Leads into Clients

> **Length:** 30–40 minutes
> **Level:** Advanced
> **Prerequisites:** Basic understanding of real estate sales process

---

## Learning Objectives

By the end of this video, the viewer will be able to:

1. Qualify leads quickly to avoid wasting time
2. Build a follow-up system that converts at 30%+
3. Handle common objections confidently
4. Guide prospects from "just looking" to "I'll buy"
5. Close deals and create repeat clients

---

## Script Outline

### Hook (0:00–0:30)

"Most agents lose 80% of their leads because they don't follow up. Not because the leads weren't interested. Follow-up is the difference between an agent who closes 2 deals a month and one who closes 10."

### Introduction (0:30–1:30)

- The average Nigerian agent closes 1 in 20 leads
- With a system, that moves to 1 in 5 — the same effort, 4x more closings
- This video gives you the system

### Main Content

#### Part 1: Lead Qualification (1:30–8:00)

1. **The BANT framework (adapted for real estate):**
   - **B**udget — "What price range are you considering?"
   - **A**uthority — "Are you making this decision alone or with someone else?"
   - **N**eed — "What's most important to you in a property?"
   - **T**imeline — "When are you looking to move?"
2. **20-second lead sorter:**
   - Hot lead: Budget known, needs clear, timeline < 1 month → Schedule viewing
   - Warm lead: Budget range known, exploring → Send properties, follow up in 3 days
   - Cold lead: "Just looking", no budget, no timeline → Add to nurture list
3. **Questions that qualify:**
   - "Are you pre-approved for a mortgage?"
   - "Have you viewed any properties before?"
   - "What didn't you like about them?"
   - "If I find the perfect property at ₦XXM, can you move forward this month?"
4. **Exercise:** Role-play a qualification call with a "hot" and "warm" lead

#### Part 2: The Follow-Up System (8:00–16:00)

1. **The 7-touch follow-up sequence:**
   - Touch 1 (Day 1): Thank you + asked questions answered
   - Touch 2 (Day 3): Send 3 matching properties
   - Touch 3 (Day 7): "Any thoughts on those properties?"
   - Touch 4 (Day 14): Share market update / new listing in their area
   - Touch 5 (Day 21): Offer value (blog post, checklist, video)
   - Touch 6 (Day 30): "Still in the market? I have something new"
   - Touch 7 (Day 45): Final check — "Should I keep you on my list?"
2. **Where to follow up:**
   - WhatsApp (highest response rate in Africa)
   - Phone call (for hot leads only)
   - Email (for nurture — less intrusive)
   - DM (for social media leads)
3. **CRM options (even on a budget):**
   - Google Sheets (free, start here)
   - HubSpot CRM (free)
   - Pipedrive (paid, $15/mo)
   - WhatsApp + labels (minimum viable CRM)
4. **Screen recording:** Build a lead tracking spreadsheet

#### Part 3: Objection Handling (16:00–25:00)

1. **Objection: "The price is too high"**
   - Don't: "Let me talk to the owner" (lowers your value)
   - Do: "I understand. Let me show you what makes this property different from others at this price point..."
   - Do: "What price were you expecting?" → Then show value gap
2. **Objection: "I want to think about it"**
   - Don't: "OK let me know" (dead end)
   - Do: "Great. What specifically would you like to think about?"
   - Do: "Is there something you're unsure about that I can help clarify?"
3. **Objection: "I'll check with my spouse/partner"**
   - Don't: "OK" (never hear from them again)
   - Do: "Absolutely. Would it help if I sent you a video tour to share with them?"
   - Do: "When would be a good time for us all to view together?"
4. **Objection: "I found another agent with a better deal"**
   - Don't: Badmouth the other agent
   - Do: "I'd love to see the property if you don't mind sharing. I can give you an honest comparison."
   - Do: "What matters more to you — the price or the quality of service?"
5. **Objection: "I'm not ready yet"**
   - Don't: Abandon the lead
   - Do: "No problem. What would make you ready? A promotion? Saving more deposit?"
   - Do: "I'll check in every few weeks. Is that OK? And here's my guide for when you're ready."

#### Part 4: The Viewing & Closing (25:00–34:00)

1. **Before the viewing:**
   - Confirm 24 hours before
   - Send the address, time, parking instructions
   - Ask: "Is there anything specific you want to see?"
   - Get commitment: "If you like the property, are you in a position to make a decision today?"
2. **During the viewing:**
   - Let the property sell itself — don't over-talk
   - Highlight the features that match their expressed needs
   - Point out things they might miss (storage, natural light, ceiling height)
   - Stay quiet after showing the best feature — let them react
   - Ask: "Can you see yourself living here?"
3. **After the viewing (same day — crucial):**
   - Send a thank you message within 2 hours
   - Recap: "The 3-bedroom duplex we saw today at [location]. Key features you liked: [X, Y, Z]."
   - Next step: "I can check availability and get the documents ready. Shall I proceed?"
4. **The closing conversation:**
   - Summarize the value they're getting
   - Present the payment terms clearly
   - Ask for the decision: "Would you like to go ahead?"
   - Handle final hesitation → "What's holding you back?"
   - If yes → Move to documentation immediately (strike while hot)
   - If no → "What would need to change for this to work?"

#### Part 5: Post-Sale & Repeat Clients (34:00–38:00)

1. **The sale is the beginning, not the end:**
   - Send a closing gift (wine, plant, or branded items)
   - Check in at 30 days: "How are you settling in?"
   - Check in at 6 months: "Would you like a valuation update?"
   - Check in at 1 year: "Happy anniversary! Refer a friend?"
2. **Get testimonials:**
   - Ask within 2 weeks of closing (while the joy is fresh)
   - Video testimonials have 5x more impact than text
   - Ask specific questions: "What was your biggest fear before working with me?"
3. **Referral system:**
   - "I built my business on referrals. If anyone you know is buying or selling, I'd love to help them."
   - Offer a referral incentive (₦50,000–₦100,000 per closed referral)
   - Make it easy — share a digital referral card they can forward

### Key Takeaways (38:00–40:00)

1. Quality over quantity — 10 qualified leads are better than 100 tire-kickers
2. Follow-up is everything — 80% of sales require 5+ follow-ups
3. Objections are opportunities to provide clarity — welcome them
4. The viewing is not the closing — the follow-up after the viewing is
5. A closed deal should be the start of a relationship, not the end

### CTA

- "Pick your top 10 leads from the last month and start the 7-touch follow-up sequence today"
- "You now have the complete African Real Estate Agent Growth Kit — start implementing"

---

## Practical Exercise

**Assignment:** Take your last 10 leads. Qualify each using BANT. Set up a 7-touch follow-up sequence in a spreadsheet. Run the sequence for 2 weeks. Report how many moved to viewing/sale.

**Submission:** Screenshot of your lead tracker with qualification notes

---

## Lead Tracking Template

| Lead Name | Source | BANT Score | Stage | Last Contact | Next Action | Value |
|---|---|---|---|---|---|---|
| [Name] | Instagram | Hot | Viewing scheduled | 24 Mar | Confirm viewing | ₦85M |
| [Name] | Referral | Warm | Sent properties | 20 Mar | Follow up Day 3 | ₦50M |
| [Name] | WhatsApp | Cold | Nurture | 15 Mar | Send market update | ₦120M |

### BANT Scoring

| Category | Hot (3 pts) | Warm (2 pts) | Cold (1 pt) |
|---|---|---|---|
| Budget | Specific range given | Rough idea | No idea |
| Authority | Decision-maker | Joint decision | "Will check" |
| Need | Clear, urgent | Exploring | Just looking |
| Timeline | < 1 month | 1–6 months | No timeline |

**Score 10–12:** Drop everything — close this lead
**Score 6–9:** Active follow-up sequence
**Score 4–5:** Nurture with weekly content
**Score < 4:** Remove from active list

## Resource Links

- HubSpot CRM (free): https://www.hubspot.com/products/crm
- Google Sheets CRM template: https://sheets.google.com (search "real estate CRM template")
- Pipedrive: https://www.pipedrive.com
- Calendly (scheduling): https://calendly.com
- Lead qualification training: https://www.ralabs.com (free resources)
