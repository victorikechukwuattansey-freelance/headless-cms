# Day 8 — FAQ

## Post Type
Q&A / educational

## Caption Templates

**Template 1 — Top 5 questions**
Top 5 questions I get from buyers in {{City}} every week:

1️⃣ "How much deposit do I really need?"
2️⃣ "Is it better to buy land or a completed home?"
3️⃣ "How do I verify land documents?"
4️⃣ "What are the hidden costs of buying?"
5️⃣ "How long does the process take?"

I answered every single one in detail. Swipe through the carousel 👉 and drop your own question in the comments.

**Template 2 — Quick-fire answers**
Let's do a quick-fire FAQ round 🎯

Q: Can I buy property if I live abroad?
A: Yes — many agents (including me) work with diaspora buyers.

Q: How do I avoid property scams?
A: Use a registered agent, verify documents at the land registry, never pay cash to unverified sellers.

Q: Is now a good time to buy?
A: The best time to buy was yesterday. The second best time is today.

Got more questions? Drop them below 👇

**Template 3 — The one question**
People ask me this ONE question more than any other:

"Can I trust the property market in {{Country}}?"

My answer: Yes — if you work with the right people. Every market has risks, but Africa's real estate sector is growing, professionalising, and creating real wealth for smart buyers. Do your homework, find a trusted agent, and take the leap.

## CTA
- Drop your question in the comments — I'll answer every single one
- DM me "FAQ" for a printable FAQ guide
- Save this post for reference

## Suggested Hashtags
#RealEstateFAQ #BuyerQuestions #AfricanRealEstate #PropertyAdvice #LagosHomes #NairobiRealEstate #AccraProperties #FirstTimeBuyer #RealEstateQandA #AskAnAgent

## Image Recommendation
A carousel graphic — the cover slide says "5 Questions I Get Every Week" with your photo. Subsequent slides each have one question and answer in clean text. Use your brand colours.

## Story Idea
**"Ask Me Anything"** — Use the question sticker: "Ask me anything about real estate in {{City}}." Let questions roll in for 24 hours, then answer the best 3–5 in follow-up stories. Tag the users who asked.

## Reel Idea
**60-sec "5 Questions, 5 Answers"** — Direct-to-camera. Hold up one hand with all 5 fingers. Answer each question in 10 seconds. Fast-paced, friendly, authoritative. End screen: "Got a question? Drop it in the comments."
