# Day 12 — Before & After

## Post Type
Transformation story / visual impact

## Caption Templates

**Template 1 — Property flip**
The before and after that made my jaw drop 😲

This {{PropertyType}} in {{PropertyLocation}} went from {{description of before state}} to {{description of after state}}. New paint, updated fixtures, landscaping, and some TLC turned this into a showstopper.

Estimated value increase: {{X}}%.

Which side are you team? Before or after? 👇

**Template 2 — Staging transformation**
You'd be surprised what a difference staging makes. Same room. Same property. Different presentation.

Before: Empty room, no personality.
After: Warm, inviting, and ready for a new family to call it home.

This is why staging matters when you're selling. It's not about hiding flaws — it's about showing potential.

**Template 3 — Land to home**
From bare plot to beautiful home 🏗️➡️🏡

This {{PropertyLocation}} plot was untouched land {{X}} months ago. Now? A {{Bedrooms}}-bedroom dream home for {{ClientName}} and their family.

Building from scratch takes patience, but the result is worth every step. Thinking of building? Let's map out your plan.

## CTA
- DM me to see the full portfolio of before/after projects
- Save this for renovation inspiration
- Comment "Left" or "Right" for before vs after

## Suggested Hashtags
#BeforeAndAfter #PropertyTransformation #HomeRenovation #AfricanRealEstate #LagosHomes #NairobiProperties #AccraRealEstate #HomeStaging #FixAndFlip #PropertyMakeover

## Image Recommendation
Split image — left side "Before" (dated, plain, or empty), right side "After" (styled, bright, inviting). Keep the same angle for maximum impact. Bright lighting on the "after" side.

## Story Idea
**"Swipe to Transform"** — 4-slide carousel. Each slide has "Swipe up!" text. First image is the before, then swipe reveals the after with a "Wow!" reaction sticker. Last slide: "Want this for your property? DM me."

## Reel Idea
**30-sec transformation timelapse** — Before photo starts, use a "wipe" transition effect to reveal the after photo. Repeat for 3 different rooms. Fast, dramatic transitions. Trending upbeat track. Text overlay: "Before → After. Same property. New life."
