# Instagram — Template Specifications

Complete Instagram content system: **50 Carousel Templates**, **50 Story Templates**, **30 Quote Graphics**, plus Market Update and Testimonial layouts.

---

## Global Settings (All Instagram Assets)

| Setting | Value |
|---|---|
| **Carousel Post Dimensions** | 1080 × 1080 px, 1:1 |
| **Story Dimensions** | 1080 × 1920 px, 9:16 |
| **Quote Graphic Dimensions** | 1080 × 1080 px, 1:1 |
| **Colour Mode** | RGB |
| **Resolution** | 72 DPI (screen) |
| **Headings** | Playfair Display Bold 48–72 pt (carousels), 36–54 pt (stories) |
| **Body** | Lato Regular 18–24 pt (carousels), 22–30 pt (stories) |
| **Caption Data** | Lato Bold 16–20 pt |
| **Safe Zone** | 80 px inset from all edges (text), full-bleed for backgrounds/images |
| **Logo Placement** | Bottom-right corner, 80×80 px max, 30% opacity or full with white stroke |

---

## Section 1: 50 Carousel Templates (10 Types × 5 Variations Each)

### Type 1: Listing Carousel

**Purpose:** Showcase a single property across multiple slides.

**Structure (5 slides):**

| Slide | Content | Layout Description |
|---|---|---|
| 1 — Cover | Hero property image + "Just Listed / For Sale / For Rent" overlay badge + price + address | Full-bleed image. Playfair Display title centred. Terracotta badge top-left. Gold price bottom-right. |
| 2 — Exterior | Exterior wide shot + key stats (beds, baths, sq m, parking) | Split: top 60% image, bottom 40% Cream bg with 4 stat icons. Slide number bottom-left. |
| 3 — Interior | Living room or kitchen photo + 3 feature bullets | Image left 50%, text right 50% Cream bg. Olive bullet icons. |
| 4 — Lifestyle | Neighbourhood / view shot + nearby highlights | Full-bleed image. Olive overlay panel with "5 min to..." text blocks. |
| 5 — CTA | Agent headshot + "Want a viewing?" + phone, WhatsApp, email link | Charcoal bg top 40%, Cream bg bottom 60%. Agent photo circle centre. Terracotta CTA button. |

**Variations (5):**
- **A** — Residential house (hero exterior, family-focused copy)
- **B** — Luxury apartment (hero skyline view, premium features)
- **C** — Land/plot (aerial drone shot, dimensions card)
- **D** — Commercial space (building facade, investment metrics)
- **E** — Rental (interior hero, monthly price emphasis, "Available Now" badge)

---

### Type 2: Market Update Carousel

**Purpose:** Share neighbourhood or city-level market data.

**Structure (5 slides):**

| Slide | Content | Layout Description |
|---|---|---|
| 1 — Cover | Bold number headline (e.g., "+12.4%") + "Market Update" + location name | Cream bg. Massive Gold number (120 pt) as hero. Charcoal subtitle. |
| 2 — Price Trends | Line graph area (placeholder) + YoY change callout | Cream bg. Graph frame in Olive stroke. Gold data point highlight. |
| 3 — Inventory | Supply/demand stats — "45 new listings", "32 sold this month" | Two-column stat layout. Terracotta left column, Olive right column. |
| 4 — Days on Market | Bar chart or number card — average DOM trend | Charcoal bg. Gold number (e.g., "18 days"). Cream body text. |
| 5 — Forecast | "What This Means for You" + 3 key takeaways + agent CTA | Olive header. 3 numbered takeaways. Terracotta CTA "Book a Consultation". |

**Variations (5):**
- **A** — Year-over-Year Comparison (current vs previous year data)
- **B** — Quarterly Market Report (Q1/Q2/Q3/Q4 performance)
- **C** — Suburb Spotlight (single neighbourhood deep-dive)
- **D** — Price Range Breakdown (entry-level, mid-range, luxury segments)
- **E** — Rental Market Update (average rents, vacancy rates, yield trends)

---

### Type 3: Tips Carousel

**Purpose:** Educate followers — position agent as expert.

**Structure (5 slides):**

| Slide | Content | Layout Description |
|---|---|---|
| 1 — Cover | Title e.g., "5 Tips for First-Time Buyers" + relevant icon | Cream bg. Playfair Display title centred. Olive decorative border. |
| 2 — Tip 1 | Number + heading + 1 sentence explanation | Large Gold number (01). Charcoal heading. Lato body. Bottom accent line in Terracotta. |
| 3 — Tip 2 | Same format as Tip 1 | Olive number this time. Consistent layout. |
| 4 — Tip 3 | Same format | Terracotta number. |
| 5 — CTA | "Want more tips?" + "Follow for daily real estate tips" + agent branding | Charcoal bg. Cream text. Agent logo and handle. |

**Variations (5):**
- **A** — First-Time Buyer Tips (5 tips)
- **B** — Seller Tips (staging, pricing, timing — 5 tips)
- **C** — Investor Tips (ROI, location picking, negotiation — 5 tips)
- **D** — Renovation Tips (budget-friendly upgrades that add value — 5 tips)
- **E** — Relocation Tips (moving checklist, neighbourhood research — 5 tips)

---

### Type 4: Agent Intro Carousel

**Purpose:** Personal branding — tell the agent's story.

**Structure (5 slides):**

| Slide | Content | Layout Description |
|---|---|---|
| 1 — Cover | Agent headshot (large, centred) + "Meet [Name]" + tagline | Cream bg. Circular headshot crop with Gold border ring. |
| 2 — Background | "My Story" — 3–4 sentence bio + key milestone year | Split: left 40% agent secondary photo, right 60% text on Cream. |
| 3 — Numbers | "By the Numbers" — 3 stat cards (e.g., 150+ homes sold, 98% satisfaction, 12 years exp) | 3 horizontal cards in Charcoal, Olive, Gold. White numbers. |
| 4 — Philosophy | "My Approach" — 3 core values (e.g., Integrity, Transparency, Results) | Cream bg. Terracotta icons. Quote-style text in Playfair Italic. |
| 5 — CTA | "Let's Work Together" + phone, email, WhatsApp, Instagram handle | Charcoal bg. Contact icons in circle buttons. Terracotta "DM Me" CTA. |

**Variations (5):**
- **A** — Solo Agent (personal brand focus)
- **B** — Team Introduction (team photo, member roles)
- **C** — Broker/Owner (agency philosophy, team size, track record)
- **D** — New Agent (fresh perspective, training, local knowledge)
- **E** — Luxury Specialist (high-end portfolio shots, VIP service messaging)

---

### Type 5: Testimonials Carousel

**Purpose:** Social proof — happy client stories.

**Structure (5 slides):**

| Slide | Content | Layout Description |
|---|---|---|
| 1 — Cover | "What Our Clients Say" + Gold star cluster + decorative quote mark | Cream bg. Large decorative quote mark (Gold, 100 pt, 20% opacity). |
| 2 — Testimonial 1 | Client photo (small circle) + quote + name + location | Cream bg. Quote in Playfair Display Italic. Olive accent bar. |
| 3 — Testimonial 2 | Same layout as slide 2, different client | Same layout. Terracotta accent bar this time. |
| 4 — Testimonial 3 | Video testimonial placeholder OR text + star rating | Gold accent bar. Star rating (5 Gold stars). |
| 5 — CTA | "See what we can do for you" + "Book a Consultation" button | Charcoal bg. Cream text. Terracotta button. |

**Variations (5):**
- **A** — Buyer Testimonials (first-time buyers, families)
- **B** — Seller Testimonials (fast sale, above-asking price stories)
- **C** — Investor Testimonials (ROI-focused, portfolio growth)
- **D** — Landlord/Rental Client Testimonials (property management praise)
- **E** — Video Testimonial Frames (placeholder for embedded video with play button overlay)

---

### Type 6: Neighbourhood Guide Carousel

**Purpose:** Showcase local area expertise.

**Structure (5 slides):**

| Slide | Content | Layout Description |
|---|---|---|
| 1 — Cover | Neighbourhood name + hero skyline/street photo + "Your Guide to" overlay | Full-bleed photo. Cream text overlay. Playfair Display. |
| 2 — Overview | Population, average price, vibe description | Charcoal header bar. 3 data cards (Cream, Gold, Olive backgrounds). |
| 3 — Hotspots | 4 amenity icons — schools, shopping, transport, healthcare | Icon grid 2×2. Terracotta icons. Olive labels. |
| 4 — Lifestyle | "Why People Love It Here" — 3 bullet points | Full-bleed lifestyle photo. Cream panel overlay with Charcoal text. |
| 5 — CTA | "Want to move to [Neighbourhood]?" + "I know every street" + agent contact | Charcoal bg. Agent photo circle. Terracotta CTA. |

**Variations (5):**
- **A** — Family-Friendly Neighbourhoods (schools, parks, safety)
- **B** — Up-and-Coming Areas (new developments, price growth, potential)
- **C** — Luxury Enclaves (high-end amenities, privacy, exclusivity)
- **D** — Student / Young Professional Hubs (nightlife, co-working, transport)
- **E** — Suburb vs City Comparison (pros/cons, price difference, commute times)

---

### Type 7: Before & After Carousel

**Purpose:** Showcase renovation or staging transformations.

**Structure (5 slides):**

| Slide | Content | Layout Description |
|---|---|---|
| 1 — Cover | Split image: left "Before" (desaturated), right "After" (full colour) + title | Diagonal split or side-by-side. Gold "Transformation" title. |
| 2 — Before | "Before" full image + caption (e.g., "Original condition") | Full image. Charcoal text overlay bottom. "Before" tag in Olive. |
| 3 — After | "After" full image + caption (e.g., "After full renovation") | Full image. Gold "After" tag top-right. |
| 4 — Detail | Side-by-side close-up (kitchen counter / bathroom / flooring) | Split screen with slider line in centre. Olive accent. |
| 5 — Results | Value increase stat (e.g., "+40% in value") + "Thinking of renovating?" CTA | Massive Gold number. Charcoal bg. Terracotta CTA. |

**Variations (5):**
- **A** — Full Home Renovation (exterior + interior transformation)
- **B** — Kitchen Remodel (cabinet, countertop, appliance upgrade)
- **C** — Bathroom Makeover (fixtures, tiles, lighting)
- **D** — Home Staging (unfurnished vs staged, sold price comparison)
- **E** — Office/Commercial Conversion (warehouse to office, retail fit-out)

---

### Type 8: FAQ Carousel

**Purpose:** Answer common questions proactively.

**Structure (5 slides):**

| Slide | Content | Layout Description |
|---|---|---|
| 1 — Cover | "FAQ: [Topic]" + decorative question mark icon | Cream bg. Large Olive "?" as design element. |
| 2 — Q1 | "Q: [Question]?" + "A: [Answer]" in 2–3 sentences | Charcoal "Q:" prefix. Terracotta "A:" prefix. Playfair Q, Lato A. |
| 3 — Q2 | Same format as slide 2 | Different colour accent (Olive Q prefix). |
| 4 — Q3 | Same format | Gold Q prefix. |
| 5 — CTA | "Have more questions?" + "DM me — I reply in minutes" + agent handle | Charcoal bg. Cream text. Animated arrow icon (static representation). |

**Variations (5):**
- **A** — Buying FAQ (financing, offers, closing process)
- **B** — Selling FAQ (commissions, staging, timing the market)
- **C** — Renting FAQ (deposits, leases, tenant rights)
- **D** — Investing FAQ (ROI calculations, property management, taxes)
- **E** — Legal FAQ (title deeds, land boards, transfer process — Africa-specific)

---

### Type 9: Investment Tips Carousel

**Purpose:** Attract investor clients with data-driven insights.

**Structure (5 slides):**

| Slide | Content | Layout Description |
|---|---|---|
| 1 — Cover | "Real Estate Investing in [Year]" + upward graph arrow icon | Charcoal bg. Gold arrow. Cream title. |
| 2 — Market Data | Current average yield %, price growth %, rental demand index | 3 large number cards. Terracotta, Olive, Gold backgrounds. |
| 3 — Top Pick | "Best Investment Opportunity Right Now" — property type + location | Split: image left, text right. Olive "Hot Pick" tag. |
| 4 — Strategy | "3 Strategies for [Year]" — buy-and-hold, flip, lease option | Numbered list with icons. Cream bg. |
| 5 — CTA | "Build your portfolio" + "Let's talk investments" + agent booking link | Charcoal bg. Gold text. Terracotta button. |

**Variations (5):**
- **A** — Buy-to-Let Strategy (rental yield focus, property selection tips)
- **B** — Fix-and-Flip (profit calculations, timeline, contractor vetting)
- **C** — Land Banking (appreciation, zoning changes, long-term hold)
- **D** — Commercial REITs vs Direct Ownership (pros/cons for different budgets)
- **E** — Short-Term Rentals (Airbnb arbitrage, tourism markets, regulations)

---

### Type 10: Behind-the-Scenes Carousel

**Purpose:** Humanise the agent — show the work behind the deals.

**Structure (5 slides):**

| Slide | Content | Layout Description |
|---|---|---|
| 1 — Cover | Candid agent photo (at office, with team, at a listing) + "Behind the Scenes" | Full-bleed photo. Cream text overlay bottom-left. |
| 2 — Day in the Life | "A Day in the Life" — 4 timeline entries (7 AM prep, 10 AM viewing, 2 PM paperwork, 5 PM client meeting) | Timeline-style layout. Olive vertical line. Gold time stamps. |
| 3 — On the Job | Agent at a property viewing or inspection | Full-bleed photo. Charcoal panel overlay with caption. |
| 4 — The Team | Team photo + quick intros (name + role) | Grid of circular headshots. Cream bg. Olive name labels. |
| 5 — CTA | "This is what dedication looks like" + "Ready to work with us?" + contact | Charcoal bg. Agent photo. Terracotta CTA. |

**Variations (5):**
- **A** — Day in the Life (showing prep, viewings, client meetings)
- **B** — Office Culture (team dynamics, celebrations, work environment)
- **C** — Listing Preparation (staging, photography, sign installation)
- **D** — Client Meeting (consultation process, neighbourhood tour)
- **E** — Event / Open House Setup (decorating, signage, refreshments prep)

---

## Section 2: 50 Story Templates (10 Types × 5 Variations Each)

### Story Design Principles

- Vertical 9:16 canvas (1080 × 1920 px)
- Text in top 60% safe zone (avoid bottom 30% where UI overlays appear)
- Bold, single-message-per-slide
- Swipe-up / link sticker zone at very bottom
- Agent handle watermark at top or bottom

### Type 1: Property Showcase Story

**Layout:** Full-bleed property image + slim text overlay. Price Gold strip at bottom. "Swipe up for details" callout.

**Variations (5):**
- **A** — Exterior Hero (house exterior, "Coming Soon" badge)
- **B** — Interior Highlight (best room shot, feature callout)
- **C** — Detail Shot (kitchen counter, bathroom fixture, view)
- **D** — Aerial View (drone shot, property boundary overlay)
- **E** — Location Highlight (street view, nearby landmark)

---

### Type 2: Quote Story

**Layout:** Cream bg. Large decorative quote mark (Gold, top-left). Quote in Playfair Display Italic 28 pt. Attribution in Lato 18 pt. Agent logo bottom-right.

**Variations (5):**
- **A** — Real Estate Wisdom (e.g., "The best investment on earth is earth.")
- **B** — Client Praise (pull quote from recent testimonial)
- **C** — Personal Philosophy (agent's own motto)
- **D** — Market Truth (e.g., "Rent pays your landlord's mortgage. Buy pays your own.")
- **E** — African Proverb (culturally resonant proverb about home or community)

---

### Type 3: Poll Story

**Layout:** Question at top (Playfair, Charcoal). Two interactive-style buttons (Terracotta + Olive) with answer options. "Vote now" callout.

**Variations (5):**
- **A** — "Which style do you prefer?" (Modern vs Classic with example photos)
- **B** — "What's your budget range?" (option tiers for market research)
- **C** — "Rent or Buy?" (opinion poll with follow-up link)
- **D** — "What matters most?" (location, price, size — multiple choice)
- **E** — "Best investment?" (real estate vs stocks vs crypto)

---

### Type 4: Q&A Story

**Layout:** "Ask Me Anything" header (Gold). Question box placeholder (Cream, Charcoal border). Agent photo with "Reply with your questions" callout.

**Variations (5):**
- **A** — "Ask a Realtor" (open-ended Q&A prompt)
- **B** — "Home Buying 101" (collect buyer questions)
- **C** — "Market Questions" (current market curiosity)
- **D** — "Selling Tips" (seller FAQ prompt)
- **E** — "Land Questions" (plot purchasing, title deed queries)

---

### Type 5: Countdown to Open House

**Layout:** Large number (Gold, 80 pt) as focal point. "Days until Open House" subtitle. Date/time below. "Set a reminder" callout. Property photo as blurred background.

**Variations (5):**
- **A** — 7-Day Countdown (starting 7 days before event)
- **B** — 3-Day Countdown (urgency build)
- **C** — 1 Day to Go (final reminder)
- **D** — "Today's the Day!" (event-day announcement)
- **E** — "Last Chance!" (final hours reminder)

---

### Type 6: Featured Listing Story

**Layout:** Full-bleed property photo. Gold ribbon "Featured Listing" overlay. Price + key stat strip at bottom. "Swipe up for full details" CTA.

**Variations (5):**
- **A** — Just Listed (first announcement, "New on the Market")
- **B** — Price Drop (original price strikethrough, new price emphasis)
- **C** — Back on Market (second chance messaging)
- **D** — Under Offer (pending sale, "Almost gone!")
- **E** — Property of the Week (weekly recurring highlight)

---

### Type 7: Client Spotlight Story

**Layout:** Client photo (left, circular crop) + quote text (right, Playfair Italic) + "Thank you [Name]!" Terracotta heart icon. Gold star rating strip.

**Variations (5):**
- **A** — Happy Buyer (keys handed over photo, emotional quote)
- **B** — Happy Seller (sold sign photo, profit/price achievement)
- **C** — Repeat Client (multiple transactions, loyalty story)
- **D** — Referral Thank You ("Thanks for referring [Friend Name]")
- **E** — Landlord Praise (professional management, easy process)

---

### Type 8: Market News Story

**Layout:** News-style header (Olive). Bold headline (Playfair). Key number (Gold, massive). Source attribution (Lato Small). "Swipe up for full report."

**Variations (5):**
- **A** — Interest Rate Update (central bank news impact)
- **B** — Housing Supply Data (new developments, inventory changes)
- **C** — Price Index Movement (median price change)
- **D** — Economic Indicator (GDP, employment, construction data)
- **E** — Policy Change (tax, zoning, foreign ownership rules)

---

### Type 9: Tip of the Day Story

**Layout:** Large "Tip of the Day" header (Gold stroke underline). Number (01–05). Tip text in Playfair. Icon illustration. Agent tag bottom.

**Variations (5):**
- **A** — Buying Tip (e.g., "Get pre-approved before you start viewing")
- **B** — Selling Tip (e.g., "Declutter before photos — it pays off")
- **C** — Staging Tip (e.g., "Neutral colours sell faster")
- **D** — Negotiation Tip (e.g., "Always ask for the seller's timeline")
- **E** — Maintenance Tip (e.g., "Fix that leaky faucet before listing")

---

### Type 10: Behind the Scenes Story

**Layout:** Candid photo (full bleed). Caption overlay (bottom 40%, Charcoal gradient bg). Agent handle top-left. "Real work, real results" tagline.

**Variations (5):**
- **A** — At a Listing (agent with "For Sale" sign, measuring, taking notes)
- **B** — At the Office (desk setup, working on contracts, team huddle)
- **C** — At an Event (open house, networking, client appreciation)
- **D** — In the Car (drive to viewings, neighbourhood tour)
- **E** — Celebrating (closing celebration, client gift delivery)

---

## Section 3: 30 Quote Graphics

### Design Template (Universal)

**Dimensions:** 1080 × 1080 px

**Layout:**
```
┌──────────────────────────────────────┐
│                                      │
│   ┌──────────────────────────────┐   │
│   │                              │   │
│   │   ❝                          │   │  Large quote mark (Gold, 80 pt)
│   │                              │   │
│   │   [Quote text]               │   │  Playfair Display Italic 28–36 pt
│   │                              │   │  Charcoal or Cream (depending on bg)
│   │                              │   │
│   │   — [Author Name]           │   │  Lato Regular 16 pt
│   │                              │   │
│   └──────────────────────────────┘   │
│                                      │
│   [Agent Logo]           [Handle]    │  Bottom strip
└──────────────────────────────────────┘
```

### Quote Categories (30 Total)

**Category A: Real Estate Wisdom (10 quotes)**
| # | Background | Author | Text Colour | Decorative Element |
|---|---|---|---|---|
| 01 | Cream | Unknown | Charcoal | Olive leaf divider |
| 02 | Charcoal | Robert Kiyosaki | Cream | Gold diamond accent |
| 03 | Terracotta | Andrew Carnegie | Cream | Gold star |
| 04 | Cream | Warren Buffett | Charcoal | Terracotta line |
| 05 | Charcoal | Unknown | Gold | Olive circle frame |
| 06 | Olive | Unknown | Cream | Gold thin border |
| 07 | Cream | Barbara Corcoran | Charcoal | Terracotta arrow |
| 08 | Charcoal | John D. Rockefeller | Cream | Gold coin icon |
| 09 | Gold | Unknown | Charcoal | Cream decorative border |
| 10 | Cream | Brandon Turner | Charcoal | Olive house icon |

**Category B: Agent Philosophy (10 quotes)**
| # | Background | Author | Text Colour | Decorative Element |
|---|---|---|---|---|
| 11 | Charcoal | Agent's name | Cream | Gold signature line |
| 12 | Cream | Agent's name | Charcoal | Terracotta logo mark |
| 13 | Olive | Agent's name | Cream | Gold star cluster |
| 14 | Terracotta | Agent's name | Cream | Olive leaf motif |
| 15 | Cream | Agent's name | Charcoal | Charcoal quotation mark |
| 16 | Gold | Agent's name | Charcoal | Cream thin border |
| 17 | Charcoal | Agent's name | Gold | Cream circle |
| 18 | Cream | Agent's name | Charcoal | Terracotta arrow accent |
| 19 | Olive | Agent's name | Cream | Gold diamond |
| 20 | Cream | Agent's name | Terracotta | Charcoal decorative line |

**Category C: Market Wisdom (10 quotes)**
| # | Background | Author | Text Colour | Decorative Element |
|---|---|---|---|---|
| 21 | Charcoal | Market analyst name | Gold | Cream bar chart icon |
| 22 | Cream | Local expert | Charcoal | Olive trend arrow |
| 23 | Gold | Industry report | Charcoal | Cream pie chart icon |
| 24 | Olive | Financial advisor | Cream | Gold upward graph |
| 25 | Cream | Economist | Charcoal | Terracotta building icon |
| 26 | Charcoal | Investment firm | Gold | Olive coin stack icon |
| 27 | Terracotta | Property developer | Cream | Gold key icon |
| 28 | Cream | Bank report | Charcoal | Olive house price icon |
| 29 | Charcoal | Research firm | Cream | Gold shield icon |
| 30 | Olive | Local authority | Cream | Gold line chart |

---

## Section 4: Market Update Templates

### Monthly Market Report (Single Graphic)

**Dimensions:** 1080 × 1080 px

**Layout:**
```
┌──────────────────────────────────────┐
│   ┌──────────────────────────────┐   │
│   │  [City] Market Report        │   │  Playfair Bold, Charcoal
│   │  [Month] [Year]              │   │  Lato, Olive
│   └──────────────────────────────┘   │
│                                      │
│   ┌─────────────┐ ┌─────────────┐   │
│   │ Median Price│ │ Avg DOM     │   │  4 stat cards (2×2 grid)
│   │ KES 12.5M   │ │ 22 days     │   │  Gold numbers, Cream text bg
│   ├─────────────┤ ├─────────────┤   │
│   │ New Listings│ │ Sold        │   │
│   │ 142         │ │ 98          │   │
│   └─────────────┘ └─────────────┘   │
│                                      │
│   ┌──────────────────────────────┐   │
│   │  [Trend line graph area]     │   │  Price trend, 6-month view
│   │                              │   │  Gold line, Charcoal grid
│   └──────────────────────────────┘   │
│                                      │
│   "Data source: [Institution]"       │  Lato Small, Olive
│   [Agent Logo]                       │
└──────────────────────────────────────┘
```

### Year-over-Year Comparison Template

**Dimensions:** 1080 × 1080 px

**Layout:** Left column "[Year-1] (Olive)", right column "[Year] (Gold)". 4 comparison rows: Median Price, Average DOM, Total Sales, Price per Sq M. Downward/green and upward/red arrows between columns. "Year-over-Year" header.

**Variations:**
- 2-year comparison side-by-side
- 5-year trend with mini line graph
- Pre-COVID vs Post-COVID comparison
- Quarter-over-quarter with percentage change callouts
- Suburb performance ranking table

---

## Section 5: Testimonial Graphics

### Client Quote Layout

**Dimensions:** 1080 × 1080 px

**Layout:**
```
┌──────────────────────────────────────┐
│   ┌──────────────────────────────┐   │
│   │  ❝ [Client Quote] ❝         │   │  Playfair Display Italic 26 pt
│   │                              │   │  Cream bg, Charcoal text
│   │  — [Client Name]            │   │  Lato Regular 16 pt
│   └──────────────────────────────┘   │
│                                      │
│   ⭐⭐⭐⭐⭐                          │  5 Gold stars, centred
│                                      │
│   [Property Type]  |  [Location]     │  Lato Small, Olive
│                                      │
│   [Agent logo]        [optional      │
│                        client photo] │
└──────────────────────────────────────┘
```

### Star Rating Display

**Dimensions:** 1080 × 1080 px

**Layout:** Massive star cluster background (Gold, 30% opacity). "RATED" in Playfair (Charcoal). "4.9 / 5.0" in Gold (72 pt). "Based on [number] Google Reviews" in Lato. Agent logo.

### Before/After Results

**Dimensions:** 1080 × 1080 px

**Layout:** Diagonal split. Left "BEFORE" (desaturated photo + stats). Right "AFTER" (full colour photo + improved stats). "SOLD in 14 days at 98% of asking price" achievement banner across bottom (Gold bg).

---

## Posting Schedule Guidelines

| Day | Content Type | Best Time (CAT) |
|---|---|---|
| Monday | Market Update / Data | 7:00 AM, 12:00 PM |
| Tuesday | Listing Showcase | 12:00 PM, 6:00 PM |
| Wednesday | Tips / Educational | 9:00 AM, 5:00 PM |
| Thursday | Client Testimonial | 10:00 AM, 4:00 PM |
| Friday | Open House / Event | 8:00 AM, 1:00 PM |
| Saturday | Neighbourhood Guide | 10:00 AM, 2:00 PM |
| Sunday | Quote / Inspirational | 9:00 AM, 6:00 PM |

---

## Hashtag Strategy

Each template should have a designated hashtag placeholder area containing:

- **10 High-volume tags** (e.g., #RealEstate #HomeBuying #Property)
- **10 Location tags** (e.g., #NairobiRealEstate #LagosProperty #SandtonHomes)
- **5 Niche tags** (e.g., #FirstTimeBuyerKE #LuxuryLagos #RentalJohannesburg)
- **Agent brand tag** (e.g., #[AgentName]Homes)

Hashtag blocks should be placed in the caption skeleton (not on the graphic) to maintain clean design.
