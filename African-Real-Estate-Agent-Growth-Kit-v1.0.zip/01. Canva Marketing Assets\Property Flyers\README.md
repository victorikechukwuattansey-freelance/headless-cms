# Property Flyers — Template Specifications

8 distinct flyer types designed for the African real estate market. Each is optimised for both US Letter (2550 × 3300 px) and A4 (2480 × 3508 px) print, with identical layout structure adapted to each aspect ratio.

---

## Global Settings (All Flyers)

| Setting | Value |
|---|---|
| **Dimensions** | US Letter 2550 × 3300 px / A4 2480 × 3508 px, 300 DPI |
| **Bleed** | 0.125 in (3.175 mm) all sides |
| **Colour Mode** | CMYK |
| **Primary Palette** | Charcoal `#2D2D2D`, Cream `#F5F0E8`, Terracotta `#C26A4A`, Olive `#7B8D5D`, Gold `#C9A84C` |
| **Heading Font** | Playfair Display Bold 36–48 pt |
| **Subheading Font** | Playfair Display Italic 20–28 pt |
| **Body Font** | Lato Regular 11–14 pt |
| **Accent / Data Font** | Lato Bold 14–18 pt |
| **Agent Footer** | Lato Regular 10 pt — name, phone, email, logo, QR code |

---

## 1. Luxury Home Flyer

**Purpose:** Premium residential properties in upscale neighbourhoods (e.g., Ikoyi, Runda, Sandton).

### Layout (Front)

```
┌──────────────────────────────────────┐
│                                      │
│   ┌──────────────────────────────┐   │  HERO IMAGE AREA
│   │                              │   │  (full-width, top 55%)
│   │                              │   │
│   │      [Full-bleed hero        │   │
│   │       property photo]        │   │
│   │                              │   │
│   │   ┌────────────────────┐    │   │
│   │   │ LUXURY LIVING      │    │   │  Overlay badge 
│   │   │   IN [CITY]        │    │   │  (Gold bg, white text)
│   │   └────────────────────┘    │   │
│   └──────────────────────────────┘   │
│                                      │
│   ┌────────────────────────────┐    │
│   │  [Price]                   │    │  Price strip (Charcoal bg, Gold text)
│   │  [Location / Suburb]       │    │
│   └────────────────────────────┘    │
│                                      │
│   ┌────┐ ┌────┐ ┌────┐ ┌────┐    │
│   │Beds │ │Baths│ │Sq.m│ │Gar │    │  Key stats row
│   └────┘ └────┘ └────┘ └────┘    │
│                                      │
│   [Agent Name]   [Logo]             │  Agent footer
│   [Phone] [Email]                    │
└──────────────────────────────────────┘
```

### Sections / Placeholders

| Section | Description | Colours |
|---|---|---|
| Hero Image | Full-bleed property photo (exterior, golden hour preferred) | — |
| Badge Overlay | "Luxury Living" ribbon badge, rotated -3°, top-left of image | Gold bg, Cream text |
| Property Title | Address or development name | Playfair Display Bold 42 pt, Cream over image |
| Price Strip | Bold price with currency (e.g., KES 45M) | Charcoal bg, Gold text |
| Location | Suburb / city line below price | Lato Regular 16 pt, Cream |
| Key Stats | 4 icon + number blocks: Bedrooms, Bathrooms, Floor Area (sq m), Parking | Olive icons, Charcoal numbers |
| Feature Bullets | 3–5 premium features (e.g., infinity pool, smart home, staff quarters) | Terracotta bullets, Charcoal text |
| Agent Footer | Agent headshot (circular crop, 80×80 px), name, phone, email, brokerage logo | Cream bg, split bottom strip |

### Back Layout

```
┌──────────────────────────────────────┐
│   ┌─────────────┐                    │
│   │ Agent Photo │  Agent Bio         │  Left: agent headshot
│   │  (circle)   │  (3–4 sentences)   │  Right: bio + tagline
│   └─────────────┘                    │
│                                      │
│   ───  FEATURES  ─────────────────   │  Divider line (Gold)
│                                      │
│   • Feature 1  • Feature 3  • Feat 5│  2-column feature grid
│   • Feature 2  • Feature 4  • Feat 6│
│                                      │
│   ───  FLOOR PLAN  ────────────────  │
│                                      │
│   [Floor plan image placeholder]     │  60% width, centred
│                                      │
│   ───  CONTACT  ───────────────────  │
│                                      │
│   [QR Code]   Name                   │
│                Phone                 │
│                Email                 │
│                Web                   │
└──────────────────────────────────────┘
```

### Colour Distribution
- Background: Cream (60%), Charcoal (20%, mostly footer/price), Terracotta + Gold (10% accents), Olive (10% icons)

---

## 2. Apartment Flyer

**Purpose:** Modern urban apartments targeting young professionals, investors, and first-time buyers.

### Layout (Front)

```
┌──────────────────────────────────────┐
│   ┌──────────────────────────────┐   │
│   │                              │   │
│   │   [Hero apartment image]     │   │  Top 50%, full bleed
│   │                              │   │
│   │        ┌─────────────┐       │   │
│   │        │  NEW LISTING │       │   │  Badge top-right (Terracotta)
│   │        └─────────────┘       │   │
│   └──────────────────────────────┘   │
│                                      │
│   [Apartment Name / Address]         │  Playfair Display Bold 36 pt
│   [Price]                            │  Gold, 24 pt
│                                      │
│   ┌────┐ ┌────┐ ┌────┐ ┌────┐    │
│   │Beds │ │Baths│ │Sq.m│ │Floor│    │  Stats row (icon + number)
│   └────┘ └────┘ └────┘ └────┘    │
│                                      │
│   ───  AMENITIES  ────────────────  │  Gold divider
│                                      │
│   🏊 Pool    🚗 Parking    🔒 24hr Sec│
│   🏋️ Gym     🌿 Garden     📶 WiFi   │  2×3 amenity grid (icons + label)
│   🧺 Laundry 🚪 Smart Locks 🎥 CCTV  │
│                                      │
│   [Agent Name]   [Logo]             │
│   [Phone] [Email] [WhatsApp]        │
└──────────────────────────────────────┘
```

### Sections / Placeholders

| Section | Description | Colours |
|---|---|---|
| Hero Image | Apartment building exterior or modern interior | — |
| "New Listing" Badge | Rectangular badge, top-right | Terracotta bg, Cream text |
| Apartment Name | Development or building name | Charcoal |
| Price | Monthly/annual rent or sale price | Gold |
| Key Stats | Bedrooms, Bathrooms, Sq m, Floor level | Olive icons, Charcoal text |
| Amenities Grid | 6 amenity icons with labels, 2×3 or 3×2 layout | Olive icons, Charcoal labels |
| Description | 2–3 sentence highlights (finishes, views, location) | Lato Regular 12 pt |
| Contact Strip | Agent name, phone, email, WhatsApp number | Charcoal bg bar at bottom |
| QR Code | Direct link to listing page | Bottom-right corner |

### Colour Distribution
- Background: Cream, Accent: Terracotta for badges, Olive for icons, Gold for price emphasis

---

## 3. Land Flyer

**Purpose:** Vacant land / plot sales — residential, commercial, or agricultural plots.

### Layout (Front)

```
┌──────────────────────────────────────┐
│   ┌──────────────────────────────┐   │
│   │                              │   │
│   │   [Aerial / landscape photo] │   │  Hero image (drone shot preferred)
│   │                              │   │
│   │   ┌─────────────────┐       │   │
│   │   │  PRIME LAND     │       │   │  Gold badge
│   │   │  FOR SALE       │       │   │
│   │   └─────────────────┘       │   │
│   └──────────────────────────────┘   │
│                                      │
│   [Plot Location / Area]             │
│   [Price per Sq M / Total Price]     │
│                                      │
│   ┌──────────────────────────┐      │
│   │  PLOT DIMENSIONS         │      │  Info card (Cream bg, Charcoal border)
│   │  50m × 100m  |  5,000 m² │      │
│   │  Title: Freehold         │      │
│   │  Zoning: Residential     │      │
│   └──────────────────────────┘      │
│                                      │
│   ───  LOCATION HIGHLIGHTS  ──────  │
│   • 5 min to main road              │  Bullet list with Olive checkmarks
│   • 15 min to city centre           │
│   • Water & electricity available   │
│   • Secure neighbourhood            │
│                                      │
│   [Agent footer]                     │
└──────────────────────────────────────┘
```

### Sections / Placeholders

| Section | Description | Colours |
|---|---|---|
| Hero Image | Drone aerial or landscape shot of the land | — |
| "Prime Land" Badge | Gold badge, top-left | Gold bg, Charcoal text |
| Plot Name | Location name (e.g., "Tatu City — Phase 2") | Charcoal, Playfair Display |
| Price | Per sq m and total price | Gold |
| Dimensions Card | Area card with: length × width, total sq m, title deed type, zoning classification | Cream card, Charcoal text |
| Location Highlights | 4 key location advantages with checkmark bullets | Olive checkmarks |
| Zoning Info | Commercial / Residential / Agricultural with icon | Terracotta accent |
| Map / Direction | Small map snippet or "Get Directions" QR code | — |

### Colour Distribution
- Background: Cream, Accent: Olive (land/nature feel), Gold for price, Terracotta for zoning

---

## 4. Commercial Flyer

**Purpose:** Retail spaces, offices, warehouses, and mixed-use commercial properties.

### Layout (Front)

```
┌──────────────────────────────────────┐
│   ┌──────────────────────────────┐   │
│   │                              │   │
│   │   [Commercial property       │   │  Hero image (building exterior
│   │    exterior image]           │   │  or street view)
│   │                              │   │
│   │   ┌──────────────────────┐   │   │
│   │   │  COMMERCIAL SPACE    │   │   │  Terracotta badge
│   │   └──────────────────────┘   │   │
│   └──────────────────────────────┘   │
│                                      │
│   [Property Name / Address]          │
│   [Price / Lease Rate]               │
│                                      │
│   ┌──────────────────────────────┐  │
│   │  PROPERTY FEATURES           │  │  Section header (Gold underline)
│   │  • Total Area: 2,500 sq m   │  │
│   │  • Frontage: 40 m           │  │
│   │  • Parking: 50 bays         │  │
│   │  • Floors: 4                │  │
│   │  • Lifts: 2                 │  │
│   └──────────────────────────────┘  │
│                                      │
│   ───  INVESTMENT HIGHLIGHTS  ────  │  Olive section
│   • 8% projected annual return      │
│   • Triple-net lease available      │
│   • High foot traffic zone          │
│   • Grade-A certification           │
│                                      │
│   [Agent footer with QR code]       │
└──────────────────────────────────────┘
```

### Sections / Placeholders

| Section | Description | Colours |
|---|---|---|
| Hero Image | Commercial building exterior or street-level view | — |
| "Commercial Space" Badge | Rectangular badge | Terracotta bg, Cream text |
| Property Name | Building or development name | Charcoal |
| Price / Lease | Sale price OR annual lease rate (per sq m) | Gold |
| Features List | 5–6 property specs with icons (area, frontage, parking, floors, lifts, loading) | Olive icons, Charcoal text |
| Investment Highlights | 4 bullet points with upward-trend icons | Olive section header |
| Zoning / Permitted Use | Retail / Office / Warehouse / Mixed-Use tag | Terracotta tag |
| Contact Strip | Agent details, brokerage, QR code for virtual tour | Charcoal bg |

### Colour Distribution
- Background: Cream, Strong: Terracotta + Gold (investment emphasis), Olive for features

---

## 5. Rental Flyer

**Purpose:** Residential rental listings — apartments, houses, townhouses for lease.

### Layout (Front)

```
┌──────────────────────────────────────┐
│   ┌──────────────────────────────┐   │
│   │                              │   │
│   │   [Property interior/        │   │  Hero image
│   │    exterior photo]           │   │
│   │                              │   │
│   │   ┌─────────┐ ┌─────────┐   │   │
│   │   │ FOR     │ │ [Price] │   │   │  Badge left, Price right
│   │   │ RENT    │ │ KES 45K │   │   │  (both overlaid on image)
│   │   └─────────┘ └─────────┘   │   │
│   └──────────────────────────────┘   │
│                                      │
│   [Address / Estate Name]            │
│                                      │
│   ┌────┐ ┌────┐ ┌────┐ ┌────┐    │
│   │3   │ │2   │ │120 │ │Furn│    │  Beds, Baths, Sq m, Furnished
│   │Beds│ │Baths│ │Sq m│ │ished│    │
│   └────┘ └────┘ └────┘ └────┘    │
│                                      │
│   ───  AMENITIES  ────────────────  │
│   • Water included                  │  Bullet list
│   • Security estate                 │
│   • Parking for 2 cars              │
│   • Nearby shopping                 │
│                                      │
│   [Agent Name]   [Call] [WhatsApp]  │  Contact buttons
│   [Phone Number]                     │
└──────────────────────────────────────┘
```

### Sections / Placeholders

| Section | Description | Colours |
|---|---|---|
| Hero Image | Interior (living room or kitchen) or exterior | — |
| "For Rent" Badge | Left side overlay | Terracotta bg |
| Price | Right side overlay, bold | Gold bg, Charcoal text |
| Address | Property address or estate name | Charcoal |
| Key Stats | 4 stat blocks: beds, baths, area, furnished/unfurnished | Olive icons |
| Amenities | 4–6 bullet points with small icons | Charcoal text, Olive bullets |
| Rental Terms | Lease duration, deposit required, available from | Lato Regular 11 pt |
| Contact Buttons | "[Call]" and "[WhatsApp]" styled buttons | Terracotta buttons, Cream text |
| Agent Footer | Name, phone, email, brokerage logo | Cream bg strip |

### Colour Distribution
- Background: Cream, Accent: Terracotta (CTA buttons, For Rent badge), Gold (price)

---

## 6. Just Listed Flyer

**Purpose:** "New on the Market" announcement — creates urgency and FOMO.

### Layout (Front)

```
┌──────────────────────────────────────┐
│   ┌──────────────────────────────┐   │
│   │                              │   │
│   │   [Property photo]           │   │  Hero image
│   │                              │   │
│   │   ╔══════════════════╗       │   │
│   │   ║  NEW ON THE      ║       │   │  Large diagonal badge (Gold)
│   │   ║  MARKET          ║       │   │  Rotated -5°
│   │   ╚══════════════════╝       │   │
│   └──────────────────────────────┘   │
│                                      │
│   [Address]                          │  Charcoal, Playfair Display 40 pt
│   [Price]                            │  Gold, 28 pt
│                                      │
│   ┌────┐ ┌────┐ ┌────┐ ┌────┐    │
│   │Beds │ │Baths│ │Sq.m│ │Price│    │  Key stats plus price/sq m
│   │     │ │     │ │    │ │/sq m│    │
│   └────┘ └────┘ └────┘ └────┘    │
│                                      │
│   Featured highlights:               │
│   ✦ Recently renovated               │  Gold star bullets
│   ✦ Corner unit, lots of natural light│
│   ✦ Walking distance to school       │
│                                      │
│   Listed [Date] — [Agent Name]       │
│   [Phone] [Email]                    │
└──────────────────────────────────────┘
```

### Sections / Placeholders

| Section | Description | Colours |
|---|---|---|
| Hero Image | Best exterior or hero shot of property | — |
| "New on the Market" Badge | Diagonal ribbon-style badge, rotated slightly, placed over image | Gold bg, Charcoal text, Playfair Display Bold |
| Address | Full property address | Charcoal |
| Price | Bold sale price | Gold |
| Key Stats | Beds, Baths, Sq m, Price per sq m | Olive icons |
| Featured Highlights | 3 features with gold star bullets | Gold stars, Charcoal text |
| List Date | "Just Listed" date (e.g., "Listed 24 July 2026") | Lato Italic, Olive |
| Agent Announcement | Agent name + brokerage name | Charcoal |

### Colour Distribution
- High contrast: Gold badge on hero image, Charcoal text on Cream bg

---

## 7. Sold Flyer

**Purpose:** Announce a successful sale — builds credibility and social proof.

### Layout (Front)

```
┌──────────────────────────────────────┐
│   ┌──────────────────────────────┐   │
│   │                              │   │
│   │   [Property photo]           │   │  Hero image (best exterior)
│   │                              │   │
│   │   ┌────────────────────┐     │   │
│   │   │      SOLD!         │     │   │  Large SOLD stamp over image
│   │   │  Another Happy     │     │   │  (Charcoal bg or Terracotta bg)
│   │   │  Client Served     │     │   │
│   │   └────────────────────┘     │   │
│   └──────────────────────────────┘   │
│                                      │
│   [Property Address]                 │  Strikethrough price above
│   ✓ Sold Price: [Amount]             │
│   ✓ Days on Market: [14]             │
│                                      │
│   "The team made the process         │
│    seamless. Highly recommend!"      │  Client testimonial quote
│       — [Client Name]                │  (Playfair Display Italic)
│                                      │
│   [Agent Name]                       │
│   [Sold Date]                        │
│                                      │
│   ┌──────────────────────────────┐  │
│   │  Looking to buy or sell?   │   │  CTA button
│   │  [Call Now]                 │   │
│   └──────────────────────────────┘  │
└──────────────────────────────────────┘
```

### Sections / Placeholders

| Section | Description | Colours |
|---|---|---|
| Hero Image | Property photo (slightly dimmed overlay) | — |
| "SOLD" Badge | Large stamp-style overlay, centre | Charcoal bg or Terracotta bg, Gold or Cream text |
| "Another Happy Client" | Subtitle below SOLD badge | Cream text over image |
| Previous Price (strikethrough) | Original listing price, crossed out | Lato Regular, 50% opacity |
| Sold Price | Final sale price, bold | Gold |
| Days on Market | "Sold in just X days" | Olive |
| Client Testimonial | 1–2 sentence quote from happy client | Playfair Display Italic, Charcoal |
| Client Name | Name attribution | Lato Regular, Olive |
| CTA Button | "Looking to buy or sell? Call Now!" | Terracotta button, Cream text |
| Agent Footer | Agent name, phone, email, brokerage | Charcoal bg |

### Colour Distribution
- Bold: SOLD badge (high impact), Gold (success/achievement), Charcoal (authority)

---

## 8. Open House Flyer

**Purpose:** Promote an open house event — drive foot traffic.

### Layout (Front)

```
┌──────────────────────────────────────┐
│   ┌──────────────────────────────┐   │
│   │                              │   │
│   │   [Property photo]           │   │  Hero image
│   │                              │   │
│   │   ┌──────────────────────┐   │   │
│   │   │   OPEN HOUSE         │   │   │  Gold badge, top-left
│   │   │   THIS SUNDAY        │   │   │
│   │   └──────────────────────┘   │   │
│   └──────────────────────────────┘   │
│                                      │
│   [Address]                          │
│                                      │
│   ⏰ Sunday, 28 July 2026            │  Event date & time (bold)
│      2:00 PM — 5:00 PM               │
│                                      │
│   ┌──────────────────────────────┐  │
│   │  Refreshments Provided       │   │  Info card
│   │  🥂 Wine & Cheese            │   │
│   │  Light Snacks                │   │
│   └──────────────────────────────┘  │
│                                      │
│   ✦ Tour the property               │  Event highlights
│   ✦ Meet the agent                  │
│   ✦ Get exclusive market info       │
│   ✦ Financing consultation avail.   │
│                                      │
│   [Agent Name]                       │
│   [RSVP: Phone / WhatsApp]           │
│   [QR Code → Event Registration]    │
└──────────────────────────────────────┘
```

### Sections / Placeholders

| Section | Description | Colours |
|---|---|---|
| Hero Image | Property exterior (welcoming, daytime) | — |
| "Open House" Badge | Gold badge, top-left | Gold bg, Charcoal |
| "This Sunday" | Urgency text below badge | Terracotta |
| Address | Full property address | Charcoal |
| Date & Time | Bold event date + time range | Charcoal, Gold accent on date |
| Refreshments Card | "Refreshments Provided" with wine & cheese icon | Cream card, Terracotta border |
| Event Highlights | 4 bullet points with icons | Olive bullets |
| RSVP / Contact | Agent name, phone, WhatsApp, QR code | Charcoal bg footer |
| Directions | "Get Directions" link or map snippet | — |

### Colour Distribution
- Warm & inviting: Gold + Terracotta (event feel), Cream (approachable)

---

## Printed Specifications Summary

| Spec | Value |
|---|---|
| **Paper Stock** | 300 gsm matte or silk finish |
| **Finish** | Matte (premium feel) or silk (slight sheen) |
| **Bleed** | 3.175 mm / 0.125 in all sides |
| **Safe Zone** | 10 mm / 0.4 in inset from bleed edge |
| **Binding** | N/A — single-sided or double-sided print |
| **Quantity** | 100–500 recommended per flyer type |

---

## Copy Templates (Per Flyer)

Each flyer spec includes a **copy skeleton** in the `_copy/` subfolder (to be created):

- `Luxury-Copy-Skeleton.md`
- `Apartment-Copy-Skeleton.md`
- `Land-Copy-Skeleton.md`
- `Commercial-Copy-Skeleton.md`
- `Rental-Copy-Skeleton.md`
- `JustListed-Copy-Skeleton.md`
- `Sold-Copy-Skeleton.md`
- `OpenHouse-Copy-Skeleton.md`

Each skeleton contains fill-in-the-blank copy with word counts and SEO keywords relevant to African real estate search behaviour.
