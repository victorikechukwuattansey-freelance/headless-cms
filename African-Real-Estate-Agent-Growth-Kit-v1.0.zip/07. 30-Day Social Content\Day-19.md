# Day 19 — Market Analysis

## Post Type
Data-driven / neighbourhood comparison

## Caption Templates

**Template 1 — Neighbourhood comparison**
{{NeighborhoodName}} vs {{NeighborhoodName}} — which one is right for you? Let's compare 📊

| Factor | {{NeighborhoodName}} | {{NeighborhoodName}} |
|--------|---------------------|---------------------|
| Avg. Price ({{Bedrooms}} bed) | {{Price}} | {{Price}} |
| Distance to CBD | {{X}} mins | {{X}} mins |
| Rental Yield | {{X}}% | {{X}}% |
| Schools | {{Rating}} | {{Rating}} |
| Security | {{Rating}} | {{Rating}} |

Both are great — but for different reasons. DM me to find YOUR fit.

**Template 2 — Price trends**
Here's how property prices have shifted in {{City}} over the past {{X}} months:

📈 {{NeighborhoodName}}: {{PriceRange}} → {{PriceRange}} (+{{X}}%)
📈 {{NeighborhoodName}}: {{PriceRange}} → {{PriceRange}} (+{{X}}%)
📊 {{NeighborhoodName}}: {{PriceRange}} → {{PriceRange}} (stable)

The market is moving. Is your plan keeping up?

**Template 3 — Buyer budget map**
Where does your budget take you in {{City}}?

💰 {{LocalCurrency}}{{Amount}}–{{Amount}}: Best options in {{NeighborhoodName}}
💰 {{LocalCurrency}}{{Amount}}–{{Amount}}: Best options in {{NeighborhoodName}}
💰 {{LocalCurrency}}{{Amount}}+ : Best options in {{NeighborhoodName}}

Every budget has a perfect neighbourhood. Let's find yours.

## CTA
- DM me "ANALYSIS" for a personalised neighbourhood match
- Save this post for your market research
- Tag someone who's deciding between areas

## Suggested Hashtags
#MarketAnalysis #NeighborhoodComparison #AfricanRealEstate #LagosMarket #NairobiProperties #AccraRealEstate #PropertyData #RealEstateTrends #HomeBuyerTips #InvestmentInsights

## Image Recommendation
Clean infographic comparing two neighbourhoods side by side. Use a table format or split design with photos of each area. Professional, data-heavy, visually organised.

## Story Idea
**"Which Neighbourhood Wins?"** — 4-slide head-to-head battle. Each slide compares one factor (price, commute, schools, vibe). Use the poll sticker to let followers vote. End slide: "The winner? {{NeighborhoodName}}. DM me for listings there."

## Reel Idea
**45-sec "This Neighbourhood vs That Neighbourhood"** — Split screen or alternating cuts. Show each area's best feature: a street, a park, a market. Text overlay compares key stats. End screen: "Which one fits your lifestyle? DM me."
