# Day 15 — Land Buying Tips

## Post Type
Educational / plot purchasing guide

## Caption Templates

**Template 1 — The checklist**
Buying land in Africa? Here's your non-negotiable checklist:

📋 **Verify ownership** — Land registry search, not just a receipt
📋 **Survey the land** — Confirm boundaries, check for encroachment
📋 **Check zoning** — Is it residential, commercial, or agricultural?
📋 **Access road** — Legal access, not just a neighbour's goodwill
📋 **Utilities** — Water, electricity, drainage in place or planned

Skipping these steps is how people lose money. DM me "LAND" and I'll send you the full checklist.

**Template 2 — Common mistakes**
3 mistakes people make when buying land in {{City}}:

❌ Trusting a "cheap price" without verifying documents
❌ Buying without a survey
❌ Not visiting the land in person

Land is one of the best investments you can make — but only if you buy wisely. Protect your investment. Work with a trusted agent.

**Template 3 — Long-term value**
Why land? Because they're not making more of it.

In {{City}}, land values in areas like {{NeighborhoodName}} have appreciated {{X}}% over the past {{Y}} years. That's wealth you can see, touch, and pass on to the next generation.

Whether you're building your dream home or holding for future sale — land is foundation.

## CTA
- DM me "LAND" for a free land-buying guide PDF
- Save this post for your land-buying journey
- Tag someone planning to buy land

## Suggested Hashtags
#LandBuyingTips #PlotPurchase #AfricanRealEstate #LandInvestment #LagosLand #NairobiLand #AccraProperties #LandVerification #RealEstateAdvice #BuyingLand

## Image Recommendation
Photo of a surveyed plot with boundary markers or a "For Sale" sign on vacant land. Aerial/drone shots work well. Alternatively, a graphic with a checklist design in your brand colours.

## Story Idea
**"Land Verification Process"** — 4-slide walkthrough. Slide 1: "Step 1: Get the document number." Slide 2: "Step 2: Visit the land registry." Slide 3: "Step 3: Do a physical inspection." Slide 4: "Step 4: Get legal advice." Use the GIF sticker for each step.

## Reel Idea
**45-sec "5 Things to Check Before Buying Land"** — Direct-to-camera standing on a plot of land. Count down 5 points on your fingers. Use the land as your backdrop — show the surroundings. Text overlays reinforce each point. End with "DM me LAND for the full guide."
