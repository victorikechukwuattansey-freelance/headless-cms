# Day 18 — Weekend Listings

## Post Type
Curated property roundup

## Caption Templates

**Template 1 — The weekend roundup**
Your weekend property tour starts here 🏡✨

This week's featured listings:
1️⃣ {{Bedrooms}}-bedroom {{PropertyType}} in {{PropertyLocation}} — {{ListingPrice}}
2️⃣ {{Bedrooms}}-bedroom {{PropertyType}} in {{PropertyLocation}} — {{ListingPrice}}
3️⃣ {{Bedrooms}}-bedroom {{PropertyType}} in {{PropertyLocation}} — {{ListingPrice}}

Which one caught your eye? Drop the number in the comments 👇

**Template 2 — Price range focus**
Looking for something under {{LocalCurrency}}{{Amount}}? Here are {{X}} options I'm showing this weekend:

👇 {{PropertyLocation}} — {{Bedrooms}} bed, {{Price}}
👇 {{PropertyLocation}} — {{Bedrooms}} bed, {{Price}}
👇 {{PropertyLocation}} — {{Bedrooms}} bed, {{Price}}

All available, all verified, all ready for viewing. DM me to book a slot.

**Template 3 — Open weekend**
Planning your property search this weekend? I have {{X}} open viewings scheduled:

📅 Saturday:
— {{Time}} — {{PropertyLocation}}
— {{Time}} — {{PropertyLocation}}

📅 Sunday:
— {{Time}} — {{PropertyLocation}}
— {{Time}} — {{PropertyLocation}}

Spots are limited. DM me to secure your slot.

## CTA
- DM me the number of the property you love
- Save this post for your weekend plans
- Share with someone who's house-hunting

## Suggested Hashtags
#WeekendListings #PropertyRoundup #HouseHunting #AfricanRealEstate #LagosProperties #NairobiHomes #AccraRealEstate #HomeSearch #RealEstateListings #WeekendVibes

## Image Recommendation
A collage of 3–4 property photos with price/property type labels overlay. Use Canva for a clean grid layout. Consistent lighting across all images. Or a single high-quality featured listing photo.

## Story Idea
**"Swipe Through This Weekend's Picks"** — 5-slide carousel. Each slide = one property with a photo, price, and key details. Use the "DM for details" sticker on each. Last slide: "Which one is yours? Let me know."

## Reel Idea
**30-sec "3 Listings You Need to See"** — Fast cuts: Exterior → Interior → Key feature for each of 3 properties. Text overlay shows price and location for each. Energetic music. End screen: "DM to book a viewing."
