# Quick-Start Guide

**From zero to your first professional property post in 10 minutes.**

---

## What You'll Accomplish

- Create a branded property flyer
- Create an Instagram post
- Export and share

---

## Step 1: Open Canva

1. Go to [canva.com](https://canva.com) and log in
2. If you set up the Brand Kit (see [Canva-BrandKit-Setup.md](./Canva-BrandKit-Setup.md)), your colors and fonts are ready
3. If not — no problem. Just note the hex codes below.

---

## Step 2: Create a Property Flyer

1. Click **"Create a design"**
2. Search for **"A4 document"** (2480 × 3508 px)
3. You'll see a blank canvas

### Build the Layout

**Layer 1 — Background:**
- Click **Elements → Shapes → Rectangle**
- Make it 2480 × 3508 px, fill with Cream `#F5F0E8`
- Lock it (click the lock icon)

**Layer 2 — Hero Image:**
- Click **Uploads → Upload Files** and select your best property photo
- Drag the photo onto the canvas
- Resize to cover the top 55% of the page (about 1929 px tall)
- Position at the top edge
- **Pro tip:** Hold Shift while resizing to maintain proportions

**Layer 3 — Badge:**
- Add a rectangle, make it about 300 × 80 px
- Color: Gold `#C9A84C`
- Rotate slightly (-3°) using the handle above the shape
- Position top-left over the image
- Add text: **"NEW LISTING"** — Playfair Display Bold, 28 pt, Charcoal `#2D2D2D`

**Layer 4 — Property Name:**
- Add text: your property name/address
- Font: Playfair Display Bold, 36 pt
- Color: Charcoal `#2D2D2D`
- Position below the hero image

**Layer 5 — Price:**
- Add text: your price (e.g., "KES 45,000,000")
- Font: Playfair Display Bold, 28 pt
- Color: Gold `#C9A84C`

**Layer 6 — Stats Row:**
- Add four small rectangles (120 × 120 px each)
- Color: Olive `#7B8D5D` with 20% opacity
- Inside each, add text: Beds, Baths, Sq m, Parking
- **Pro tip:** Create one, duplicate it 3 times with Ctrl+D, then edit each

**Layer 7 — Agent Footer:**
- Add a rectangle 2480 × 200 px at the bottom
- Color: Charcoal `#2D2D2D`
- Add your name (Lato Bold, 18 pt, Cream)
- Add your phone and email (Lato Regular, 14 pt, Cream)

### Export Your Flyer

1. Click **"Share"** (top right)
2. Click **"Download"**
3. File type: **PDF Print** (for print) or **PNG** (for digital)
4. Click **"Download"**

---

## Step 3: Create an Instagram Post

1. Click **"Create a design"** → **"Instagram Post"** (1080 × 1080 px)
2. Apply the same recipe, but at square dimensions
3. Use one hero image that fills the background
4. Overlay your text with contrast (white text on dark image areas, or add a semi-transparent Charcoal overlay rectangle)

### Pro Tip: Use the Same Structure

The flyer you just made has all the pieces you need. To make an Instagram version:
- Create a new **Instagram Post** canvas
- Copy and paste elements from your flyer (or re-create using the same recipe)
- Adjust font sizes (make them bigger — Instagram is viewed on phones)

---

## Next Steps

1. **Set up your Brand Kit** — Follow [Canva-BrandKit-Setup.md](./Canva-BrandKit-Setup.md) for one-click branding
2. **Build your template library** — Use the [Template Build Guide](./Template-Build-Guide.md) to build all 300+ templates
3. **Follow the 30-Day Content Calendar** — In `07. 30-Day Social Content/` for ready-made daily posts
4. **Launch your ads** — Use the Meta and TikTok scripts in Modules 3 & 4
5. **Set up your store** — Use `02. Sales Page/selar-listing.md` or `gumroad-listing.md` to list this product

---

**You're now ready to market like a premium agency.**
