# Launch Checklist — African Real Estate Agent Growth Kit

> **Product launch date:** T‑7 and counting
> **Format:** This checklist covers everything from pre-launch prep to post-launch optimization

---

## Pre-Launch Timeline (7 Days Before Launch)

### Day T‑7: Foundation

- [ ] Finalize all product files and modules
- [ ] Upload to Selar / Gumroad (whichever platform you chose)
- [ ] Set product price (regular + launch discount)
- [ ] Configure payment methods (card, bank transfer, USSD)
- [ ] Enable automatic delivery (instant PDF + download links)
- [ ] Test download flow with a test purchase
- [ ] Create product thumbnail (1370 × 800 px recommended)
- [ ] Create 3–5 preview images (showcasing kit contents)
- [ ] Write product description (benefits-first, features-second)
- [ ] Set up thank-you page with clear download instructions
- [ ] Set up customer support email (support@yourdomain.com)
- [ ] Create FAQ for checkout page

### Day T‑6: Email & Automation

- [ ] Connect email marketing tool (Mailchimp, MailerLite, ConvertKit, or SendGrid)
- [ ] Write welcome email sequence (5 emails):
  - Email 1: "Your download links inside" (immediate delivery)
  - Email 2: "How to get started — Module 1 first"
  - Email 3: "Customize your Canva templates"
  - Email 4: "Set up your first Facebook ad"
  - Email 5: "Bonus resources you don't want to miss"
- [ ] Set up abandoned cart email (automated, 1 hour after abandonment)
- [ ] Enable analytics (Google Analytics + Meta Pixel on checkout page)
- [ ] Create custom conversion event in Meta Pixel
- [ ] Set up UTM parameters for all marketing links

### Day T‑5: Social Content Prep

- [ ] Design 30 days of social media posts (use your kit!)
- [ ] Write 30 captions (hook + value + CTA)
- [ ] Create 5 Reels / TikToks promoting the kit
- [ ] Schedule first 10 posts in Meta Business Suite
- [ ] Write launch announcement post
- [ ] Write "X hours left" urgency post
- [ ] Write "Sold X copies" social proof post
- [ ] Write testimonial post template
- [ ] Create WhatsApp Status content (5 days of behind-the-scenes)

### Day T‑4: Ad Campaign Setup

- [ ] Create Meta Ads campaign (objective: Conversions or Sales)
- [ ] Set up 3 ad sets with different targeting:
  - Ad set 1: Real estate agents (interest-based targeting)
  - Ad set 2: Small business owners / entrepreneurs
  - Ad set 3: Lookalike of email list / past buyers
- [ ] Design 5 ad creatives (3 image, 2 carousel)
- [ ] Write 5 ad copy variations
- [ ] Set up TikTok Ads campaign (2 ad groups)
- [ ] Design 2 TikTok ad creatives (vertical video)
- [ ] Set daily budget: Meta (₦3,000–₦5,000), TikTok ($5–$10)
- [ ] Install tracking pixels on landing page

### Day T‑3: Outreach & Partnerships

- [ ] Identify 10 real estate Facebook groups
- [ ] Join groups with your business profile (not personal)
- [ ] Identify 3 real estate influencers for collaboration
- [ ] Prepare influencer briefing document (what they need to post)
- [ ] Reach out to influencers with offer (free kit + commission)
- [ ] Prepare email to existing contacts
- [ ] Segment contact list (past clients, prospects, agents)

### Day T‑2: Final Testing

- [ ] End-to-end purchase test on desktop
- [ ] End-to-end purchase test on mobile
- [ ] Test email delivery (check spam folder)
- [ ] Test download links from purchase confirmation
- [ ] Test all links in ad creatives
- [ ] Review all social scheduled posts
- [ ] Confirm influencer partnerships
- [ ] Prepare customer support scripts (FAQ responses)

### Day T‑1: Launch Eve

- [ ] Send "coming tomorrow" teaser to email list
- [ ] Post "last chance at pre-launch price" on social media
- [ ] WhatsApp Status: "Launching tomorrow"
- [ ] Make sure product page is LIVE but in "draft" or "unlisted" mode
- [ ] Turn OFF any test ads
- [ ] Prepare launch day dashboard (check analytics, keep tab open)
- [ ] Get a good night's sleep

---

## Launch Day Playbook (Hour by Hour)

| Time | Action |
|---|---|
| **6:00 AM** | Wake up, shower, coffee. Mindset check: "I built this, it's valuable, people need it." |
| **7:00 AM** | **Flip the switch** — set product to PUBLIC / PUBLISHED |
| **7:05 AM** | Send launch email to entire list ("It's live!") |
| **7:15 AM** | Post launch announcement on all social platforms |
| **7:30 AM** | WhatsApp Status: "🚀 JUST LAUNCHED" (link in status) |
| **7:45 AM** | Enable Meta Ads campaign |
| **8:00 AM** | Enable TikTok Ads campaign |
| **8:15 AM** | Send launch message to 10 WhatsApp broadcast lists |
| **8:30 AM** | Post in 5 real estate Facebook groups (follow group rules) |
| **9:00 AM** | Monitor: Check for first purchases. Screenshot them. |
| **9:30 AM** | If first sale comes in — post social proof ("Sold in the first hour!") |
| **10:00 AM** | Respond to all comments and DMs (keep response time < 1 hour) |
| **12:00 PM** | Midday check — review ad performance |
| **1:00 PM** | Send "lunch break" social post |
| **3:00 PM** | Second round of Facebook group posts (5 more groups) |
| **5:00 PM** | WhatsApp Status update: "X agents have grabbed the kit today" |
| **6:00 PM** | Evening ad performance review |
| **7:00 PM** | Send follow-up email: "Last chance at launch price" |
| **8:00 PM** | Post evening social content |
| **9:00 PM** | Final check — adjust budgets if ads perform well |
| **10:00 PM** | Pause ads if budget exhausted |
| **10:30 PM** | **End of day review** — log sales, leads, engagement metrics |

### Launch Day Priority Actions (Ranked)

1. **Get that first sale** (post everywhere, DM close contacts)
2. **Capture social proof** (screenshot every sale notification)
3. **Respond to inquiries** within 1 hour maximum
4. **Monitor ad performance** — kill underperformers, scale winners
5. **Send personalized thank you** to every buyer within 30 minutes

---

## Post-Launch Optimization Schedule

### Day 2–3: Stabilization

- [ ] Review Day 1 metrics (sales, traffic, conversion rate)
- [ ] Pause worst-performing ad (CPL > 2x target)
- [ ] Increase budget on best-performing ad (+20%)
- [ ] A/B test new ad creative against winner
- [ ] Post client testimonial (first buyer's reaction)
- [ ] Send "still available" email to non-openers
- [ ] Share first buyer's testimonial on WhatsApp Status
- [ ] Post in 5 more Facebook groups

### Day 4–7: First Week Scale

- [ ] Analyze first 7 days of data
- [ ] Double down on best channel (Meta vs. TikTok vs. organic)
- [ ] Create lookalike audience from first 50 buyers
- [ ] Collect testimonials from all buyers (automated email: "Loved the kit? Reply here")
- [ ] Publish first case study (interview early buyer)
- [ ] Launch referral campaign ("Refer an agent, get 20% commission")
- [ ] Post 3x daily on social (morning, afternoon, evening)

### Week 2: Momentum

- [ ] Analyze conversion funnel (visit → cart → purchase)
- [ ] Fix any drop-off points
- [ ] Upsell: Offer 1-on-1 coaching to buyers (₦XX,XXX/session)
- [ ] Upsell: Bundle kit + coaching at premium price
- [ ] Create and send "tips and tricks" bonus email to buyers
- [ ] Pitch to 5 real estate blogs for review
- [ ] Pitch to 3 real estate podcasts

### Week 3–4: Sustainability

- [ ] Review full 30-day metrics
- [ ] Plan rerun / sequel campaign
- [ ] Price increase (remove launch discount)
- [ ] Create content upgrades (new templates, new bonuses)
- [ ] Automate wherever possible (email flows, ads)
- [ ] Decide: Keep as evergreen product or limited-time launch

---

## KPI Tracker Template

| Day | Sales | Revenue | Traffic | Conversion Rate | AOV | Ad Spend | ROAS | Page Views | CPL | Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| T‑7 | | | | | | | | | | |
| T‑6 | | | | | | | | | | |
| ... | | | | | | | | | | |
| Launch | | | | | | | | | | |
| D+1 | | | | | | | | | | |
| D+2 | | | | | | | | | | |
| D+3 | | | | | | | | | | |
| ... | | | | | | | | | | |
| D+30 | | | | | | | | | | |

### Key Metrics Glossary

| Metric | Definition | Target |
|---|---|---|
| **Conversion Rate** | % of visitors who purchase | 2–5% |
| **AOV (Average Order Value)** | Total revenue ÷ Number of orders | Kit price + upsells |
| **ROAS (Return on Ad Spend)** | Revenue ÷ Ad spend | 3x+ |
| **CPL (Cost Per Lead)** | Ad spend ÷ Leads generated | < ₦500 |
| **CTR (Click-Through Rate)** | % who click ad after seeing it | 1–3% |
| **Email Open Rate** | % who open your launch email | 30–50% |
| **Email Click Rate** | % who click link in email | 3–10% |
| **Bounce Rate** | % who leave checkout page without buying | < 60% |

### When to Pivot

| Signal | Action |
|---|---|
| 0 sales in first 6 hours of launch | Check checkout flow (is it broken?) |
| High traffic, 0 sales (24 hours) | Price too high? Messaging unclear? A/B test landing page |
| Ad CTR > 2% but 0 conversions | Landing page is the problem — redesign |
| Ad CTR < 0.5% | Creative is the problem — new ads |
| High conversions at launch, drop Week 2 | Audience saturated — expand targeting |
| Low email open rate | Subject line is weak — test new subject lines |

---

## Launch Completion Checklist

- [ ] Product is live and selling
- [ ] Welcome email sequence is sending
- [ ] Abandoned checkout automation is active
- [ ] Ads are running profitably (ROAS 3x+)
- [ ] First 5 testimonials collected
- [ ] 2 case studies in progress
- [ ] Social content is scheduled for next 30 days
- [ ] Influencer posts are live
- [ ] Upsell offers are live (coaching, premium)
- [ ] KPI tracker is being updated daily
- [ ] Rerun campaign is planned (30–60 days from now)

---

> **Remember:** A product launch is not the finish line — it's the starting line. The real money is made in the weeks and months after launch through upsells, referrals, and building a brand that customers trust.
