# Property Inspection Checklist — African Real Estate

> **Format:** Print-ready PDF / Digital download
> **Goal:** Guide buyers through a thorough room-by-room property inspection
> **Tip:** Visit the property at least twice — once during the day and once in the evening

---

## Before You Go

- [ ] Print this checklist (one copy per property)
- [ ] Bring: flashlight, phone charger (to test outlets), measuring tape, notebook
- [ ] Wear comfortable shoes — you'll be walking around the entire property
- [ ] Schedule viewing during daylight (preferably 10 AM – 2 PM)
- [ ] Arrive 10 minutes early to observe the neighborhood

---

## Exterior

### Boundary & Land

- [ ] Fence/gate is intact and secure
- [ ] Property boundaries match the survey plan
- [ ] No encroachment from neighboring properties
- [ ] No evidence of boundary disputes (makeshift markers, conflicting walls)
- [ ] Gate motor/automatic system works (if applicable)
- [ ] Drainage channels are clear and properly sloped

### Roof

- [ ] Visible from ground — no missing or displaced tiles/sheets
- [ ] No sagging or uneven sections
- [ ] Gutters are clean and securely attached
- [ ] Downspouts direct water away from foundation
- [ ] No signs of rust on corrugated iron/aluminum roofing sheets
- [ ] Fascia/soffit boards not rotting or damaged

### Foundation

- [ ] No visible cracks in foundation walls
- [ ] No signs of subsidence (sloping floors, sticking doors)
- [ ] Damp proof course intact (black line on exterior walls)
- [ ] No termite mounds or trails near foundation
- [ ] No standing water around foundation

### Driveway & Parking

- [ ] Surface condition (cracked, uneven, potholes)
- [ ] Drainage — no water pooling after rain
- [ ] Parking space fits your vehicle(s)
- [ ] Carport/garage door operates smoothly
- [ ] Garage floor — no oil stains or cracks

---

## Interior — Room by Room

### Living Room / Dining Room

- [ ] Wall condition — cracks, dampness, peeling paint
- [ ] Ceiling — stains, cracks, mold, asbestos concerns
- [ ] Flooring — tiles/cracking, wood/rotting, carpet/stains
- [ ] Natural lighting — windows face which direction?
- [ ] Ventilation — windows open fully, airflow adequate
- [ ] Electrical — enough power points? Location convenient?
- [ ] TV/Internet point present and working
- [ ] AC unit — brand, BTU rating, age, remote included
- [ ] AC — test cooling for 5+ minutes

### Kitchen

- [ ] Cabinet condition — doors close properly, no water damage underneath
- [ ] Countertop — cracks, stains, heat damage
- [ ] Sink — water pressure, drainage speed, no leaks under sink
- [ ] Plumbing — pipes visible, no corrosion or leaks
- [ ] Gas connection — flex hose condition, shutoff valve works
- [ ] Extractor fan — operational, vents to outside
- [ ] Electrical — dedicated points for fridge (surge protected), microwave, blender
- [ ] A / B Switch present (for generator/inverter power)
- [ ] Floor drainage — slope toward drain, no standing water
- [ ] Pest signs — droppings, grease marks, dead insects

### Bedrooms

- [ ] Room size — can it fit your bed + furniture?
- [ ] Window size and orientation — morning sun vs. afternoon sun
- [ ] Built-in wardrobe — door operation, inside condition, no damp smell
- [ ] AC unit — same checks as living room
- [ ] Electrical — bedside outlet locations
- [ ] Noise level — windows closed vs. open (road noise, neighbor noise)
- [ ] Curtain rails/blind fittings present

### Bathrooms

- [ ] Toilet — flush power, no running water sound, stable base
- [ ] Shower — water pressure (hot and cold), drain speed
- [ ] Bathtub (if present) — no cracks, faucet operation, drain plug
- [ ] Sink — tap pressure, no leaks, cabinet underneath (no mold/rot)
- [ ] Mirror — condition, fog-proof? Light above mirror?
- [ ] Ventilation — window or exhaust fan working
- [ ] Tiles — wall and floor, no cracks, grout not missing/decayed
- [ ] Floor drain — water pools and drains, no standing water
- [ ] Water heater — type (electric/solar/gas), age, capacity (liters)
- [ ] Water heater test — heats within 15–20 minutes

### Hallway / Corridor

- [ ] Width — comfortable for moving furniture
- [ ] Lighting — functional
- [ ] Smoke detector present (if property has one)

---

## MEP (Mechanical, Electrical, Plumbing)

### Electrical System

- [ ] Main panel location — accessible, not cluttered
- [ ] Breaker labels — clear and accurate
- [ ] Wiring — not exposed, no frayed cables
- [ ] Wall outlets — test 3 random ones with phone charger
- [ ] Light switches — all present, all work
- [ ] Ceiling fans — test at all speeds, check wobble
- [ ] A / B Switch — switches between mains and generator smoothly
- [ ] Surge protection — present on main panel
- [ ] Earth/grounding wire — present (crucial for lightning protection)

### Plumbing

- [ ] Main water shutoff valve — location known and accessible
- [ ] Pipes (visible) — no corrosion, no leaks, no signs of previous leaks
- [ ] Water pressure — acceptable at farthest tap from tank
- [ ] Hot water — reaches all intended points (bathroom sinks, shower, kitchen)
- [ **Water Tank** — check below]

### African-Specific Systems

#### Generator

- [ ] Brand and model — reliable brand? (e.g., Mikano, FG Wilson, Elepaq)
- [ ] Power rating (kVA) — sufficient for the property's needs?
- [ ] Fuel type — petrol, diesel, or gas
- [ ] Fuel consumption — liters per hour (ask owner)
- [ ] Service history — last service date, regular schedule?
- [ ] Running hours — meter reading (if digital)
- [ ] Noise level — acceptable for neighborhood? (especially at night)
- [ ] Exhaust — directed away from windows/neighbors
- [ ] Automatic Changeover — present and working?
- [ ] Generator house — clean, ventilated, secured

#### Inverter / Solar System

- [ ] Inverter brand and capacity (kVA/kW)
- [ ] Battery type — Lithium (LiFePO4) vs. Lead-acid (Deep Cycle)
- [ ] Battery bank — number of batteries, total capacity (Ah)
- [ ] Solar panels — number, wattage, orientation, age
- [ ] Charge controller — MPPT vs. PWM? Condition?
- [ ] Backup duration — full load / partial load hours
- [ ] Last maintenance date
- [ ] Warranty remaining on panels and batteries
- [ ] Any faults or error codes on display panel?

#### Water Supply

- [ ] **Borehole:**
  - [ ] Depth (feet/meters)
  - [ ] Pump type — submersible vs. surface
  - [ ] Water quality test date — potable?
  - [ ] Flow rate — liters per hour
  - [ ] Tank capacity (liters) and material (plastic vs. concrete)
- [ ] **Municipal water:**
  - [ ] Supply frequency — daily, weekly, sporadic?
  - [ ] Storage tank — capacity, condition, cleaning schedule
- [ ] **Pump:**
  - [ ] Brand and model
  - [ ] Pressure tank — condition, no rust/leaks
  - [ ] Automatic operation — cuts in/out correctly
  - [ ] Noise level when running

#### Sewage / Waste

- [ ] Type — septic tank vs. municipal sewage
- [ ] Septic tank — location known, last emptied (date)
- [ ] Septic tank — no odor near location
- [ ] Septic tank — access cover intact and sealed
- [ ] Soakaway — location known, no water pooling above it
- [ ] Waste pipes — slope adequate, no blockages
- [ ] Vent pipes — present, no odor from drains

---

## Security

### Perimeter Security

- [ ] Perimeter fence — height, condition, any gaps
- [ ] Barbed wire / electric fence — present and active
- [ ] Security gate — operates smoothly, remote control works
- [ ] Guard house — present, size, condition
- [ ] Security lighting — motion sensor? Coverage adequate?
- [ ] Neighborhood security — local security arrangement, HOA security

### Building Security

- [ ] Main door — material (solid wood, metal), lock type (mortise, padlock)
- [ ] Window grilles/burglar bars — secure, no rust, emergency exit windows openable
- [ ] All external doors have at least 2 locking points
- [ ] Sliding doors — lock works, track not worn, security bar present
- [ ] CCTV system — camera count, NVR, remote viewing capability
- [ ] Intercom / gate phone — working condition
- [ ] Smoke detectors — present on each floor
- [ ] Fire extinguisher — present, not expired

---

## Pest Inspection

- [ ] Termites — mud tubes on walls/foundation, wood damage, discarded wings
- [ ] Cockroaches — droppings (black pepper-like) in kitchen/bathroom cabinets
- [ ] Rodents — droppings, gnaw marks, noises in ceiling
- [ ] Mosquitoes — standing water nearby, window screens intact
- [ ] Ants — trails inside the property
- [ ] Bed bugs — check mattress seams, headboard, behind picture frames
- [ ] Previous pest treatment — date, type, warranty
- [ ] Fumigation history — year, company, certificate available

---

## Final Assessment

### Scores

| Area | Score (1–5) | Notes |
|---|---|---|
| Exterior & Boundary | | |
| Roof & Foundation | | |
| Living / Dining | | |
| Kitchen | | |
| Bedrooms | | |
| Bathrooms | | |
| Electrical | | |
| Plumbing | | |
| Generator | | |
| Inverter / Solar | | |
| Water Supply | | |
| Security | | |
| Pests | | |

**Scoring:** 1 = Poor / Needs major work | 3 = Average / Minor updates needed | 5 = Excellent / Move-in ready

### Summary

| Item | Yes | No | Needs Further Check |
|---|---|---|---|
| Move-in ready? | | | |
| Major repairs needed? | | | |
| Negotiation leverage found? | | | |
| Recommended for purchase? | | | |

### Post-Inspection Actions

- [ ] Ask for utility bills (electricity, water) — average monthly cost
- [ ] Ask about estate dues / service charge (₦/year)
- [ ] Ask about neighborhood issues (flooding, road accessibility, power supply hours)
- [ ] Request generator maintenance log
- [ ] Request borehole water quality test report
- [ ] Visit again on a rainy day (check for leaks and drainage)
- [ ] Visit at night (check security, noise, neighborhood activity)
- [ ] Speak to at least 2 neighbors about the area

---

> **Remember:** No property is perfect. Prioritize structural issues (foundation, roof, plumbing, electrical) over cosmetic ones (paint, tiles, fittings). Negotiate on the major items.
