# Video 1: Editing Canva Templates

> **Length:** 25–35 minutes
> **Level:** Beginner
> **Prerequisites:** Free Canva account (canva.com)

---

## Learning Objectives

By the end of this video, the viewer will be able to:

1. Navigate Canva and open the Growth Kit templates
2. Change colors to match their personal brand
3. Swap placeholder images with their own property photos
4. Edit text, fonts, and layouts
5. Export templates to the correct size for each platform
6. Save branded templates for reuse

---

## Script Outline

### Hook (0:00–0:30)

"Most agents spend 3 hours every week designing posts from scratch. With the templates in this kit, you can do it in 10 minutes. Let me show you how."

### Introduction (0:30–1:30)

- What's included in the Canva template pack
- Where to find the template link (check your download email)
- Overview of template categories (Facebook, Instagram, LinkedIn, Property Flyers)

### Main Content

#### Part 1: Opening a Template (1:30–5:00)

1. Log into Canva
2. Click the template link from the kit
3. Navigate the Canva editor interface
4. **Screen recording:** Open a flyer template

#### Part 2: Changing Colors (5:00–10:00)

1. Click any element to select
2. Use the color picker to change
3. Set brand colors (upload hex codes or pick from existing)
4. How to change all colors at once (brand kit — Canva Pro feature)
5. **Exercise:** Change one flyer to your brand colors

#### Part 3: Replacing Images (10:00–15:00)

1. Click an image in the template
2. Use "Replace image" (keep frame)
3. Upload your own property photos
4. Adjust image crop and positioning
5. Apply filters for consistency
6. **Exercise:** Swap 3 placeholder images with your own

#### Part 4: Editing Text (15:00–20:00)

1. Click text boxes to edit
2. Change fonts (recommendations for real estate: bold, readable)
3. Adjust text size and alignment
4. Add your phone number, website, WhatsApp link
5. **Best practice:** Keep text minimal — let the photo sell the property
6. **Exercise:** Customize all text in a property flyer

#### Part 5: Duplicating & Saving (20:00–25:00)

1. Duplicate templates for recurring posts
2. Save to a folder ("Brand — Agent Name")
3. Export options (PNG vs. JPG vs. PDF)
4. Schedule directly from Canva (Pro feature)
5. **Exercise:** Create a folder, duplicate 3 templates, save as PNG

### Key Takeaways (25:00–28:00)

1. Always work from a copy — never edit the original template
2. Keep brand colors consistent across all posts
3. Use high-quality photos (no blurry or dark images)
4. Export at 2x resolution for sharp images on all devices
5. Save frequently — Canva auto-saves but backup is better

### CTA (28:00–30:00)

- "Open your kit now and customize your first template"
- Next video: "Creating Reels for Real Estate"

---

## Practical Exercise

**Assignment:** Customize 3 templates from different categories (Facebook, Instagram, Property Flyer) with your own branding and photos. Post one to your social media.

**Submission:** Screenshot of the 3 customized templates

---

## Resource Links

- Canva: https://www.canva.com
- Canva Design School (free tutorials): https://www.canva.com/learn/
- Hex color picker: https://coolors.co
- Free stock photos (if you need them): https://www.pexels.com, https://unsplash.com
- Brand color inspiration: https://www.colors.lol
