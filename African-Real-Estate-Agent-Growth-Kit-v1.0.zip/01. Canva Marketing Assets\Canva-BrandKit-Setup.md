# Canva Brand Kit Setup Guide

Set up your Canva Brand Kit in 5 minutes so every template you create automatically uses your brand colors and fonts.

---

## What You'll Need

- A Canva account (free or Pro — Brand Kit requires Pro, but you can manually set colors/fonts on Free)
- Your logo (PNG with transparent background, minimum 200×200 px)
- Your agent photo (headshot, square crop, minimum 400×400 px)

---

## Step 1: Open Brand Kit

1. Log in to [Canva.com](https://canva.com)
2. Click **Brand** in the left sidebar
3. Click **"Add brand kit"** (or edit an existing one)
4. Name it: `African Real Estate Agent — [Your Name]`

---

## Step 2: Add Brand Colors

Click **"Add brand colors"** and enter these hex codes:

| Color | Hex Code | Usage |
|-------|----------|-------|
| Charcoal | `#2D2D2D` | Headlines, footer backgrounds, primary text |
| Cream | `#F5F0E8` | Page backgrounds, card backgrounds |
| Terracotta | `#C26A4A` | Badges, CTA buttons, accent highlights |
| Olive | `#7B8D5D` | Icons, checkmarks, stat numbers, nature associations |
| Gold | `#C9A84C` | Prices, premium badges, achievement accents |

**Pro tip:** Add tints of each color too. Click the `+` next to each color to add 20%, 40%, and 60% opacity versions. Use these for subtle background washes and hover states.

---

## Step 3: Add Brand Fonts

Click **"Add brand fonts"** and select:

| Style | Font | Weight |
|-------|------|--------|
| Heading | Playfair Display | Bold (700) |
| Subheading | Playfair Display | Italic (400) |
| Body | Lato | Regular (400) |
| Bold Body | Lato | Bold (700) |
| Caption | Lato | Light (300) |

**Pro tip:** If you don't have Canva Pro, you can still use these fonts manually. Just select the text element and choose the font from the dropdown. You'll need to do this each time for free accounts.

---

## Step 4: Upload Logo

1. In Brand Kit, click **"Add logo"**
2. Upload your logo PNG file
3. Choose the **"Dark background"** and **"Light background"** variants
4. Set the safe zone margins (minimum 20 px padding)

---

## Step 5: Upload Brand Photos

1. Click **"Add photos"**
2. Upload 5-10 high-quality property photos you commonly use
3. These will appear in your brand assets panel for quick access

---

## Step 6: Save as Brand Template

1. After creating any design, click **"File" → "Save as brand template"**
2. Name it and add it to your brand kit
3. Team members can now use it from the **Brand Templates** tab

---

## Step 7: Share with Team

1. Click **"Share"** on your brand kit
2. Enter team member email addresses
3. Set permissions: **"Can edit"** for full access
4. They'll receive an invite with one-click apply

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Can't see Brand Kit tab | You need Canva Pro ($12.99/mo). Free users can still use the guide — just set colors/fonts manually on each template. |
| Colors look different on screen vs print | Design for web in RGB mode, for print in CMYK. Our hex codes are for web. Print shops will convert. |
| Font not appearing | Some fonts are Pro-only. Playfair Display and Lato are available on Free tier. |
| Logo looks pixelated | Re-upload at minimum 200×200 px, PNG format, transparent background. |

---

Next: Open the [QUICK-START.md](./QUICK-START.md) to create your first template in under 10 minutes, or dive into the [Template Build Guide](./Template-Build-Guide.md) for the full library.
