# Video 3: Running Facebook & Instagram Ads

> **Length:** 30–40 minutes
> **Level:** Intermediate
> **Prerequisites:** Facebook Business Page, Meta Business Suite account

---

## Learning Objectives

By the end of this video, the viewer will be able to:

1. Set up a Meta Ads Manager campaign from scratch
2. Target African real estate buyers effectively
3. Choose the right ad objective and format
4. Set a budget and bid strategy that works
5. Read ad performance metrics and optimize

---

## Script Outline

### Hook (0:00–0:30)

"Most agents waste money on Facebook ads because they target the wrong people, use the wrong creative, or don't track results. In this video, I'll show you the exact system I use to generate leads for under ₦500 per contact."

### Introduction (0:30–2:00)

- Why Facebook/Instagram ads work for real estate in Africa
- Platform penetration data (Nigeria has 35M+ Facebook users, 15M+ Instagram users)
- What you'll be able to do after this video

### Main Content

#### Part 1: Campaign Setup (2:00–10:00)

1. Go to Meta Ads Manager (business.facebook.com/adsmanager)
2. **Campaign objective:** Choose "Leads" or "Conversions"
   - Leads: Use built-in lead form (no website needed)
   - Conversions: Send to your website/landing page (requires Meta Pixel)
3. **A/B Testing:** Set up at least 2 ad sets from the start
4. **Screen recording:** Walk through the entire campaign creation flow

#### Part 2: Targeting African Audiences (10:00–17:00)

1. **Location targeting:** City + radius (e.g., Lagos Island + 5 km)
2. **Demographics:**
   - Age: 25–55
   - Income: Top 25% (if available in your market)
   - Homeowners / Recently moved (interest-based)
3. **Interest targeting (work in Nigeria/Ghana):**
   - Real estate
   - Property investment
   - Home ownership
   - Specific neighborhoods (use as interest)
   - Followers of local developers (e.g., "Lekki Gardens")
4. **Custom audiences:**
   - Website visitors (if using Pixel)
   - WhatsApp engagement (if using click-to-WhatsApp)
5. **Exclusions:** Remove people who already submitted leads (suppression list)

#### Part 3: Ad Creatives That Convert (17:00–25:00)

1. **Image vs. Video:** Video ads get 2x higher engagement
2. **Ad copy formula:**
   - Hook (first line): "Looking for a 3-bedroom in Lekki?"
   - Body: 2–3 sentences on the property/offer
   - CTA button: "Learn More" or "Send WhatsApp Message"
3. **Primary text:** Short and benefit-focused
4. **Headline:** "New Listing: 3-Bedroom Duplex in Lekki Phase 1"
5. **Creative rotation:** Run 3–5 different creatives per ad set
6. **Screen recording:** Build an ad from the kit's ad templates

#### Part 4: Budget & Bidding (25:00–32:00)

1. **Daily budget:** Start with ₦2,000–₦5,000 per ad set
2. **Lifetime budget:** Better for time-bound campaigns
3. **Bid strategy:** "Lowest cost" (default) works best
4. **Schedule:** Run ads 6 AM – 10 PM (when people are scrolling)
5. **Payment:** Nigerian Naira via Naira card, Ghana Cedi, etc.
6. **Cost benchmarks:**
   - CPL (Cost Per Lead): ₦300–₦800 (Nigeria)
   - CPC: ₦50–₦150
   - CTR: 1–3% is good

#### Part 5: Tracking & Optimization (32:00–38:00)

1. **Key metrics to watch:**
   - CTR (Click-Through Rate) — below 0.5% = change creative
   - CPL — above ₦1,000 = refine targeting
   - Frequency — above 3 = audience fatigue
2. **When to kill an ad:**
   - After 50,000 impressions with 0 conversions
   - CTR below 0.3% after 1,000 impressions
   - CPL consistently above target
3. **When to scale:**
   - CPL is at or below target for 3+ days
   - CTR is above 2%
   - Increase budget by 20% every 2–3 days

### Key Takeaways (38:00–40:00)

1. Always run at least 2 ad sets in A/B test
2. Use video creatives — they outperform images 2:1
3. Start small (₦2,000/day), scale winners
4. Track everything — use a spreadsheet for leads
5. Retarget anyone who engaged but didn't convert

### CTA

- "Set up your first campaign using the templates in your kit"
- Next video: "TikTok Marketing for Property"

---

## Practical Exercise

**Assignment:** Create one Facebook ad campaign with 2 ad sets (different targeting). Run for 3 days at ₦2,000/day total budget. Report the results.

**Submission:** Screenshot of Ads Manager showing campaign results

---

## Budget Recommendation

| Daily Budget | Duration | Estimated Leads |
|---|---|---|
| ₦2,000 | 7 days | 15–30 |
| ₦5,000 | 7 days | 40–80 |
| ₦10,000 | 7 days | 80–160 |

## Resource Links

- Meta Business Suite: https://business.facebook.com
- Meta Ads Manager: https://adsmanager.facebook.com
- Meta Pixel Setup Guide: https://www.facebook.com/business/help/952192354298755
- Facebook Blueprint (free certification): https://www.facebook.com/business/learn
- Canva Ad Templates (use your kit templates)
