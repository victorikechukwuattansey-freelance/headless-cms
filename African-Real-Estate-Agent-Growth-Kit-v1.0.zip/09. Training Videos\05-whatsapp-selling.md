# Video 5: WhatsApp Selling & Automation

> **Length:** 20–30 minutes
> **Level:** All levels
> **Prerequisites:** WhatsApp Business app installed

---

## Learning Objectives

By the end of this video, the viewer will be able to:

1. Set up WhatsApp Business with a professional profile
2. Organize contacts with labels and broadcast lists
3. Create quick replies and automated responses
4. Send broadcast messages without getting blocked
5. Convert WhatsApp chats into property viewings and sales

---

## Script Outline

### Hook (0:00–0:30)

"In Nigeria, 9 out of 10 real estate conversations start on WhatsApp. But most agents use it like a personal chat app. Let me show you how to turn WhatsApp into your sales engine."

### Introduction (0:30–1:30)

- WhatsApp penetration in Africa (95%+ of smartphone users)
- Why WhatsApp Business is essential for agents
- What you'll be able to do after this video

### Main Content

#### Part 1: WhatsApp Business Setup (1:30–7:00)

1. Download WhatsApp Business (separate from WhatsApp)
2. **Profile setup:**
   - Business name: "[Your Name] — Real Estate Agent"
   - Profile photo: Professional headshot
   - Description: "Real estate agent specializing in [areas]. DM for viewing."
   - Address: Your office or agency location
   - Hours: Set business hours (not 24/7 — set boundaries)
   - Website: Link to your listings or Linktree
3. **Catalog feature:**
   - Add 5–10 current listings
   - Each with: photos, price, location, key features
   - Update weekly
4. **Screen recording:** Walk through the full WhatsApp Business setup

#### Part 2: Labels & Organization (7:00–10:00)

1. **Create label system:**
   - 🔥 Hot Lead (viewing scheduled this week)
   - 🧊 Cold Lead (interested, not urgent)
   - 📅 Viewing Done
   - ✅ Closed Deal
   - ❌ Not Interested
   - 📣 Broadcast Only
2. Label every new contact within 24 hours
3. Use search + labels to filter your contact list
4. **Exercise:** Create labels and categorize 10 existing contacts

#### Part 3: Quick Replies & Automation (10:00–15:00)

1. **Quick Replies** (saved message templates):
   - "Hi! Thanks for reaching out. Here are my current listings: [Link]. Let me know what you're looking for."
   - "This property is available for viewing this [day]. Shall I schedule you?"
   - "Price: ₦XX,XXX,XXX. Location: [Area]. I can send you more photos. Are you interested?"
2. Set up **Away Message** (outside business hours):
   - "Thanks for your message! I'm currently away. I'll respond to you as soon as I'm back during business hours (Mon–Sat, 9 AM – 6 PM)."
3. Set up **Greeting Message** (for new contacts):
   - "Hi {{contact_name}}! Welcome to [Your Name] Real Estate. How can I help you today? Looking to buy, sell, or rent?"
4. **Screen recording:** Create quick replies + automate greeting message

#### Part 4: Broadcast Lists (Not Groups!) (15:00–20:00)

1. Difference between broadcast lists and groups
2. **Create broadcast segments:**
   - Buyers looking for 2-bedroom flats
   - Buyers looking for 3-bedroom duplexes
   - Sellers (people who want to sell their property)
   - Past clients
3. **Broadcast etiquette:**
   - Maximum 1 broadcast per week per contact
   - Always use personalization ({{contact_name}})
   - Include clear CTA
   - Track who responds (they're your hot leads)
4. **Sample broadcast message:**
   - "Hi {{contact_name}}! New listing alert — 3-bedroom duplex in Lekki Phase 1. ₦85M. Full property tour video here: [Link]. Want to schedule a viewing?"
5. **What NOT to do:**
   - Don't add strangers to random groups
   - Don't send multiple messages without response
   - Don't send voice notes without asking first

#### Part 5: Closing on WhatsApp (20:00–27:00)

1. **The "Yes Ladder" conversation flow:**
   - "Are you looking to buy in [area]?" → Yes
   - "What's your budget range?" → [Budget]
   - "I have 3 properties that match. Can I send you photos?" → Yes
   - "When are you free for a viewing?" → Schedule
2. **Multimedia strategy:**
   - Send 2–3 best photos first (not all 20)
   - Send a 30-second video tour
   - Send location pin
3. **Objection handling via chat:**
   - "Price is too high" → Compare value, not defend price
   - "I want to think about it" → "What specifically are you unsure about?"
   - "I'll call you later" → "When works best? I'll follow up then."
4. **The follow-up sequence:**
   - After viewing → Same day: "How did you find the property?"
   - Day 2: Send similar property
   - Day 5: Check in ("Still searching?")
   - Day 14: Share market update
   - Keep the conversation alive without being pushy

### Key Takeaways (27:00–30:00)

1. WhatsApp Business is NOT your personal WhatsApp — keep it professional
2. Labels are your CRM — use them religiously
3. Quick Replies save hours every week — invest time setting them up
4. Broadcast lists build relationships — groups damage them
5. Every conversation should move toward a viewing or a "no"

### CTA

- "Set up your WhatsApp Business profile and create 3 quick replies"
- Next video: "Building Your Personal Brand"

---

## Practical Exercise

**Assignment:** Set up WhatsApp Business (if not done). Create labels, 3 quick replies, greeting message, and away message. Send 1 broadcast to a segmented list.

**Submission:** Screenshot of your WhatsApp Business profile + one quick reply setup

---

## WhatsApp Business Features Summary

| Feature | Purpose | Setup Time |
|---|---|---|
| Business Profile | Professional identity | 10 min |
| Catalog | Showcase listings in-app | 30 min |
| Labels | Organize contacts | 15 min |
| Quick Replies | Save templates | 20 min |
| Greeting Message | Welcome new contacts | 5 min |
| Away Message | After-hours response | 5 min |
| Broadcast Lists | One-to-many messaging | 10 min |
| Stars | Mark important messages | Instant |

## Resource Links

- WhatsApp Business: https://business.whatsapp.com
- WhatsApp Business Guide: https://faq.whatsapp.com/business
- Canva (create catalog images): https://www.canva.com
- WATI (WhatsApp automation tool for scaling): https://www.wati.io
