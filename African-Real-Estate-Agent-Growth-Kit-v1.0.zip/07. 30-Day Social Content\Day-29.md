# Day 29 — Monthly Review

## Post Type
Recap / reflection

## Caption Templates

**Template 1 — Stats recap**
{{Month}} in review 📊

🏡 Properties sold: {{X}}
💰 Total value: {{LocalCurrency}}{{Amount}}
👥 New clients: {{X}}
📸 Posts this month: {{X}}
💬 DMs received: {{X}}
🎯 Biggest lesson: {{Lesson}}

Every month is a step forward. {{Month}} was about {{theme}}. {{NextMonth}} is about {{nexttheme}}.

Thank you for following the journey. Let's make next month even bigger.

**Template 2 — Client wins**
This month, {{X}} families found their dream homes 🏡

Each one has a unique story, and I'm honoured to have been part of it. From first-time buyers to seasoned investors — watching my clients win is what keeps me going.

Highlights from {{Month}}:
- {{ClientWin1}}
- {{ClientWin2}}
- {{ClientWin3}}

Your story could be next month's highlight. Let's talk.

**Template 3 — Personal reflection**
{{Month}} was a blur — in the best way.

Between {{X}} property viewings, {{X}} closings, and countless conversations, I'm ending the month tired, grateful, and excited for what's next.

Here's what I'm carrying into {{NextMonth}}:
- Keep showing up
- Stay curious
- Serve first, sell second

What's one word to describe your {{Month}}? Drop it below 👇

## CTA
- DM me to be part of NEXT month's success stories
- Save this post and let's make {{NextMonth}} even better
- Drop one word that describes your {{Month}}

## Suggested Hashtags
#MonthlyReview #MonthInReview #RealEstateRecap #AfricanRealEstate #LagosAgent #NairobiRealtor #AccraRealEstate #GrowthMindset #BusinessRecap #Grateful

## Image Recommendation
A photo of you at your desk or in front of a property, looking accomplished. Or a graphic with key monthly stats (properties sold, value, etc.) in a clean infographic style.

## Story Idea
**"{{Month}} Highlights"** — 5-slide carousel. Each slide: one highlight from the month (a closing photo, a testimonial, a milestone). Use the celebration sticker. End slide: "{{NextMonth}} — DM me to be part of it."

## Reel Idea
**45-sec "{{Month}} Recap"** — Fast montage of clips and photos from the month: showings, closings, client meetings, behind-the-scenes. Upbeat, energetic track. Text overlay: "{{Month}} was..." → "{{X}} homes. {{X}} families. Countless memories." → "See you in {{NextMonth}}."
