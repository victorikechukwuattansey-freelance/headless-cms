# WhatsApp Broadcast Templates — African Real Estate Agent Growth Kit

> **Tool:** WhatsApp Business App (Free) or Broadcast API (Paid)
> **Best send time:** 10 AM – 12 PM or 4 PM – 6 PM local time
> **Frequency:** Maximum 2 broadcasts per week per contact (best practice)
> **Opt-out:** Include "Reply STOP to unsubscribe" in every broadcast

---

## Template 1 — Launch Announcement

**Goal:** Make a strong first impression and drive immediate sales

```
🔥 JUST LAUNCHED: African Real Estate Agent Growth Kit

{{FirstName}}, I'm excited to announce something I've been working on for months.

A complete digital toolkit designed specifically for African real estate agents who want to level up their online presence.

Here's what's inside:
🎨 40+ Canva Templates (editable, ready to post)
📱 30 Days of Social Media Content
📈 Facebook & TikTok Ad Creatives
💬 WhatsApp Scripts & Automation Templates
🎁 6 Lead Magnets to grow your email list

Normally ₦XX,XXX — Launch price: ₦XX,XXX

👉 {{CheckoutLink}}

Reply STOP to opt out.
```

**Best for:** Warm contacts who know you
**CTA:** Direct checkout link

---

## Template 2 — Limited-Time Offer

**Goal:** Create urgency with a countdown

```
⏰ 48 HOURS LEFT — Launch Discount Ends Soon

{{FirstName}}, the African Real Estate Agent Growth Kit launched at ₦XX,XXX but this price won't last.

After {{EndDate}}, the price increases to ₦XX,XXX.

If you've been thinking about upgrading your marketing, now is the time.

👉 {{CheckoutLink}}

Reply STOP to opt out.
```

**Best for:** Contacts who haven't purchased yet
**CTA:** Urgency-driven checkout link

---

## Template 3 — Social Proof Message

**Goal:** Leverage testimonials and FOMO

```
{{FirstName}}, over {{Count}} agents across Nigeria have already grabbed the African Real Estate Agent Growth Kit.

Here's what one agent said:

"Before this kit, I was spending 3+ hours every week designing posts from scratch. Now I just open Canva, pick a template, and my listing is ready in 10 minutes." — {{TestimonialName}}

Join your fellow agents who are saving time and closing more deals.

👉 {{CheckoutLink}}

Reply STOP to opt out.
```

**Best for:** Mid-funnel contacts who need proof
**CTA:** Social proof + checkout link

---

## Template 4 — Feature Spotlight

**Goal:** Highlight a specific valuable feature

```
{{FirstName}}, did you know the African Real Estate Agent Growth Kit includes ready-to-use Facebook Ad creatives?

Not just templates — actual ad copy + image designs that are optimized for Nigerian/Ghanaian property buyers.

Here's what you get:
📸 5 Carousel Ad Designs
✍️ 10 Ad Copy Variations (with hooks)
🎯 Targeting Guide for African Audiences
📊 Tracking Spreadsheet

One ad set can bring you 20+ qualified leads. This kit shows you exactly how.

👉 {{CheckoutLink}}

Reply STOP to opt out.
```

**Best for:** Contacts who need specific feature details
**CTA:** Feature-focused checkout link

---

## Template 5 — Urgency Close

**Goal:** Final push to convert remaining leads

```
🎯 {{FirstName}}, I noticed you haven't grabbed the African Real Estate Agent Growth Kit yet.

I built this because I know how hard it is to:
→ Create content consistently
→ Design professional graphics from scratch
→ Write ad copy that actually converts
→ Set up lead magnets that bring in clients

This kit solves ALL of that. Ready in 10 minutes.

Last chance at this price.

👉 {{CheckoutLink}}

Reply STOP to opt out.
```

**Best for:** Final touchpoint before moving to cold list
**CTA:** Empathy-driven urgency close

---

## Broadcast Best Practices

### Personalization
- Always use `{{FirstName}}` — messages without names have 30% lower open rates
- Segment your list before broadcasting (warm vs. cold, past buyers vs. never-bought)
- If possible, reference past interactions: "{{FirstName}}, you asked about..."

### Timing Rules
- **Monday–Friday:** 10 AM – 12 PM, 4 PM – 6 PM
- **Saturday:** 11 AM – 2 PM
- **Sunday:** Avoid broadcasts (reserved for personal/family time)
- Maximum **1 broadcast per week** to the same contact

### Compliance Checklist
- [ ] Template approved by Meta before sending
- [ ] Recipients have opted in to your broadcast list
- [ ] "Reply STOP to opt out" included in message
- [ ] Opt-out processing system in place
- [ ] Sender identity is clear (your business name)
- [ ] Link uses a branded short URL (not raw checkout link)

### Segmentation Ideas
| Segment | Message | CTA |
|---|---|---|
| Past buyers | "You already own the kit — share with a friend and earn {{Commission}}" | Referral link |
| Website visitors | "You visited my site — here's what you missed" | Feature spotlight |
| Social followers | "You follow me on {{Platform}} — grab the kit at launch price" | Urgency close |
| Email subscribers | "You're on my email list — WhatsApp exclusive offer inside" | Discount link |
