# Day 21 — Property Tour

## Post Type
Virtual walkthrough / video tour

## Caption Templates

**Template 1 — Full tour**
Come inside — let's take a tour of this beautiful {{PropertyType}} in {{PropertyLocation}} 🏡✨

From the moment you walk in, you're greeted by {{feature}}. The {{Bedrooms}} bedrooms are spacious and filled with natural light. The kitchen is {{description}}. And the outdoor space? Perfect for {{activity}}.

Priced at {{ListingPrice}}. DM me to schedule your private viewing.

**Template 2 — Highlight reel**
3 reasons this {{PropertyLocation}} property won't last long:

1️⃣ Location — walking distance to {{amenity}}
2️⃣ Layout — {{Bedrooms}} beds, open-plan living
3️⃣️ Value — {{ListingPrice}} for this quality

Watch the full tour and tell me: which room is your favourite? 👇

**Template 3 — First look**
FIRST LOOK 🔥 This just hit the market — and I had to show you before anyone else.

{{Bedrooms}}-bedroom {{PropertyType}} in {{PropertyLocation}}
✨ Brand new listing
✨ {{KeyFeature1}}
✨ {{KeyFeature2}}
✨ {{KeyFeature3}}

Full video tour attached. DM me "TOUR" for more details.

## CTA
- DM me "VIEW" to book your in-person tour
- Comment which room you loved most
- Save this post — this one won't last

## Suggested Hashtags
#PropertyTour #VirtualTour #HomeWalkthrough #AfricanRealEstate #LagosProperties #NairobiHomes #AccraRealEstate #HouseTour #DreamHome #RealEstateVideo

## Image Recommendation
A video thumbnail or the most impressive angle of the property. Wide shot of the living room or the exterior facade. Bright, inviting, high resolution.

## Story Idea
**"Room by Room"** — 5-slide story. Each slide features one room with a "Swipe for more" prompt. Include a "DM for price" sticker on each slide. Last slide has a "Book a viewing" link sticker.

## Reel Idea
**60-sec cinematic tour** — Smooth walkthrough: Enter front door → living room → kitchen → bedrooms → bathroom → outdoor space. Slow, deliberate camera movement. Text overlay shows room names. Ambient or chill lounge music. End with your name and "DM for details."
