# Day 22 — Legal Advice

## Post Type
Educational / property law guidance

## Caption Templates

**Template 1 — Document checklist**
Before you buy any property in {{Country}}, make sure you have these documents checked:

📄 **Certificate of Occupancy (C of O)** — Confirms legal ownership rights
📄 **Survey Plan** — Shows exact boundaries and measurements
📄 **Deed of Assignment** — Transfers ownership from seller to buyer
📄 **Consent from Governor/Ministries** — Required in some states
📄 **Tax Clearance** — Seller must be up-to-date

Missing any of these? Proceed with caution. DM me "LEGAL" for a full guide.

**Template 2 — Common legal pitfalls**
3 legal mistakes that cost people their property:

⚖️ Buying family land without verifying the true owner
⚖️ Accepting a "receipt" instead of a registered deed
⚖️ Not doing a land registry search before payment

These mistakes are common — but they're also avoidable. Work with a registered agent who knows the law. Your investment is worth protecting.

**Template 3 — Why you need a lawyer**
"I'll just use the agent's lawyer to save money." — Said someone who later had a legal problem.

Here's the truth: A good real estate agent will RECOMMEND you get your own lawyer. Not because we don't want to help — but because your interests deserve independent representation.

A lawyer costs a fraction of what you could lose. Don't skip this step.

## CTA
- DM me "LEGAL" for a property legal checklist PDF
- Save this post for your reference
- Tag someone buying property soon

## Suggested Hashtags
#PropertyLaw #LegalAdvice #AfricanRealEstate #LandLaw #LagosProperty #NairobiRealEstate #AccraProperty #DocumentCheck #PropertyRights #RealEstateLegal

## Image Recommendation
Photo of legal documents, a stamp, and a pen on a desk. Or a photo of you with a lawyer or at a land registry. Professional, serious, authoritative.

## Story Idea
**"Document or No Document?"** — Quick quiz. Show a document type (e.g., "Receipt from the seller's brother"). Users vote "Valid" or "Not Valid." Reveal the answer with an explanation. 3 rounds, educational but light.

## Reel Idea
**60-sec "3 Documents You MUST Have Before Buying"** — Hold up each document (or a mock-up): C of O, Survey Plan, Deed of Assignment. Explain what each one is in 15 seconds. Direct-to-camera, serious but friendly. Text overlays with document names.
