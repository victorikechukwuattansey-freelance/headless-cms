# Template Build Guide

**Build all 300+ Canva templates — step by step.**

---

## Canva Toolkit

Master these before you start building.

### Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl + D` | Duplicate selected element(s) |
| `Ctrl + G` | Group selected elements |
| `Ctrl + Shift + G` | Ungroup |
| `Ctrl + L` | Lock/unlock element |
| `Ctrl + ]` | Move element forward |
| `Ctrl + [` | Move element backward |
| `Shift + drag` | Maintain proportions while resizing |
| `Alt + drag` | Duplicate while dragging |
| `Ctrl + A` | Select all |

### Essential Techniques

**Grids & Guides:**
- Drag from the left ruler to create vertical guides
- Drag from the top ruler to create horizontal guides
- Use guides to align elements across slides

**Image Masking:**
- Upload your photo
- Click the photo, then click **"Crop"**
- Choose a shape mask (circle for headshots, rectangle with rounded corners for feature images)

**Text Styles:**
- Format a heading exactly how you want it
- Click the text box, then the paint roller icon
- Click another text to apply the same style

**Color Palette:**
- After setting Brand Kit (see Canva-BrandKit-Setup.md), your 5 colors appear in the color panel
- Click any color swatch to apply
- Use **"Color extractor"** tool to match colors from uploaded images

---

## Property Flyers

All flyers follow the same base construction. Instructions below cover the structure; variant-specific notes follow.

### Base Recipe (used for ALL 8 flyer types)

```
Step 1 — New Document
   Action: Click "Create a design" → "A4" (2480 × 3508 px)
   Tip: Set up one master flyer, then duplicate for other types.

Step 2 — Background Layer
   Shape: Rectangle, 2480 × 3508 px
   Fill: Cream (#F5F0E8)
   Lock: Ctrl + L

Step 3 — Hero Image Area
   Upload: Your property photo
   Resize: Width 2480 px, height ~1750 px (top 50%)
   Position: Align top edge
   Mask: Optional — use a rounded rectangle mask for a softer feel

Step 4 — Overlay Badge
   Shape: Rectangle, 300 × 90 px
   Fill: Gold (#C9A84C)
   Rotate: -3° (use rotation handle above shape)
   Position: Top-left, about 60 px from edges
   Text: Add heading text (Playfair Display Bold, 32 pt, Charcoal #2D2D2D)

Step 5 — Property Title
   Text field: Property name/address
   Font: Playfair Display Bold, 36 pt
   Color: Charcoal (#2D2D2D)
   Position: Below hero image, left-aligned, 60 px from left

Step 6 — Price
   Text field: Price with currency (e.g., "KES 45,000,000")
   Font: Playfair Display Bold, 26 pt
   Color: Gold (#C9A84C)
   Position: Below title

Step 7 — Stats Row (4 icons)
   Create one stat block:
     - Icon: Small rectangle 80 × 80 px, Olive (#7B8D5D), rounded corners 10 px
     - Label: Lato Bold, 14 pt, Charcoal
     - Value: Lato Bold, 20 pt, Charcoal
   Group (Ctrl + G) the icon + label + value
   Duplicate 3 times (Ctrl + D)
   Arrange horizontally with 40 px spacing
   Position: Below price

Step 8 — Feature Bullets
   Text list: 3-5 features
   Bullet style: Use "✦" or "●" in Gold or Olive
   Font: Lato Regular, 14 pt, Charcoal
   Position: Below stats row, 60 px left margin

Step 9 — Agent Footer
   Shape: Rectangle, 2480 × 180 px
   Fill: Charcoal (#2D2D2D)
   Position: Bottom of page
   Add headshot: Circle crop, 80 × 80 px, position left
   Add name: Lato Bold, 16 pt, Cream (#F5F0E8)
   Add phone/email: Lato Regular, 12 pt, Cream
   Add logo: Bottom-right, 100 × 60 px

Step 10 — Review & Export
   Check alignment with guides
   Group all elements (Ctrl + A, Ctrl + G)
   Save as template: File → Save as brand template
   Export: Share → Download → PDF Print (for print) or PNG (for digital)
```

### 1. Luxury Home Flyer

**Badge text:** "LUXURY LIVING"
**Price position:** Center-aligned, larger (32 pt)
**Color emphasis:** Gold throughout
**Back side:** Add agent bio section (left: photo, right: 3-4 sentence bio), floor plan placeholder, QR code
**Pro tip:** Use a warm filter on the hero image to match the Gold/Terracotta palette

### 2. Apartment Flyer

**Badge text:** "NEW LISTING" — Terracotta (#C26A4A) background
**Amenities grid:** 2×3 layout below stats — use icons (Pool, Parking, Gym, Security, Garden, WiFi)
**Icon source:** Canva Elements → Graphics → search each icon
**Color:** Olive (#7B8D5D) icons, Charcoal labels
**Contact:** Add WhatsApp number prominently

### 3. Land Flyer

**Badge text:** "PRIME LAND" — Gold background
**Hero image:** Use an aerial/drone photo if available
**Plot dimensions card:** Create a card (Cream bg, Charcoal border 2 px, rounded corners 15 px) with plot size, title type, zoning
**Location highlights:** Use Olive checkmark icons
**Map:** Add a "Get Directions" button or map placeholder

### 4. Commercial Flyer

**Badge text:** "COMMERCIAL SPACE" — Terracotta background
**Features:** Total area, frontage, parking bays, floors, lifts — use Olive icon + number format
**Investment highlights section:** Use Gold upward-trend icons with bullet points
**CTA:** "Schedule a Viewing" button, Terracotta bg, Cream text

### 5. Rental Flyer

**Badge text:** "FOR RENT" — Terracotta background (left side)
**Price badge:** Gold background, right side (overlaid on image)
**Price format:** Monthly (e.g., "KES 45K/mo")
**Key stat:** Add "Furnished/Unfurnished" as 4th stat
**Amenities:** Water included, security estate, parking, nearby shopping
**Contact buttons:** Create two rounded buttons — "[Call]" (Terracotta) and "[WhatsApp]" (Olive)

### 6. Just Listed Flyer

**Badge:** "NEW ON THE MARKET" — Large diagonal badge, Gold bg, rotated -5°, placed over image center
**Star bullets:** Use Gold star icon "✦" for 3 featured highlights
**Date:** Add "Listed [Date]" in Olive italic
**Urgency:** Add "Just Listed" stamp element

### 7. Sold Flyer

**SOLD stamp:** Large Charcoal (#2D2D2D) rectangle over hero image center, rotated -5°, with "SOLD!" in Playfair Display Bold 72 pt, Gold (#C9A84C) text
**Subtitle:** "Another Happy Client Served" — Lato Bold, 24 pt, Cream
**Previous price:** Add original price with strikethrough (Lato Regular, 50% opacity)
**Sold price:** Gold, 30 pt, Playfair Bold
**Days on market:** Olive, "Sold in just 14 days"
**Testimonial:** Playfair Display Italic, 22 pt, center-aligned
**CTA button:** "Looking to buy or sell? Call now!" — Terracotta button, 60 px padding

### 8. Open House Flyer

**Badge:** "OPEN HOUSE" — Gold bg, top-left
**Sub-badge:** "THIS SUNDAY" — Terracotta text below badge
**Date & time:** Large, bold — Playfair Display 32 pt for day, Lato 20 pt for time
**Refreshments card:** Create a card with wine/cheese icon and "Refreshments Provided" text — Cream bg, Terracotta border
**Event highlights:** 4 items with icons (tour, meet agent, market info, financing)
**RSVP:** Phone + WhatsApp, plus QR code for event registration

---

## Instagram Templates

### Carousel Posts (50 total — 10 types × 5 variations)

**Base dimensions:** 1080 × 1080 px, RGB, 72 DPI

#### Carousel Base Recipe

```
Step 1 — New Document
   Action: Click "Create a design" → "Instagram Post" (1080 × 1080 px)

Step 2 — Create Cover Slide
   Background: Full-bleed image or Cream (#F5F0E8) solid
   Overlay text (if on image):
     - Add a semi-transparent Charcoal rectangle overlay (50% opacity)
     - Reduces to taste: adjust opacity to ensure text readability
   Title: Playfair Display Bold, 52 pt, centered
   Subtitle: Lato Regular, 20 pt
   Badge: Top-left, Terracotta or Gold
   Page number: Bottom-right, "1/5"

Step 3 — Create Content Slides (2-4)
   Repeat for each slide with different content.
   Use "Duplicate page" (top bar) to copy the slide, then edit elements.
   Layout options:
     - Split: Image top 60%, text bottom 40% (Cream bg)
     - Side-by-side: Image left 50%, text right 50% (Cream bg)
     - Full-image: Full-bleed image with text overlay

Step 4 — Create CTA Slide (last slide)
   Background: Charcoal (#2D2D2D)
   Agent photo: Circle crop, 120 × 120 px, center
   CTA text: "Want a viewing?" or "Book a consultation"
   Button: Terracotta rectangle with "Call Now" or "DM Me"
   Contact: Phone, WhatsApp, email — Lato Regular, 16 pt, Cream

Step 5 — Duplicate for Variations
   Create one carousel set completely
   Use "File → Make a copy" to create variations
   Swap images and text for each property type
```

#### Carousel Type Variations

**Type A — Residential House**
- Cover: Exterior hero shot with "JUST LISTED" badge, price
- Slide 2: Garden/backyard, family features
- Slide 3: Living room, 3 feature bullets
- Slide 4: Neighborhood highlights (schools, parks, shopping)
- Slide 5: Agent CTA with family-oriented copy

**Type B — Luxury Apartment**
- Cover: Skyline view or rooftop pool, "LUXURY LIVING" badge
- Slide 2: Interior premium finishes (kitchen, bathroom)
- Slide 3: Building amenities (pool, gym, concierge)
- Slide 4: Location benefits (fine dining, nightlife, views)
- Slide 5: Agent CTA with exclusive/invitation tone

**Type C — Land/Plot**
- Cover: Aerial drone shot, "PRIME LAND" badge
- Slide 2: Dimensions card with plot details
- Slide 3: Location map with nearby landmarks
- Slide 4: Investment potential (appreciation, development)
- Slide 5: Agent CTA for site inspection

**Type D — Commercial**
- Cover: Building facade, "COMMERCIAL SPACE" badge
- Slide 2: Property specs (area, parking, floors)
- Slide 3: Investment metrics (ROI, lease rates)
- Slide 4: Foot traffic/demographics data
- Slide 5: Agent CTA for business buyers

**Type E — Rental**
- Cover: Interior hero, "FOR RENT" + monthly price
- Slide 2: Room-by-room tour (bedroom, kitchen, living)
- Slide 3: Amenities grid
- Slide 4: Neighborhood lifestyle (cafes, transport)
- Slide 5: Agent CTA — "Book a viewing"

**Types F-J (Market Updates, Tips, Testimonials, Neighborhood Guides, Agent Branding)**
- Follow the same 5-slide structure
- Adjust content type per the category

### Story Templates (50 total — 10 types × 5 variations)

**Dimensions:** 1080 × 1920 px, 9:16

#### Story Base Recipe

```
Step 1 — New Document
   Action: "Create a design" → "Instagram Story" (1080 × 1920 px)

Step 2 — Background
   Full-bleed image or solid Cream (#F5F0E8)
   If using image: Add Charcoal gradient overlay (bottom to top, 60% opacity)
     How: Add a rectangle, fill with gradient (Charcoal to transparent),
     position from bottom to middle

Step 3 — Main Text
   Font: Playfair Display Bold, 48-60 pt
   Color: Cream (on images) or Charcoal (on Cream backgrounds)
   Position: Center or slightly above center
   Max words: 8-10 words for quick reading

Step 4 — Subtext
   Font: Lato Regular, 22-28 pt
   Color: Cream or Olive
   Position: Below main text

Step 5 — CTA / Contact
   "Swipe up" or "Link in bio" text — Olive, 18 pt
   Agent name and logo at top or bottom
   Page number: Top-right, e.g., "2/5"

Step 6 — Interactive Element (optional)
   Poll sticker: "Which property style do you prefer? Modern vs Classic"
   Question sticker: "Ask me about this property"
   Quiz sticker: "Guess the price of this home"
```

#### Story Type Content Guide

- **Property Showcase:** Single property, 3-5 story slides (exterior, interior, key features, price, CTA)
- **Quote Story:** Single quote, large text, agent branding at bottom
- **Poll Story:** Market question, two-option poll, results discussion
- **Q&A Story:** "Ask me anything about buying in [City]" with question sticker
- **Countdown:** "Open House in 3 days" countdown sticker
- **Featured Listing:** Carousel-style, swipe through highlights
- **Client Spotlight:** Photo + testimonial text
- **Market News:** Single stat highlight (e.g., "+12.4% YoY")
- **Tip of the Day:** Single actionable tip, large text
- **Behind the Scenes:** Agent photo + personal caption

### Quote Graphics (30 total)

**Dimensions:** 1080 × 1080 px

```
Step 1 — New Document
   "Create a design" → "Instagram Post" (1080 × 1080 px)

Step 2 — Background
   Option A: Cream (#F5F0E8) solid with subtle pattern (use Elements → Grids)
   Option B: Charcoal (#2D2D2D) solid for dramatic quotes
   Option C: Terracotta (#C26A4A) to Olive (#7B8D5D) gradient

Step 3 — Quote Text
   Font: Playfair Display Italic, 36-44 pt
   Color: Charcoal (on light bg) or Cream (on dark bg)
   Alignment: Center
   Quotation marks: Add large quote marks " " in Gold (#C9A84C) at 80 pt, 30% opacity

Step 4 — Attribution
   Font: Lato Bold, 16 pt
   Color: Gold or Olive
   Position: Below quote
   Format: "— [Agent Name]"

Step 5 — Branding
   Logo: Bottom-right, 60 × 60 px, 50% opacity
   Website: Bottom-center, Lato Regular, 12 pt
```

**30 Quote Topics:**
1. "Home is not a place, it's a feeling."
2. "The best investment is in the place you call home."
3. "Your dream home is closer than you think."
4. "Real estate is not about square feet — it's about the life you build inside."
5. "Don't wait for the perfect property. Find the right one and make it perfect."
6-30: Mix of real estate wisdom, investment advice, home ownership inspiration, and African market-specific quotes

### Market Update Templates

**Dimensions:** 1080 × 1080 px

**Structure:**
1. Cover slide: Big number headline "+12.4%" + "Market Update" + city name
2. Price trends: Line graph (draw with curved line tool) + YoY change
3. Inventory stats: Two-column layout — new listings vs sold
4. Days on market: Bold number card
5. CTA: "DM me for a free home valuation"

**How to draw the line graph:**
- Use Elements → Lines → Curved line
- Draw a rising trend line in Gold (#C9A84C)
- Add data points as small circles (Olive #7B8D5D)
- Label with Lato Bold, 14 pt

### Testimonial Graphics

**Dimensions:** 1080 × 1080 px

**Structure:**
- Client photo (circle crop, 140 × 140 px, top center)
- Star rating (5 Gold stars in a row)
- Quote text (Playfair Display Italic, 28 pt)
- Client name + location (Lato Bold, 16 pt, Olive)
- Agent branding footer

---

## Facebook Templates

### Cover Photos (3 types)

**Dimensions:** 1640 × 856 px

```
Step 1 — New Document
   "Create a design" → "Custom size" → 1640 × 856 px

Step 2 — Background
   Full-bleed image or brand-colored gradient
   Remember: Profile picture and buttons overlap the bottom-right corner
   Keep important content in the safe zone (center 70%)

Step 3 — Text Placement
   Headline: Playfair Display Bold, 36 pt, centered
   Subtitle: Lato Regular, 18 pt
   Position all text in the top-center safe zone

Step 4 — Branding
   Logo: Bottom-left, 80 × 80 px
   Tagline: Bottom-left next to logo, Lato Regular, 14 pt
```

**Types:**
- **Agent Profile:** Agent photo (right side), name + title + tagline (left), branded background
- **Property Showcase:** Hero property image, "Featured Listing" badge, price overlay
- **Open House:** Event details, date/time overlay, branded background

### Property Banners

**Dimensions:** 1200 × 628 px

Same recipe as covers but with more text space. Used for:
- **Listing highlights:** Property photo + key stats + CTA
- **Featured properties:** Grid layout showing 3-4 properties with prices
- **Just Sold:** Sold badge + testimonial + agent branding

### Event Promotions

**Dimensions:** 1200 × 628 px

- Event name + date/time at top
- Compelling imagery (property or lifestyle)
- "Register Now" CTA button (Terracotta)
- Event details in the description section

---

## LinkedIn Templates

### Agent Branding Posts

**Dimensions:** 1200 × 627 px

**Structure:**
- Professional headshot (large, right or left side)
- Bold headline in Playfair Display
- Achievement highlight (e.g., "Closed 50+ properties in 2025")
- 2-3 credibility stats with Olive icons
- Personal philosophy quote or mission statement
- CTA: "Let's connect" or "DM me for real estate advice"

**How to build:**
1. Background: Cream, with a Charcoal accent strip on the left (120 px wide)
2. Headshot: Circular crop, 300 × 300 px, positioned right
3. Name: Playfair Display Bold, 36 pt, Charcoal, left-aligned
4. Stats row: 3 boxes with numbers (e.g., "50+ Closed", "5★ Rating", "10+ Years")
5. CTA: Terracotta button with white text

### Market Reports

**Dimensions:** 1200 × 627 px

**Structure:**
- Title: "Market Report — [City] [Month/Year]"
- Big stat number (e.g., "+12.4%")
- 4 stat cards in a 2×2 grid (Avg Price, DOM, Inventory, Sold)
- Mini graph/trend line (Gold line on Olive grid)
- Agent branding footer

**How to build:**
1. Background: Charcoal (#2D2D2D) for premium feel
2. Title: Playfair Display Bold, 28 pt, Cream
3. Big number: Playfair Display Bold, 72 pt, Gold
4. Stat cards: Cream card with rounded corners, Charcoal text, Olive accent line
5. Graph: Use line tool + small circles for data points

---

## Business Templates

### Business Cards

**Dimensions:** 1050 × 600 px (3.5 × 2 in at 300 DPI)
**Bleed:** 0.125 in all sides
**Safe zone:** 0.25 in from edges

**Front layout:**
- Left 40%: Charcoal (#2D2D2D) background
  - Logo centered (150 × 150 px max)
  - Small Olive accent line below logo
- Right 60%: Cream (#F5F0E8) background
  - Agent name: Playfair Display Bold, 24 pt, Charcoal
  - Title: Lato Regular, 12 pt, Terracotta
  - Brokerage: Lato Regular, 11 pt, Olive
  - Contact info: Lato Regular, 10 pt, Charcoal
  - Icons: Small circles in Gold for phone, email, web

**Back layout:**
- Full Cream background
- Centered tagline or service list
- QR code (bottom-right corner)
- Social media handles (bottom, in a row)

### Email Signature

**Create in Canva or use HTML directly.**

**Canva method:**
1. Create a custom design: 600 × 300 px
2. Background: Transparent
3. Layout:
   - Left: Headshot (circle crop, 60 × 60 px)
   - Top: Agent name (Playfair Display Bold, 16 pt, Charcoal)
   - Below: Title + Brokerage (Lato Regular, 11 pt, Terracotta)
   - Below: Phone | Email | Website (Lato Regular, 10 pt, Olive)
   - Bottom: Small Gold accent line + logo
4. Export as PNG, upload to Gmail/Outlook

### Letterhead

**Dimensions:** 2550 × 3300 px (A4)

**Structure:**
- Header: Logo (left) + Agent name + Tagline + Contact info (right) — separated by Gold accent line
- Body: Cream background, generous white space for content
- Footer: Charcoal strip with phone, email, website, brokerage address

### Invoice

**Dimensions:** 2550 × 3300 px (A4)

**Structure:**
- Header: Same as letterhead
- Invoice details: Invoice #, Date, Client name (Lato Bold, 14 pt)
- Itemized table:
  - Header row: Charcoal bg, Cream text (Description | Amount | Total)
  - Data rows: alternating Cream and light Charcoal (10% opacity)
  - Total row: Gold bg, Charcoal text, Bold
- Payment terms: Lato Regular, 10 pt, footer
- Bank details: If applicable for African market (bank name, account #, sort code)

### Proposal

**8-page document, full color.**

**Page 1 — Cover:**
- Full-bleed Charcoal bg
- "PROPOSAL" in Gold, large
- Property name, client name, date
- Agent logo bottom-right

**Page 2 — About the Agent:**
- Headshot + bio
- Credentials and experience
- Previous sales stats

**Page 3 — Property Details:**
- Photos + specs table
- Key features with icons

**Page 4 — Market Analysis:**
- Comparable sales
- Market trends
- Pricing recommendation

**Page 5 — Marketing Plan:**
- Channels (Instagram, Facebook, TikTok, WhatsApp)
- Sample ad mockups
- Timeline

**Page 6 — Pricing Tiers:**
- 3 marketing packages (Basic, Standard, Premium)
- Each with price and included services
- Gold highlight on recommended tier

**Page 7 — ROI Projection:**
- Expected time to sell
- Projected sale price range
- Agent commission structure

**Page 8 — CTA / Next Steps:**
- "Ready to get started?"
- Agent contact information
- QR code to portfolio
- Signature lines

**How to build proposals:**
- Use Canva's "Proposal" template as a starting point
- Override with brand colors
- Replace fonts with Playfair Display + Lato
- Each page is a separate page in the same design
- Export as PDF for client delivery

---

## Batch Production Workflow

To create all 300+ templates efficiently:

1. **Build one master per category** — Create a perfect flyer, one carousel set, one story
2. **Duplicate** — Use "File → Make a copy" for each variation
3. **Swap assets** — Replace images, adjust text, update prices
4. **Use pages** — Keep all flyers in one design with separate pages
5. **Name pages** — Right-click page thumbnails to rename (e.g., "Luxury-Front", "Luxury-Back")

### Production Order (Quickest to Build)

1. Business stationery (6 designs, high reuse)
2. Quote graphics (30 designs, same template)
3. Story templates (50 designs, 10 base layouts)
4. Facebook templates (15 designs, 3 base layouts)
5. LinkedIn templates (12 designs, 2 base layouts)
6. Property flyers (8 designs with front + back)
7. Instagram carousels (50 designs, 10 base layouts)

---

## Export Settings

| Use Case | Format | Settings |
|----------|--------|----------|
| Print (flyers, cards, letterhead) | PDF Print | CMYK, 300 DPI, crop marks |
| Social media posts | PNG | RGB, 72 DPI, transparent bg if needed |
| Email signature | PNG | RGB, 72 DPI, transparent bg |
| Website use | JPG | RGB, 72 DPI, 80% quality |
| Proposal | PDF | RGB or CMYK, 300 DPI, flatten PDF |
