# Seller Preparation Guide — How to Prepare Your Property for Sale

> **Target audience:** Homeowners preparing to sell their property
> **Format:** Print-ready PDF / Digital download
> **Goal:** Help sellers maximize their property value and sell faster

---

## Introduction

A well-prepared home sells **40% faster** and for **5–15% more** than one sold "as-is." This guide walks you through every step of preparing your property for the market.

**Estimated preparation timeline:** 4–8 weeks

---

## Section 1: Pricing Strategy

### Step 1: Research Comparable Sales

- [ ] Identify 5–10 similar properties sold in your area in the last 6 months
- [ ] Compare: size (sqm), bedroom count, age, condition, amenities
- [ ] Note the **selling price** (not asking price) of each comparable
- [ ] Adjust for differences — your property may be worth more or less based on condition, upgrades, location

### Step 2: Get a Professional Valuation

- [ ] Hire a certified valuer (Nigerian Institution of Estate Surveyors and Valuers — NIESV)
- [ ] Cost: Typically ₦50,000–₦150,000 depending on property value
- [ ] Use the valuation report to set a **data-driven asking price**

### Step 3: Set Your Price

| Strategy | Description | Best For |
|---|---|---|
| **Market price** | Price at fair market value based on comparables | Quick sale, standard property |
| **Premium price** | 5–10% above market to leave room for negotiation | Unique properties, hot market |
| **Competitive price** | 5–10% below market to attract multiple offers | Seller needs quick sale |
| **Price ladder** | Start high, reduce by 5% every 2–3 weeks | Seller has time to wait |

**Recommended:** Price at market value or slightly below to generate competition. Overpricing leads to stale listings that sell for less.

---

## Section 2: Home Staging

Staging helps buyers visualize themselves living in the property. It doesn't have to be expensive.

### Living Room

- [ ] Declutter — remove personal items, excess furniture, stacks of papers
- [ ] Deep clean — walls, ceiling, fans, windows, floors
- [ ] Neutral paint — repaint if walls are bold colors (go with cream, off-white, light grey)
- [ ] Arrange furniture to maximize space (remove oversized pieces)
- [ ] Let in natural light — open curtains, clean windows inside and out
- [ ] Add fresh flowers or a plant (creates life in the room)
- [ ] Repair any visible damage (holes in walls, cracked tiles, leak marks)

### Kitchen

- [ ] Clear countertops — leave only coffee maker, fruit bowl, or decorative item
- [ ] Empty the sink — no dishes, no sponge, no dish rack
- [ ] Clean cabinets inside and out — no sticky residue
- [ ] Organize pantry — less clutter, more space perception
- [ ] Replace worn cabinet handles (cheapest upgrade with highest ROI)
- [ ] Fix dripping taps — buyers test everything
- [ ] Ensure all lights work — replace burnt bulbs

### Bedrooms

- [ ] Remove personal photos and items — buyers need to imagine THEIR life here
- [ ] Minimal furniture — bed, nightstand, lamp is enough
- [ ] Neutral bedding — white or cream linen
- [ ] Clear closet floors — organized closets look bigger
- [ ] Remove shoes, laundry, clutter from visible areas

### Bathrooms

- [ ] Deep clean — tiles, grout, toilet, shower, mirror — everything spotless
- [ ] Remove personal toiletries from visible areas
- [ ] Fresh towels — neatly hung, matching set
- [ ] Fix caulking around bathtub/shower — replace if moldy
- [ ] Check toilet — no running water, clean base
- [ ] Good lighting — bright == clean

### Exterior / Curb Appeal

- [ ] Mow lawn and trim hedges
- [ ] Sweep driveway and walkways
- [ ] Paint or wash the front gate
- [ ] Ensure house number is visible
- [ ] Fix any exterior lights
- [ ] Add potted plants at the entrance
- [ ] Remove trash bins from view during viewings
- [ ] Check — is the property visible from the road? Clear any obstructions

---

## Section 3: Minor Repairs (High ROI)

Focus on repairs that give the best return. You don't need to renovate the entire house.

### Priority 1 — Safety & Structural (Fix These First)

- [ ] Exposed electrical wires — enclose them
- [ ] Leaking pipes — fix all before listing
- [ ] Broken window panes — replace
- [ ] Cracked or broken tiles in walkways — replace
- [ ] Loose handrails — secure them
- [ ] Broken locks on external doors — fix or replace

### Priority 2 — Visible Defects (Buyers Notice These)

- [ ] Peeling paint — touch up all visible areas
- [ ] Cracked caulk in bathrooms — reapply
- [ ] Stained ceiling — repaint (fix the leak first)
- [ ] Scuffed baseboards — clean or repaint
- [ ] Worn door handles — replace (inexpensive)
- [ ] Sticking doors — sand or adjust hinges
- [ ] Burned-out light bulbs — replace all (use warm white bulbs)

### Priority 3 — African-Specific Repairs

- [ ] **Generator:** Service it — clean oil filter, fresh oil, new spark plugs
- [ ] **Inverter:** Check battery levels, clean solar panels, tighten connections
- [ ] **Borehole:** Test water quality, service pump, check pressure tank
- [ ] **Water tank:** Clean tank, check for algae, repair any leaks
- [ ] **Septic tank:** Empty if near full — bad smell is a dealbreaker
- [ ] **CCTV / Security:** Verify cameras are working and recording

---

## Section 4: Professional Photography

**90% of buyers decide whether to view a property based on photos.** This is not an area to cut corners.

### Booking a Photographer

- [ ] Hire a real estate photographer (not a wedding photographer — different skills)
- [ ] Verify portfolio — look for wide-angle shots, natural lighting, property exteriors
- [ ] Cost in Nigeria: ₦30,000–₦80,000 for a 3-bedroom flat (including edits)
- [ ] Schedule shoot during **golden hour** (sunrise or sunset) for exterior shots
- [ ] Virtual tour / videography: ₦50,000–₦150,000 additional (highly recommended)

### Pre-Shoot Checklist

- [ ] Property is staged (see Section 2 above)
- [ ] All repairs made
- [ ] All lights are on (replace any burnt bulbs)
- [ ] Curtains/blinds open for natural light
- [ ] AC off (noise interferes with video recording)
- [ ] Cars removed from driveway
- [ ] Neighbors informed — no noisy construction on shoot day
- [ ] Pets removed from property during shoot
- [ ] Walk through with photographer before they start — point out best features

---

## Section 5: Documentation Preparation

Have all documents ready before listing. Delays in document availability lose deals.

### Title Documents

- [ ] Certificate of Occupancy (C of O) — original or certified true copy
- [ ] Survey Plan — recent and registered
- [ ] Deed of Assignment / Conveyance
- [ ] Governor's Consent (if applicable)
- [ ] Building Plan Approval
- [ ] Land Use Charge receipts (Lagos)
- [ ] Ground rent receipts

### Financial Documents

- [ ] Recent property tax receipts
- [ ] Utility bills (electricity, water) — show average monthly cost
- [ ] Estate service charge records
- [ ] Generator/inverter maintenance records (shows care)
- [ ] Borehole water quality test (if applicable)

### Marketing Documents

- [ ] Floor plan (drawn to scale, showing room dimensions)
- [ ] Features sheet (all amenities, finishes, appliances)
- [ ] Neighborhood guide (schools, hospitals, markets, transport)
- [ ] Disclosure statement (known defects you must legally disclose)

---

## Section 6: Marketing Timeline

| Week | Activity |
|---|---|
| **Week 1–2** | Pricing strategy, valuation, documentation preparation |
| **Week 3** | Home staging, minor repairs, deep cleaning |
| **Week 4** | Professional photography, floor plan creation |
| **Week 5** | Listing goes live — photos, description, agent engaged |
| **Week 6** | First round of viewings |
| **Week 7** | Negotiate offers, accept offer, sales agreement signed |
| **Week 8** | Due diligence by buyer, deposit payment, legal process begins |

### Professional Photography Timeline

| Day | Task |
|---|---|
| Day 1 | Book photographer (2 weeks before listing date) |
| Day 7 | Final pre-shoot walkthrough (check repairs, staging, cleaning) |
| Day 8 | Photo shoot (2 hours for 3-bedroom flat) |
| Day 9 | Photo editing and selection |
| Day 10 | Receive final photos (15–25 images) |
| Day 14 | Listing goes live |

---

## Section 7: During the Selling Process

### Viewing Preparation

- [ ] Property should be show-ready at all times (30-minute notice possible)
- [ ] Create a viewing route — highlight best features in order
- [ ] Prepare information sheets for potential buyers (leave one in each room)
- [ ] Have documents ready for serious buyers to view (under supervision)
- [ ] Consider leaving during viewings — buyers ask more honest questions without the owner present

### Negotiation Tips

- [ ] Know your **bottom line** (minimum acceptable price)
- [ ] Don't accept the first offer immediately — ask for 24 hours to "consider"
- [ ] All offers in writing (email or formal letter)
- [ ] Consider non-price terms: faster closing, fewer contingencies
- [ ] Respond to all offers within 24 hours

---

## Summary Checklist

### Before Listing

- [ ] Professional valuation completed
- [ ] Asking price set with agent
- [ ] Minor repairs completed
- [ ] Property staged
- [ ] Deep cleaned
- [ ] Professional photos taken
- [ ] Floor plan created
- [ ] All documents organized
- [ ] Agent agreement signed
- [ ] Listing description written

### During Listing

- [ ] All viewings accommodated (flexible schedule)
- [ ] Property kept show-ready
- [ ] Offers responded to within 24 hours
- [ ] Agent provides weekly feedback

### After Offer

- [ ] Sale agreement signed
- [ ] Deposit received (typically 10%)
- [ ] Buyer's legal due diligence underway
- [ ] Payment plan agreed
- [ ] Handover date set

> **Pro Tip:** The cheapest improvements with the highest ROI are: fresh paint, clean carpets/floors, staged minimalism, and professional photography. These four things alone can add 10% to your selling price.
