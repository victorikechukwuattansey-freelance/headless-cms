# Day 20 — Agent Tips

## Post Type
Productivity / professional development

## Caption Templates

**Template 1 — Daily habits**
Real estate is 20% selling and 80% systems. Here are 3 habits that keep {{AgentName}} productive:

⏰ **Morning block** — 6–8 AM: No meetings, just deep work (prospecting, planning, learning)
📋 **CRM first** — Every lead, every follow-up, every note goes into the system
🚶 **Afternoon movement** — Showings, site visits, client meetings in one geographic block

Your system determines your success. What's one habit that keeps YOU productive?

**Template 2 — Tools & tech**
The tools I use every day to stay on top of my real estate game:

📱 **CRM**: {{ToolName}} — tracks every lead and follow-up
📸 **Camera**: {{ToolName}} — listing photos that sell
✍️ **Design**: Canva — for social posts and flyers
🗺️ **Maps**: Google Maps + local knowledge — planning viewing routes
📞 **Communication**: WhatsApp Business — fast, professional client chat

What tool could you not live without? Drop it in the comments.

**Template 3 — Mindset**
This business is a marathon, not a sprint. Here's what {{X}} years has taught me:

- Your first {{X}} deals will be your hardest. Keep going.
- The clients who say "no" today may say "yes" next year. Nurture relationships.
- Your reputation is everything. Protect it.
- Every 'no' gets you closer to a 'yes.'

Keep showing up. The consistency pays off.

## CTA
- DM me "TOOLS" for my full tech stack list
- Save this post for motivation on tough days
- Share this with a fellow agent who needs a boost

## Suggested Hashtags
#AgentTips #RealEstateProductivity #AgentLife #AfricanRealEstate #LagosAgent #NairobiRealtor #AccraAgent #CRM #RealEstateTools #BusinessTips

## Image Recommendation
Photo of your workspace setup or your CRM open on a laptop. Or a professional headshot with a thoughtful expression. Or a flat lay of your daily carry: laptop, phone, notebook, pen, keys.

## Story Idea
**"Day in the Life of an Agent"** — 7-slide story following your day: Wake up → Morning routine → First showing → Lunch → Paperwork → Second showing → Evening wrap-up. Use the countdown sticker for each activity. Authentic, unpolished feel.

## Reel Idea
**60-sec "A Day in My Life as a Real Estate Agent"** — Montage: alarm goes off → coffee → laptop → driving to a property → showing → documents → sunset. Voiceover or text overlay narrating the day. Trending chill beat. Real, relatable, inspiring.
