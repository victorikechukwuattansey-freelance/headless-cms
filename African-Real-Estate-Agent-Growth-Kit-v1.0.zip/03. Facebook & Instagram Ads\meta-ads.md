# Facebook & Instagram Ads — Ready-to-Launch Campaigns

---

## Ad 1: "Your Listings Deserve Better Marketing"

### Creative

| Element | Copy |
|---|---|
| **Headline** | Your Listings Deserve Better Marketing. |
| **Primary Text** | Most agents lose buyers because their marketing looks average. Download 300+ professional templates built specifically for African real estate agents. |
| **Description** | Instant download. Canva-ready. No design skills needed. |
| **CTA Button** | Download Now |

### Visual Suggestions

- **Option A (Carousel)**: Before/after comparison — ugly flyer vs. professional template from the kit. 3–4 slides showing different template examples.
- **Option B (Single Image)**: Mockup of a smartphone displaying a gorgeous property listing post, with the kit branding subtly overlaid. Clean, bright, aspirational.
- **Option C (Video)**: 10–15 second quick-cut montage of templates flipping on screen. Text overlay: "300+ templates. One click. Your brand."

### Target Audience

| Parameter | Setting |
|---|---|
| **Location** | Nigeria (Lagos, Abuja, Port Harcourt), Ghana (Accra, Kumasi), Kenya (Nairobi, Mombasa), South Africa (Johannesburg, Cape Town, Durban) |
| **Age** | 25–45 |
| **Gender** | All |
| **Interests** | Real Estate, Property Investment, Real Estate Agent, Mortgage, Construction, Interior Design, Property Development, Canva, Graphic Design |
| **Behaviours** | Engaged Shoppers, Small Business Owners |
| **Placements** | Feed, Stories, Reels, Marketplace |

### Budget Recommendations

| Budget Level | Daily Spend | Duration | Estimated Reach |
|---|---|---|---|
| **Test** | $5–$10 | 3–5 days | 2,000–5,000 |
| **Low** | $10–$20 | 7 days | 8,000–15,000 |
| **Medium** | $20–$40 | 14 days | 20,000–50,000 |
| **High** | $50+ | Ongoing | 50,000+ |

*All figures in USD. Local currency equivalents apply (NGN, GHS, KES, ZAR).*

### Placement Suggestions

| Platform | Placement | Why |
|---|---|---|
| **Instagram** | Feed & Stories | Highest engagement for visual content |
| **Instagram** | Reels | Viral potential, algorithm favours video |
| **Facebook** | Feed | Broader reach among 30+ demographic |
| **Facebook** | Marketplace | Direct access to property buyers/sellers |
| **Facebook** | Messenger Ads | Direct click-to-chat for leads |

---

## Ad 2: "Still Posting Blurry House Pictures?"

### Creative

| Element | Copy |
|---|---|
| **Headline** | Still posting blurry house pictures? |
| **Primary Text** | Imagine posting like a premium agency. Get every template you'll ever need — listing posts, stories, reels, flyers, and ads — all designed for the African market. No graphic design experience required. |
| **Description** | 300+ Canva templates. Instant download. Start today. |
| **CTA Button** | Learn More |

### Visual Suggestions

- **Image**: Split screen — left side showing a low-quality, blurry, badly cropped property photo with "Your Current Posts" label; right side showing the same property with a polished template overlay reading "With the Kit." High contrast, instantly scannable.
- **Video**: A 10-second clip of someone scrolling through an Instagram feed. First few posts are mediocre. Then they land on a post from your template. They stop scrolling. Screen freezes. Text: "Make them stop scrolling."

### Target Audience

Same as Ad 1 — but consider a **retargeting** variant that excludes anyone who already clicked Ad 1. Use "Thumbnail Blocker" creative (ugly left / polished right) for cold audiences.

### A/B Testing Variant

- **Variant A** (benefit-driven): Headline about professional branding
- **Variant B** (pain-driven): Headline about embarrassment/lost opportunities
- **Variant C** (social proof): Headline about agents already using the kit

---

## Ad 3: "The Fastest Way to Look Like a Million-Dollar Real Estate Brand"

### Creative

| Element | Copy |
|---|---|
| **Headline** | The fastest way to look like a million-dollar real estate brand. |
| **Primary Text** | You don't need a big budget to market like a top agency. This kit gives you 300+ ready-to-use Canva templates, a full content calendar, WhatsApp scripts, and ad copy — everything designed specifically for African real estate. Professional branding in one download. |
| **Description** | $39 one-time. Lifetime updates. Instant access. |
| **CTA Button** | Get Started |

### Visual Suggestions

- **Image**: Flat lay of a desk — laptop showing the template dashboard, phone with Instagram open, notebook, coffee, keys. The "million-dollar brand" aesthetic. Lifestyle, aspirational.
- **Carousel**: Slide 1 — Headline on brand background. Slide 2 — "300+ Canva Templates" with grid of templates. Slide 3 — "30-Day Content Calendar" with screenshot. Slide 4 — "WhatsApp Scripts + Ads" with preview. Slide 5 — CTA to buy.

### Target Audience

Same geographic and demographic targeting as Ads 1 & 2. Use **Detailed Targeting Expansion** to let Meta broaden reach if conversion costs are low.

---

## Ad Platform Specifications

### Image Specs

| Placement | Dimensions | Format | Max Text |
|---|---|---|---|
| Feed (Square) | 1080 × 1080 px | JPG, PNG | 20% of image |
| Feed (Landscape) | 1200 × 628 px | JPG, PNG | 20% of image |
| Stories / Reels | 1080 × 1920 px | JPG, PNG, MP4 | 10% of image |
| Marketplace | 1200 × 1200 px | JPG, PNG | 20% of image |

### Text Limits

| Element | Character Limit | Best Practice |
|---|---|---|
| Primary Text | 125 (before "See More" truncation) | Lead with hook in first 125 characters |
| Headline | 40 characters | Short, punchy, benefit-focused |
| Description | 30 characters | Supplementary detail |
| CTA Button | 25 characters | Use standard CTAs (Download, Learn More, Get Started) |

### Video Specs

| Parameter | Specification |
|---|---|
| Aspect Ratio | 1:1 (square) or 9:16 (vertical) |
| Resolution | 1080 × 1080 or 1080 × 1920 |
| Length | 6–15 seconds (ideal for landing page views) |
| File Size | Max 4 GB |
| Format | MP4, MOV |
| Captions | **Required** — most users watch on mute |

---

## A/B Testing Strategy

### Week 1 — Creative & Copy Test

Create 3 ad sets, each with a different **Ad** from this document. Same audience. Same budget. Run for 3–5 days.

### Week 2 — Audience Test

Take the winning ad creative. Create 3 ad sets:

1. **Broad** — Age 25–45, real estate interests, all placements
2. **Narrow** — Age 28–40, real estate agents + property developers, Feed & Stories only
3. **Lookalike** — 1% lookalike from your existing buyers/email subscribers (once you have 100+ conversions)

### Week 3 — Optimization

- Pause the worst-performing ad set
- Shift 70% budget to the winner, 30% to the second-place
- Refresh creative if CTR drops below 0.5%

### Key Metrics to Track

| Metric | Good | Excellent | Action If Below |
|---|---|---|---|
| CTR (Click-Through Rate) | 0.8%–1.2% | 1.5%+ | Refresh creative |
| CPC (Cost Per Click) | $0.20–$0.50 | < $0.20 | Adjust audience |
| CPM (Cost Per 1,000) | $5–$15 | < $5 | Optimise placement |
| ROAS (Return on Ad Spend) | 2× | 4×+ | Scale budget |
| Conversion Rate | 2%–4% | 5%+ | Improve landing page |

---

## Retargeting Strategy

### Pixel Setup (Essential)

Install the **Meta Pixel** on your checkout/sales page before launching any ad. This enables retargeting.

### Retargeting Funnel

| Stage | Audience | Duration | Offer |
|---|---|---|---|
| **Viewers** | Anyone who watched 3s+ of video | 7 days | Same ad (brand awareness) |
| **Engagers** | Anyone who clicked CTA or liked/saved/shares | 14 days | "Still thinking about it?" — add urgency |
| **Cart Abandoners** | Visited checkout but didn't buy | 30 days | Discount code or bonus offer |
| **Buyers** | Purchased the kit | 90 days | Upsell: Done-For-You service, 1:1 coaching, or advanced templates |

### Retargeting Ad Copy Examples

**For engagers (14-day window):**

> You almost grabbed the Kit. It's still waiting for you. 300+ Canva templates. Full content calendar. WhatsApp scripts. All at $39. Grab it now.

**For cart abandoners (30-day window):**

> Still on the fence? Here's a little push. Use code GROW20 for 20% off the African Real Estate Agent Growth Kit. Valid for 48 hours.

---

## Launch Checklist

- [ ] Meta Pixel installed on sales page
- [ ] Creative assets prepared (images/video)
- [ ] Ad copy pasted into Ads Manager
- [ ] Audience targeting verified
- [ ] Budget set with daily cap
- [ ] Payment method added to Ads Manager
- [ ] Ad reviewed & submitted (allow 24h review)
- [ ] UTM parameters added for tracking
- [ ] Retargeting audiences created

## Notes for African Markets

- **Currency**: Budget in USD in Ads Manager; actual charges will be in your local currency if your ad account is set up for NGN, GHS, KES, or ZAR.
- **Payment**: Meta accepts local payment methods in most African countries (cards, bank transfers via partners).
- **Time Zone**: Set ad schedule to run during active hours in your target city (12:00–14:00 and 18:00–21:00 local time).
- **Data Costs**: In markets with expensive data, keep ad creative lightweight (smaller file sizes) to ensure quick loading on 3G/4G connections.
