# Canva Marketing Assets — African Real Estate Agent Growth Kit

A complete library of Canva template specifications for African real estate agents. Every template uses the **Signature Palette** and **Brand Fonts** below for a cohesive, professional brand identity across all channels.

---

## Brand Foundation

| Element | Value |
|---|---|
| **Primary Palette** | Charcoal `#2D2D2D`, Cream `#F5F0E8`, Terracotta `#C26A4A`, Olive `#7B8D5D`, Gold `#C9A84C` |
| **Heading Font** | Playfair Display (bold, italic available) |
| **Body Font** | Lato (regular, bold, light available) |
| **Design Style** | Clean, premium, warm-toned, African-inspired earth tones |
| **Output Format** | Print-ready PDF (flyers, business), PNG/JPG (social media) |
| **Compatible Apps** | Canva (Free/Pro), **Affinity Photo 2**, **Affinity Designer 2** |

---

## Template Inventory

| # | Category | Count | Formats |
|---|---|---|---|
| 1 | [Property Flyers](./Property%20Flyers/README.md) | 8 flyer types | US Letter / A4 print |
| 2 | [Instagram](./Instagram/README.md) | 150+ templates | 1080×1080 (carousels), 1080×1920 (stories) |
| 3 | [Facebook](./Facebook/README.md) | 15+ templates | 1640×856 (covers), 1200×628 (banners/events) |
| 4 | [LinkedIn](./LinkedIn/README.md) | 12+ templates | 1200×627 (posts), 1200×627 (reports) |
| 5 | [Business](./Business/README.md) | 6 document types | Various print & digital |
| | **Affinity Guides** | | |
| — | [Affinity Brand Kit Setup](./Affinity-BrandKit-Setup.md) | Brand palette, swatches, text styles, assets | Affinity Designer/Photo |
| — | [Affinity Template Build Guide](./Template-Build-Guide-Affinity.md) | Step-by-step flyer build for Affinity users | Affinity Designer |

---

## Usage Guidelines

1. **Stay on palette** — Use only the 5 signature colours. Tints (opacity 10–40%) are permitted for backgrounds.
2. **Font hierarchy** — Playfair Display for headings and pull quotes; Lato for body text, captions, and data.
3. **Agent customisation** — Each template includes a clearly marked zone for agent photo, logo, name, and contact details.
4. **African real estate context** — All imagery, iconography, and copy should reflect African urban and suburban markets (Nairobi, Lagos, Accra, Johannesburg, etc.).
5. **White space** — Maintain generous padding (minimum 0.5 in / 1.5 cm on print, 40 px on digital) for a premium feel.

---

## File Naming Convention

```
[Category]-[TemplateName]-[Variant]-[Language].png
```

Examples: `Instagram-ListingCarousel-01-EN.png`, `Flyer-LuxuryHome-A4-EN.png`

---

## Template Dimensions Quick Reference

| Format | Dimensions (px) | Aspect Ratio |
|---|---|---|
| Print Flyer (US Letter) | 2550 × 3300 | 1:1.294 |
| Print Flyer (A4) | 2480 × 3508 | 1:1.414 |
| Instagram Carousel | 1080 × 1080 | 1:1 |
| Instagram Story | 1080 × 1920 | 9:16 |
| Facebook Cover | 1640 × 856 | ~1.92:1 |
| Facebook Banner / Event | 1200 × 628 | ~1.91:1 |
| LinkedIn Post | 1200 × 627 | ~1.91:1 |
| LinkedIn Report | 1200 × 627 | ~1.91:1 |
| Business Card | 1050 × 600 | 1.75:1 |
| Letterhead | 2550 × 3300 | 1:1.294 |
