# Day 23 — New Development

## Post Type
New project / construction update

## Caption Templates

**Template 1 — Project announcement**
Coming soon to {{PropertyLocation}} 🚧🏡

{{DevelopmentName}} — {{X}} units of modern {{PropertyType}}s designed for {{target market description}}.

✨ {{KeyFeature1}}
✨ {{KeyFeature2}}
✨ {{KeyFeature3}}
✨ {{KeyFeature4}}

Construction is {{percentage}}% complete, and early bird pricing is available. DM me "NEW" to get on the priority list.

**Template 2 — Progress update**
Construction update from {{DevelopmentName}} in {{PropertyLocation}} 📸

The foundation is in, walls are going up, and the vision is becoming reality. {{X}} units already sold off-plan.

Here's why buyers are choosing this development:
- Prime location
- Quality finishes
- Flexible payment plans

Want to secure your unit before completion? Let's talk.

**Template 3 — Why invest off-plan**
Why buy off-plan in a new development?

💰 **Lock in today's price** — Properties appreciate during construction
📈 **Payment plans** — Spread the cost over months or years
🎨 **Customisation** — Choose finishes in some developments
🏗️ **New standards** — Modern design, better infrastructure

This {{DevelopmentName}} in {{PropertyLocation}} is {{X}}% sold. Don't wait until completion.

## CTA
- DM me "NEW" for brochures and payment plans
- Save this to follow the development progress
- Tag someone looking to invest off-plan

## Suggested Hashtags
#NewDevelopment #OffPlan #ConstructionUpdate #AfricanRealEstate #LagosDevelopment #NairobiProjects #AccraConstruction #RealEstateDevelopment #InvestEarly #PropertyGrowth

## Image Recommendation
Construction site photo showing progress (foundation, framework, or completed structure). Or an architectural render of the finished development. Aerial shots add impact.

## Story Idea
**"Development Progress"** — 5-slide update. Slide 1: Renders of the finished project. Slide 2–4: Current construction photos. Slide 5: "Only {{X}} units left. DM for details." Use the countdown sticker: "Estimated completion: {{Month}}."

## Reel Idea
**45-sec "Before & During Construction"** — Split screen or transition from empty land to current construction progress. Add text overlay: "{{DevelopmentName}} — {{PropertyLocation}}. {{X}} units. Coming {{Month}}." Time-lapse of construction if available. Upbeat instrumental.
