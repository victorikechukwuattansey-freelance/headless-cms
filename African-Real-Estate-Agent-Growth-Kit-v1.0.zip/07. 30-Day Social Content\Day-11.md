# Day 11 — Investment Tips

## Post Type
Educational / investment strategy

## Caption Templates

**Template 1 — Starter advice**
Looking to invest in African real estate? Here are 3 ways to start:

1️⃣ **Buy and hold** — Purchase land or property in growing areas and let appreciation work for you
2️⃣ **Rental income** — Buy a {{PropertyType}} in a high-demand area and earn monthly cash flow
3️⃣ **Fix and flip** — Find undervalued properties, renovate, and sell at a profit

Each strategy takes different capital, time, and risk. Not sure which fits you? Let's talk.

**Template 2 — Location focus**
The #1 rule of real estate investment: Location. Location. Location.

In {{City}}, I'm watching these areas for growth potential:
📍 {{NeighborhoodName}} — {{Why}}
📍 {{NeighborhoodName}} — {{Why}}
📍 {{NeighborhoodName}} — {{Why}}

Early movers in these areas are seeing {{X}}% appreciation. Want in? DM me "INVEST."

**Template 3 — Long-term mindset**
Real estate isn't a get-rich-quick game. It's a get-rich-steady game.

Here's what {{X}} years in this business has taught me:
- The best time to invest was 5 years ago. The second best time is now.
- Don't try to time the market — time IN the market matters more.
- Your first deal won't be perfect. Do it anyway.

Ready to start? I'm here to guide you.

## CTA
- DM me "INVEST" for a free investment portfolio review
- Save this for your wealth-building strategy
- Tag a friend who's ready to invest in property

## Suggested Hashtags
#RealEstateInvestment #PropertyInvesting #AfricanRealEstate #InvestInAfrica #LagosProperties #NairobiRealEstate #AccraRealEstate #WealthBuilding #PassiveIncome #RealEstateTips

## Image Recommendation
Photo of a new development or construction site (progress = investment). Or a professional headshot with a confident pose. Or a clean graphic with "3 Ways to Start Investing" as text overlay.

## Story Idea
**"Investment Calculator"** — Show a simple breakdown: "Buy a {{PropertyType}} at {{Price}} → Rent at {{MonthlyRent}} → {{X}}% annual yield." Use the slider sticker: "What's your investment budget?" with options from ₦5M to ₦50M+.

## Reel Idea
**60-sec "3 Investment Strategies"** — Direct-to-camera. Hold up 3 fingers. Breakdown each strategy (buy & hold, rental, flip) with 10 seconds per strategy. Use simple props: a toy house, coins, a "SOLD" sign. Energetic, informative.
