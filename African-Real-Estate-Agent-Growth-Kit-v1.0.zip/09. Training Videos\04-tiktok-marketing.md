# Video 4: TikTok Marketing for Real Estate

> **Length:** 25–35 minutes
> **Level:** Intermediate
> **Prerequisites:** TikTok account (personal or business)

---

## Learning Objectives

By the end of this video, the viewer will be able to:

1. Understand TikTok's algorithm and how to work with it
2. Create real estate content that fits TikTok's native style
3. Use trending sounds, effects, and hashtags for property content
4. Grow a local following that converts to leads
5. Run TikTok ads (Spark Ads) for real estate

---

## Script Outline

### Hook (0:00–0:30)

"TikTok isn't just for dancing teenagers. In Nigeria, real estate agents with 5,000 followers are getting more leads than agents with 50,000 Instagram followers. Here's how."

### Introduction (0:30–1:30)

- TikTok's growth in Africa (Nigeria: 20M+ users, Ghana: 5M+, Kenya: 8M+)
- Why TikTok's algorithm favors local content
- The shift from polished to authentic content

### Main Content

#### Part 1: Setting Up for Real Estate Success (1:30–6:00)

1. **Profile optimization:**
   - Profile photo: Professional headshot or branded logo
   - Bio: "Real Estate Agent | Lagos | DM for viewing"
   - Link in bio: Calendly or WhatsApp link (use Linktree for multiple links)
2. **Switch to Business Account** (for analytics + ads)
3. **Content pillars for real estate:**
   - Property tours (40% of content)
   - Education (30%) — tips, advice, market updates
   - Personal (20%) — agent life, behind the scenes
   - Trends (10%) — hop on viral formats
4. **Show examples** of each content pillar

#### Part 2: Filming for TikTok (6:00–12:00)

1. **TikTok is vertical** — 9:16 aspect ratio always
2. **Hook in first 2 seconds:**
   - "You won't believe what ₦50M gets you in Lekki..."
   - "3 things your real estate agent won't tell you..."
   - "This is the best deal in Abuja right now..."
3. **Authentic over polished** — TikTok punishes overly produced content
4. **Pacing:** Fast cuts, text on screen, trending audio
5. **Property tour format:**
   - Establish shot (outside the property)
   - Walk through quickly (1–2 sec per room)
   - Money shot (best feature of the property)
   - End with price + CTA ("DM for viewing details")
6. **Screen recording:** Show behind-the-scenes filming + final edited TikTok

#### Part 3: Editing Inside TikTok (12:00–17:00)

1. Use TikTok's built-in editor (don't overcomplicate)
2. Add text overlays (neighborhood, price, bedrooms)
3. Use trending sounds (search "trending sounds" in TikTok)
4. Add captions (TikTok's auto-caption tool)
5. Effects: Green screen (for market updates), slow-mo (for luxury features)
6. **Exercise:** Edit a 15-second property tour inside TikTok

#### Part 4: Hashtag Strategy for Africa (17:00–21:00)

1. **Use a 3-tier hashtag system:**
   - Broad (high volume): #RealEstate #Property
   - Niche: #LagosRealEstate #AbujaProperty #LuxuryHomeNigeria
   - Local: #LekkiPhase1 #IkejaGRA #Magodo
   - Trending: Check TikTok Discover page daily
2. **Post at optimal times:**
   - 7 AM – 9 AM (morning commute)
   - 12 PM – 2 PM (lunch break)
   - 7 PM – 10 PM (evening scrolling)
3. **Post frequency:** 1–2 videos per day minimum

#### Part 5: TikTok Ads for Real Estate (21:00–28:00)

1. **Spark Ads** (most effective for real estate)
   - Boost your organic post that's already performing
   - Feels native — doesn't look like an ad
2. **In-Feed Ads:**
   - Full-screen video ad
   - Add "Swipe Up" or "Click to Learn More" CTA
3. **Lead Generation:** TikTok's lead form (instant forms)
4. **Budget:** Start with $10–$20/day (₦8,000–₦16,000)
5. **Targeting:** Location + age + interest in real estate/property
6. **Screen recording:** Set up a Spark Ad campaign

### Key Takeaways (28:00–32:00)

1. Be authentic — TikTok users can smell a sales pitch
2. Post consistently — 1 video/day beats 1 perfect video/week
3. Engage with comments — the algorithm rewards creators who reply
4. Use trending sounds within 24 hours of them trending
5. Cross-post TikTok videos to Instagram Reels and YouTube Shorts

### CTA (32:00–35:00)

- "Post your first TikTok property tour this week"
- Next video: "WhatsApp Selling & Automation"

---

## Practical Exercise

**Assignment:** Create 3 TikTok videos (15–30 seconds each): one property tour, one educational tip, one trend/hop-on. Post over 3 consecutive days.

**Submission:** Links to the 3 videos

---

## Real Estate TikTok Content Ideas

| Type | Example | Best For |
|---|---|---|
| Price reveal | "₦35M gets you THIS in Lekki" | Engagement |
| Neighborhood tour | "Where ₦50M goes in Abuja" | Authority |
| Before/After | "Staging transformed this living room" | Visual impact |
| Market insight | "Why property prices are rising in Lagos" | Trust |
| Agent day | "A day in the life of a Lagos agent" | Personal brand |
| Client react | "My client just bought this — watch her face" | Social proof |

## Resource Links

- TikTok Creative Center (trends & inspiration): https://ads.tiktok.com/business/creativecenter
- TikTok Business: https://www.tiktok.com/business
- Hashtag generator: https://influencermarketinghub.com/tiktok-hashtag-generator
- CapCut (edit before uploading): https://www.capcut.com
