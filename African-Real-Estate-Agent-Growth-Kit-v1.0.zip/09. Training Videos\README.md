# Training Video Series — African Real Estate Agent Growth Kit

> **Total videos:** 8
> **Total estimated runtime:** 3–5 hours
> **Intended audience:** Real estate agents in Nigeria, Ghana, Kenya, and other African markets
> **Prerequisites:** None — beginner to intermediate friendly
> **Format:** MP4 (1080p recommended), available as streaming + downloadable

---

## Series Overview

| # | Title | Length | Level |
|---|---|---|---|
| 1 | Editing Canva Templates | 25–35 min | Beginner |
| 2 | Creating Reels for Real Estate | 25–35 min | Beginner |
| 3 | Running Facebook & Instagram Ads | 30–40 min | Intermediate |
| 4 | TikTok Marketing for Property | 25–35 min | Intermediate |
| 5 | WhatsApp Selling & Automation | 20–30 min | All levels |
| 6 | Building Your Personal Brand | 25–35 min | All levels |
| 7 | Using AI for Property Listings | 20–30 min | All levels |
| 8 | Turning Leads into Clients | 30–40 min | Advanced |

---

## Format Recommendations

### Technical Specs

| Attribute | Recommended |
|---|---|
| Resolution | 1920 × 1080 (1080p) |
| Frame rate | 30 fps |
| Aspect ratio | 16:9 (landscape) or 9:16 (portrait for TikTok/Reels repurposing) |
| Audio | External microphone (not laptop mic) — Rode, Blue Yeti, or similar |
| Audio level | -12 dB to -6 dB peak |
| Lighting | Key light + fill light (Ring light minimum) |
| Background | Clean, professional, or branded backdrop |
| File format | MP4 (H.264 codec) |
| Intro/Outro | 5-second branded intro + 5-second CTA outro (consistent across all videos) |
| Thumbnail | Custom Canva thumbnail for each video |

### Recording Setup

- **Screen recording:** OBS Studio (free), Loom, or Screen Studio
- **Camera:** Webcam (1080p minimum) or DSLR/mirrorless
- **Teleprompter:** Teleprompter app (free) or bullet-point notes on screen
- **Editing:** CapCut (free, mobile), DaVinci Resolve (free, desktop), or Canva Video Editor

### Suggested Structure (Per Video)

| Segment | Duration | Content |
|---|---|---|
| Hook | 0:00–0:30 | Grab attention with the "what's in it for you" |
| Intro | 0:30–1:30 | Quick personal intro + what will be covered |
| Main content | 1:30–80% of video | Step-by-step tutorial |
| Key takeaways | 80–90% | 3–5 bullet recap |
| CTA | 90–100% | Next video + download link reminder |

---

## Suggested Viewing Order

**Path A — Beginner Agent:**
1 → 2 → 5 → 6 → 3 → 4 → 7 → 8

**Path B — Experienced Agent (already using social media):**
3 → 4 → 5 → 7 → 8 → 2 → 6 → 1

**Path C — I Want Leads Fast:**
5 → 3 → 8 → 7 → 2 → 4 → 6 → 1

---

## Distribution Plan

- **Primary:** Hosted on Gumroad / Selar as course bundle
- **Secondary:** YouTube (public) — upload as unlisted first, consider public after 3 months
- **Repurpose:** Each video → 5–10 short clips for Reels/TikTok/Shorts
- **Bonus:** Create a "Clips Pack" — 30+ pre-cut highlights buyers can post on their own pages

---

## Production Checklist

- [ ] Script written for all 8 videos
- [ ] Slides/presentation prepared (Canva or PowerPoint)
- [ ] Screen recordings captured (tools, software, demos)
- [ ] Talking head footage recorded
- [ ] Audio cleaned and leveled
- [ ] Edits completed
- [ ] Intro/outro added
- [ ] Thumbnails designed
- [ ] Video descriptions written
- [ ] Timestamp chapters added
- [ ] Captions/subtitles generated
- [ ] Uploaded to distribution platform
