# Day 24 — Holiday Post

## Post Type
Seasonal greeting / themed content

## Caption Templates

**Template 1 — General holiday greeting**
Happy {{Holiday}} from {{AgentName}}! 🎉

Whether you're celebrating with family, taking a well-deserved break, or working toward your next big goal — I hope this season brings you joy, peace, and plenty of reasons to smile.

And if your {{Holiday}} wishlist includes a new home, you know where to find me 🏡✨

**Template 2 — Reflection & gratitude**
As {{Holiday}} approaches, I've been reflecting on {{Year}} so far...

Grateful for:
- Every client who trusted me with their journey
- Every family I've helped find a home
- Every challenge that made me better

Here's to more homes, more dreams, and more growth. {{Holiday}} blessings from {{AgentName}} to you and yours.

**Template 3 — Themed real estate angle**
Looking for a {{Holiday}} gift that keeps giving? How about a home? 🎁

This {{Holiday}} season, give yourself the gift of:
- Financial security through property
- A space that's truly yours
- A future you're building

{{Holiday}} special: Mention this post and get a free consultation. Your dream home could be closer than you think.

## CTA
- DM me if your {{Holiday}} wishlist includes a new home
- Share this with someone you're grateful for
- Drop a 🎉 if you're celebrating this season

## Suggested Hashtags
#HappyHolidays #SeasonalGreetings #HolidaySeason #AfricanRealEstate #LagosLife #NairobiLiving #AccraVibes #FamilyHome #Gratitude #Celebrate

## Image Recommendation
Warm, lifestyle photo — you in festive or casual wear, perhaps with family or in a decorated space. Alternatively, a property decorated for the season or a graphic with a holiday message in your brand colours.

## Story Idea
**"Holiday Wishes"** — 3-slide story. Slide 1: You waving with a "Happy {{Holiday}}!" text. Slide 2: A photo of a cozy home interior with "This could be your {{Year}} goal." Slide 3: "DM me to start your home journey in the new year."

## Reel Idea
**30-sec holiday reel** — Cheerful montage: you smiling, waving, holding a "SOLD" sign wrapped with a ribbon or festive decoration. Text overlay: "Wishing you a {{Holiday}} filled with love, laughter, and a home that feels like you." Festive/upbeat music.
