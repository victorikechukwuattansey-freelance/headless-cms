# Day 16 — Rental Advice

## Post Type
Educational / landlord & tenant guidance

## Caption Templates

**Template 1 — For tenants**
Renting in {{City}}? Here's what you need to know before signing that lease:

🔑 **Read every clause** — Yes, ALL of them
🔑 **Know your rights** — Tenancy laws protect you
🔑 **Inspect the property** — Document existing damage
🔑 **Negotiate terms** — Rent, deposit, and duration are all negotiable
🔑 **Get everything in writing** — Verbal agreements cause problems

Your home matters. Protect yourself. DM me if you need a tenant checklist.

**Template 2 — For landlords**
Being a landlord doesn't have to be stressful. Here's how to protect your investment:

🏠 **Screen your tenants** — References and background checks matter
📝 **Use a proper contract** — Not a handwritten agreement
💰 **Set a fair rent** — Market-aligned = fewer vacancies
🔧 **Maintain the property** — Small fixes prevent big problems
📞 **Have a point person** — That's where I come in

Want to simplify your landlord experience? I can help manage your rental property.

**Template 3 — Deposit drama**
Let's talk about security deposits — the #1 source of rental disputes.

As a tenant: Know what deductions are legal. Take photos when you move in. Get a signed inventory.

As a landlord: Be fair. Itemise deductions. Return what's owed.

A smooth deposit return = a good reference = happy everyone.

## CTA
- DM me "RENT" for a tenant/landlord checklist
- Save this for your rental reference
- Tag a landlord or tenant who needs this

## Suggested Hashtags
#RentalAdvice #TenantTips #LandlordTips #AfricanRealEstate #LagosRentals #NairobiApartments #AccraProperties #RentalMarket #PropertyManagement #RealEstateAdvice

## Image Recommendation
Photo of a key on a rental agreement document. Or a well-presented rental property interior. Or a photo of you with a "For Rent" sign. Clean, professional, relatable.

## Story Idea
**"Rent or Buy?"** — Use the poll sticker: "Are you team Rent or team Buy?" Show the results. Follow up with 3 slides comparing the pros and cons of each. End with "Not sure? DM me and let's figure it out together."

## Reel Idea
**45-sec "3 Things Every Tenant Must Do"** — Direct-to-camera. Three points: 1) Read the contract, 2) Inspect with photos, 3) Communicate in writing. Show each point with a simple prop (contract, phone, keys). Friendly but firm tone.
