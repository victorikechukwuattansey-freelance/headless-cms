# Business — Template Specifications

Professional business stationery and documents for African real estate agents. Covers both print (business cards, letterhead, invoices) and digital (email signatures, proposals).

---

## Global Settings (All Business Assets)

| Setting | Value |
|---|---|
| **Colour Mode** | CMYK (print), RGB (email sig) |
| **Resolution** | 300 DPI (print), 72 DPI (digital) |
| **Heading Font** | Playfair Display Bold |
| **Body Font** | Lato Regular |
| **Accent / Data Font** | Lato Bold |
| **Primary Palette** | Charcoal `#2D2D2D`, Cream `#F5F0E8`, Terracotta `#C26A4A`, Olive `#7B8D5D`, Gold `#C9A84C` |
| **Logo Specifications** | Minimum 200 x 200 px (print), 100 x 100 px (digital). Provide as transparent PNG. |

---

## 1. Business Cards

### Specifications

| Setting | Value |
|---|---|
| **Dimensions** | 1050 x 600 px (3.5 x 2 in at 300 DPI) |
| **Bleed** | 0.125 in (3.175 mm) all sides |
| **Safe Zone** | 0.25 in inset from trim edge |
| **Finish** | Uncoated matte (premium feel), or silk with spot UV on logo |
| **Paper Stock** | 400-500 gsm uncoated or textured |
| **Orientation** | Horizontal |
| **Corners** | Standard square or rounded 3 mm |

### Front Layout

```
+--------------------------------------------------+
|                                                  |
|    +---------------------------+                 |
|    |      [Logo]               |                 |
|    |      (Top-left)           |                 |
|    +---------------------------+                 |
|                                                  |
|          [AGENT NAME]                            |
|          [Title / Designation]                   |
|          [Brokerage Name]                        |
|                                                  |
|    ------------------------------                |
|                                                  |
|    Phone: +254 712 345 678                       |
|    Email: agent@email.com                        |
|    Web:   www.agentwebsite.com                   |
|    Location: Nairobi, Kenya                      |
|                                                  |
|    +----------------+                            |
|    |  [QR Code]     |                            |
|    +----------------+                            |
+--------------------------------------------------+
```

This is Playfair Bold 22 pt, Charcoal. Title in Lato Regular 10 pt, Olive. Contact in Lato Regular 9 pt, Charcoal. QR code 80 x 80 px bottom-right.

### Back Layout

```
+--------------------------------------------------+
|                                                  |
|              +--------------+                    |
|              |   [LOGO]     |                    |
|              |   (Large)    |                    |
|              +--------------+                    |
|                                                  |
|        "Your Trusted Real Estate                 |
|         Partner in [City]"                       |
|                                                  |
|    @agent_handle | LinkedIn/agent                |
|                                                  |
|    ------------------------------                |
|    [Agent Name] - [Phone]                        |
+--------------------------------------------------+
```

Tagline in Playfair Italic 12 pt. Social handles row in Lato 9 pt.

### Colour Variations (3)

| Variant | Front BG | Back BG | Text | Best For |
|---|---|---|---|---|
| **Classic** | Cream | Charcoal | Charcoal text | General purpose |
| **Premium** | Charcoal | Cream | Cream text | Luxury market |
| **Bold** | Terracotta | Cream | Cream text | Standing out |

---

## 2. Email Signature

### Specifications

| Setting | Value |
|---|---|
| **Format** | HTML (inline CSS) |
| **Max Width** | 600 px (desktop safe) |
| **Max Height** | 200-250 px |
| **Font Stack** | Lato, Arial, sans-serif (fallback) |
| **Design** | Side-by-side layout (left: logo/info, right: headshot) |

### HTML Layout Spec

```
+------------------------------------------------------------+
| +---------+  +------------------------------------------+ |
| |         |  |  [Agent Name]                              | |
| | [Logo]  |  |  [Title]                                   | |
| | 120x120 |  |  [Brokerage Name]                          | |
| |         |  |                                            | |
| |         |  |  Phone: +254 712 345 678                  | |
| |         |  |  Email: agent@email.com                    | |
| |         |  |  Web:   www.agentwebsite.com               | |
| |         |  |                                            | |
| |         |  |  [LinkedIn] [Instagram] [Facebook]          | |
| |         |  |  [WhatsApp]                                | |
| |         |  +------------------------------------------+ | |
| |         |                              +----------+     | |
| |         |                              |Headshot  |     | |
| |         |                              | 120x120  |     | |
| |         |                              |          |     | |
| |         |                              +----------+     | |
| +---------+                                               | |
|                                                            | |
| ----------------------------------------------------------  | |
| Gold divider line                                           | |
| Disclaimer text                                             | |
+------------------------------------------------------------+

### HTML Structure Guide

| Element | Tag | Style |
|---|---|---|
| Container | `<table>` | `width: 600px; border-collapse: collapse; font-family: Lato, Arial, sans-serif;` |
| Logo | `<img>` | `width: 120px; height: auto; display: block;` |
| Name | `<span>` | `font-family: 'Playfair Display', Georgia, serif; font-size: 18px; font-weight: bold; color: #2D2D2D;` |
| Title | `<span>` | `font-size: 13px; color: #7B8D5D;` |
| Divider | `<hr>` | `border: none; border-top: 1px solid #C9A84C;` |
| Social Icons | `<a><img>` | `width: 24px; height: 24px; margin: 0 4px;` |
| Headshot | `<img>` | `width: 120px; height: 120px; border-radius: 50%;` |

### Social Icon Colours

| Platform | Colour | Link |
|---|---|---|
| LinkedIn | Olive `#7B8D5D` | `https://linkedin.com/in/[handle]` |
| Instagram | Terracotta `#C26A4A` | `https://instagram.com/[handle]` |
| Facebook | Charcoal `#2D2D2D` | `https://facebook.com/[handle]` |
| WhatsApp | Olive `#7B8D5D` | `https://wa.me/[number]` |

### Responsive Behaviour

- Desktop (600 px+): Side-by-side layout as shown above
- Mobile (<600 px): Stack vertically - logo top, info centre, headshot bottom
- Font sizes use `px` units for email client compatibility

---

## 3. Letterhead

### Specifications

| Setting | Value |
|---|---|
| **Dimensions** | 2550 x 3300 px (US Letter), 2480 x 3508 px (A4) |
| **Resolution** | 300 DPI |
| **Bleed** | 0.125 in all sides |
| **Margins** | 1 in (left/right), 0.75 in (top/bottom) |
| **Colour Mode** | CMYK |

### Layout

```
+------------------------------------------------------------+
|  +------------------------------------------------------+  |
|  |  +------+                    +-------------------+   |  |
|  |  |      |                    |  [Agent Name]      |   |  |
|  |  | Logo |                    |  [Title]           |   |  |
|  |  |      |                    |  [Brokerage]       |   |  |
|  |  +------+                    +-------------------+   |  |
|  |  --------------------------------------------------  |  |
|  |                                                      |  |
|  |              [BODY TEXT AREA]                        |  |
|  |              Lato Regular 12 pt                      |  |
|  |              65% of page                             |  |
|  |                                                      |  |
|  |  --------------------------------------------------  |  |
|  |                                                      |  |
|  |  [Name] [Phone] [Email]  [Address] [Web] [License]  |  |
|  +------------------------------------------------------+  |
+------------------------------------------------------------+
```

### Sections / Placeholders

| Section | Content | Dimensions |
|---|---|---|
| Header | Logo (left), Agent/Brokerage name + Gold divider (right) | Top 15% |
| Logo | Transparent PNG or vector, 300 x 150 px | - |
| Body | Editable text area, Lato Regular 12 pt, 1.15 line spacing | 65% of page |
| Footer | 4 columns: Name/Phone/Email, Address/Web, Social, License | Bottom 15% |
| Background | Cream `#F5F0E8`, optional watermark logo at 5% opacity | Full page |

---

## 4. Invoice

### Specifications

| Setting | Value |
|---|---|
| **Dimensions** | 2550 x 3300 px (US Letter) |
| **Resolution** | 300 DPI |
| **Margins** | 0.75 in all sides |
| **Colour Mode** | CMYK |

### Layout

```
+------------------------------------------------------------+
|  +------------------------------------------------------+  |
|  |  +--------------------+  +------------------------+   |  |
|  |  |       [Logo]       |  |   INVOICE              |   |  |
|  |  |                    |  |   #INV-2026-001        |   |  |
|  |  +--------------------+  |   Date: 24 Jul 2026    |   |  |
|  |                          |   Due: 23 Aug 2026     |   |  |
|  |                          +------------------------+   |  |
|  |                                                      |  |
|  |  Bill To:                                            |  |
|  |  [Client Name]                                       |  |
|  |  [Client Address]                                    |  |
|  |                                                      |  |
|  |  +------------------------------------------------+  |  |
|  |  | Item           | Qty | Rate    | Amount        |  |  |
|  |  |----------------|-----|---------|---------------|  |  |
|  |  | [Description]  | [1] | [X,XXX] | [X,XXX.00]   |  |  |
|  |  | [Description]  | [1] | [X,XXX] | [X,XXX.00]   |  |  |
|  |  |                |     | Total   | [X,XXX.00]   |  |  |
|  |  +------------------------------------------------+  |  |
|  |                                                      |  |
|  |  Payment Terms: [Terms]                              |  |
|  |  Bank: [Bank Name]   Account: [Number]               |  |
|  |  Branch: [Branch]   Code: [Code]                    |  |
|  |                                                      |  |
|  |  [Agent Name]   [Brokerage License Number]           |  |
|  +------------------------------------------------------+  |
+------------------------------------------------------------+
```

### Table Column Specs

| Column | Width | Alignment | Font |
|---|---|---|---|
| Item Description | 50% | Left | Lato Regular 11 pt |
| Quantity | 10% | Centre | Lato Regular 11 pt |
| Rate | 20% | Right | Lato Regular 11 pt |
| Amount | 20% | Right | Lato Bold 11 pt |
| **Total Row** | 100% | Right | Playfair Bold 16 pt, Gold |

### Placeholder Fields

- Invoice number (auto-increment format: INV-2026-001)
- Issue date + due date (30 days from issue)
- Client name and address block
- Line items (4-8 rows, editable)
- Subtotal, tax (if applicable), total
- Payment terms text
- Bank name, account number, branch, sort code
- Agent name, brokerage name, license number
- Logo top-left, Gold divider line

---

## 5. Proposal

### Specifications

| Setting | Value |
|---|---|
| **Dimensions** | 2550 x 3300 px (US Letter) per page |
| **Resolution** | 300 DPI |
| **Pages** | 6-8 pages (cover + sections) |
| **Binding** | Spiral or stapled top-left |
| **Paper** | 200 gsm silk for cover, 120 gsm for interior |
| **Colour Mode** | CMYK |

### Page-by-Page Layout

#### Page 1: Cover Page

```
+------------------------------------------------------------+
|                                                             |
|                    [Logo - Large, centred]                    |
|                                                             |
|                    [Agent Name]                              |
|                    [Brokerage Name]                          |
|                                                             |
|                    ==================================       |
|                                                             |
|                    MARKETING PROPOSAL                        |
|                                                             |
|                    Prepared for:                             |
|                    [Client Name]                             |
|                    [Property Address]                        |
|                                                             |
|                    [Date]                                    |
|                                                             |
|                    ==================================       |
|                                                             |
|                    "Your Trusted Partner in                  |
|                     Real Estate Success"                     |
|                                                             |
+------------------------------------------------------------+
```

Full-bleed background: Cream with Charcoal geometric pattern at 5% opacity. Logo centred top. Title in Playfair Bold 48 pt, Gold. Client name in Lato 18 pt. Gold divider lines.

#### Page 2: Executive Summary

Header "Executive Summary" (Playfair Bold 28 pt, Charcoal, Gold underline). 3-4 paragraph body (Lato 12 pt). Key metric callout box in Olive background. Agent headshot + signature block bottom-right.

#### Page 3: Property Details

Header "Property Overview". Split layout: left 50% property photo, right 50% details:
- Address
- Property type
- Size (sq m)
- Current condition
- Target market
- Estimated value

Key data points in Gold bold numbers. Olive accent icons.

#### Page 4: Marketing Plan

Header "Marketing Strategy". 4 strategy cards in 2x2 grid:

| Card | Colour | Content |
|---|---|---|
| Digital Marketing | Olive | Social media ads, Google Ads, email campaigns |
| Print Materials | Gold | Brochures, flyers, direct mail |
| Signage and Tours | Terracotta | For Sale sign, open houses, virtual tours |
| Agent Network | Charcoal | MLS listing, agent referrals, co-brokerage |

Each card has icon + heading + 3 bullet points in Lato 11 pt.

#### Page 5: Pricing Tiers

Header "Service Packages". 3-tier pricing table:

| Feature | Bronze | Silver | Gold |
|---|---|---|---|
| **Price** | X% commission | Y% commission | Z% commission |
| MLS Listing | Yes | Yes | Yes |
| Professional Photos | No | Yes | Yes |
| Virtual Tour | No | No | Yes |
| Print Flyers | 100 | 250 | 500 |
| Social Media Ads | No | 30 days | 60 days |
| Open House | No | 1 event | 2 events |
| **Recommended For** | Budget sellers | Most sellers | Premium/Luxury |

Gold header row (Charcoal text). Bronze: Cream bg. Silver: Olive tint. Gold: Gold tint.

#### Page 6: ROI Projection

Header "Projected Return on Investment". Two-column layout:

Left: "Estimated Sale Price" - Large Gold number (e.g., "KES 18.5M"). Supporting stats below (avg DOM, price per sq m).

Right: "Net Proceeds Calculation" - Stacked table:
- Sale Price: [Amount]
- Commission (-): [Amount]
- Marketing Costs (-): [Amount]
- Net to Seller: [Amount] (Gold, bold)

Bottom section: "Why Choose Us" - 3 testimonial or stat callouts in Olive, Gold, Terracotta cards.

#### Page 7: About Us

Header "About [Agent Name / Team]". Agent headshot + bio. Team photos (if applicable). Key stats:
- Years in business
- Homes sold
- Client satisfaction rate
- Sales volume

Bottom: Professional association logos and certifications.

#### Page 8: Next Steps / CTA

Header "Ready to Get Started?". Numbered action steps:
1. Sign the agreement
2. Schedule the photo shoot
3. Launch the marketing campaign
4. First open house

Terracotta CTA button: "Let's Get Started". Agent contact info repeated. "Proposal valid for 14 days" in Lato 9 pt, Olive.

### Proposal Copy Skeleton

Each proposal template includes placeholder hooks:
- "We understand that your home is more than just a property..."
- "Our proven marketing system has helped [number] sellers achieve..."
- "We don't just list homes -- we build relationships..."
- "Here is our strategy to get you the best possible outcome..."

---

## File Naming for Business Assets

| Asset | File Name Pattern |
|---|---|
| Business Card (Front) | BusinessCard-Front-[Variant]-[Language].png |
| Business Card (Back) | BusinessCard-Back-[Variant]-[Language].png |
| Email Signature | EmailSignature-[AgentName].html |
| Letterhead | Letterhead-[Language].png |
| Invoice | Invoice-Blank-[Language].png |
| Proposal (Cover) | Proposal-Cover-[Language].png |
| Proposal (Interior) | Proposal-Page[2-8]-[Language].png |

---

## Print Provider Specifications

| Spec | Business Card | Letterhead | Invoice | Proposal |
|---|---|---|---|---|
| **Bleed** | 0.125 in | 0.125 in | 0.125 in | 0.125 in |
| **Colour** | CMYK | CMYK | CMYK | CMYK |
| **PDF Preset** | PDF/X-1a | PDF/X-1a | PDF/X-1a | PDF/X-4 |
| **Resolution** | 300 DPI | 300 DPI | 300 DPI | 300 DPI |
| **Trim Marks** | Required | Required | Required | Required |
```
