# Video 6: Building Your Personal Brand

> **Length:** 25–35 minutes
> **Level:** All levels
> **Prerequisites:** Instagram, Facebook, or LinkedIn account

---

## Learning Objectives

By the end of this video, the viewer will be able to:

1. Define their real estate brand identity
2. Create a content strategy that builds trust and authority
3. Maintain consistent visual branding across platforms
4. Position themselves as the go-to agent in their area
5. Turn their personal brand into a lead generation machine

---

## Script Outline

### Hook (0:00–0:30)

"People don't buy properties from agencies. They buy from people they know, like, and trust. In a market with thousands of agents, your personal brand is what makes you the obvious choice."

### Introduction (0:30–1:30)

- Why personal brand matters more in African real estate (trust deficit)
- Clients choose agents, not agencies — especially in Lagos, Abuja, Accra, Nairobi
- The goal: Be the first agent that comes to mind in your area

### Main Content

#### Part 1: Defining Your Brand (1:30–7:00)

1. **Find your niche:**
   - "I help first-time buyers find their dream home in Lekki"
   - "I help diaspora Nigerians invest in Lagos property"
   - "I specialize in luxury duplexes in Abuja's top neighborhoods"
2. **Create your brand statement:**
   - Formula: "I help [target audience] [achieve goal] in [location]"
   - Example: "I help young professionals buy their first home in Lagos without getting scammed"
3. **Brand personality:**
   - Professional & authoritative vs. friendly & approachable
   - Luxury vs. affordable
   - Your values (transparency, education, client-first)
4. **Exercise:** Write your brand statement in 15 words or fewer

#### Part 2: Content Strategy (7:00–14:00)

1. **The 4:1 content ratio:**
   - 4 value posts (tips, education, market updates)
   - 1 promotional post (new listing, open house, offer)
2. **Content pillars (choose 3–4):**
   - Listings & properties
   - Market education (pricing, process, tips)
   - Client stories & testimonials
   - Behind the scenes (agent life, viewings, inspections)
   - Community (local news, developments, events)
3. **30-day content calendar:**
   - Monday: Market tip / Education
   - Tuesday: Property listing
   - Wednesday: Client testimonial or story
   - Thursday: Behind the scenes or personal
   - Friday: Neighborhood spotlight
   - Saturday: Property listing or open house
   - Sunday: Rest / personal content
4. **Screen recording:** Show a 30-day content calendar in Google Sheets

#### Part 3: Visual Branding Consistency (14:00–20:00)

1. **Colors:** 2–3 brand colors (use the same across all platforms)
2. **Logo:** Professional logo (use Canva or hire designer for ₦20,000–₦50,000)
3. **Fonts:** 1–2 fonts for all graphics
4. **Profile photos:** Same photo across all platforms (professional headshot)
5. **Cover images:** Consistent cover/banner on Facebook, LinkedIn, YouTube
6. **Templates:** Use your Growth Kit templates consistently
7. **Watermark:** Add your brand to all property photos (subtle)
8. **Exercise:** Audit your current profiles — do they look like the same agent?

#### Part 4: Authority Building (20:00–27:00)

1. **Share what you know:**
   - Post market data (price trends, new developments)
   - Explain the buying/selling process step by step
   - Answer common questions in posts (reduces DM volume, increases authority)
2. **Client testimonials (the RIGHT way):**
   - Video testimonials > written > screenshots
   - Ask for testimonials immediately after closing
   - Show results: "Before I helped them: stuck for 6 months. After: closed in 3 weeks"
3. **Collaborations:**
   - Partner with: mortgage brokers, interior designers, architects
   - Cross-post each other's content
   - Host joint live sessions
4. **Local expertise:**
   - Know your area inside out: schools, hospitals, traffic patterns, development plans
   - Share this knowledge freely — it positions you as the local expert

#### Part 5: From Brand to Leads (27:00–33:00)

1. **The trust → lead pipeline:**
   - Content → Trust → DM/comment → Call → Viewing → Sale
2. **Call to action in every post:**
   - "DM me for a free home valuation"
   - "Comment 'GUIDE' and I'll send you my first-time buyer checklist"
   - "Link in bio to schedule a consultation"
3. **Lead magnets work:**
   - First-time home buyer checklist (offer in every post)
   - Free property valuation
   - Neighborhood guides
4. **Engage to grow:**
   - Reply to every comment on your posts within 1 hour
   - Comment on 10 other local accounts daily
   - DM new followers within 24 hours

### Key Takeaways (33:00–35:00)

1. Your niche is your superpower — the more specific, the better
2. Consistency builds trust — show up daily, not weekly
3. Give value first, ask for the sale second
4. Your brand exists in the minds of your audience — control the narrative
5. Personal branding is a long game — 6 months of consistency = exponential results

### CTA

- "Define your brand statement and post it as your Instagram bio"
- Next video: "Using AI for Property Listings"

---

## Practical Exercise

**Assignment:** Do a brand audit. Update all your social media profiles with consistent photos, bios, and covers. Write your 30-day content calendar. Post for 7 consecutive days.

**Submission:** Screenshots of your updated profiles + links to 7 posts

---

## Brand Consistency Checklist

| Platform | Profile Photo | Bio | Cover/Banner | Link |
|---|---|---|---|---|
| Instagram | ✓ | ✓ | N/A | Linktree |
| Facebook | ✓ | ✓ | ✓ | Website/WA |
| LinkedIn | ✓ | ✓ | ✓ | Website |
| TikTok | ✓ | ✓ | N/A | Linktree |
| YouTube | ✓ | ✓ | ✓ | Subscribe link |

## Resource Links

- Canva (brand kit): https://www.canva.com
- Linktree (link in bio): https://linktr.ee
- Gaana (free stock photos if needed): https://www.pexels.com
- Brand strategy guide: https://www.brandingcompass.com (free resources)
