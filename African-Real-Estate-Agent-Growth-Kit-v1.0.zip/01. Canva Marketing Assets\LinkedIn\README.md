# LinkedIn — Template Specifications

Professional branding and market authority content for African real estate agents on LinkedIn. Designed to build credibility with B2B and high-net-worth audiences.

---

## Global Settings (All LinkedIn Assets)

| Setting | Value |
|---|---|
| **Post Dimensions** | 1200 × 627 px (1.91:1) — single image posts |
| **Report / Infographic Dimensions** | 1200 × 1500 px (portrait, scroll-friendly) |
| **Carousel / Document Post** | PDF upload, 1200 × 1200 px per page preferred |
| **Colour Mode** | RGB |
| **Resolution** | 72 DPI |
| **Heading Font** | Playfair Display Bold 32–44 pt (posts), 24–36 pt (reports) |
| **Subheading Font** | Playfair Display Italic 20–26 pt |
| **Body / Data Font** | Lato Regular 14–20 pt |
| **Accent Numbers** | Lato Bold 48–72 pt (for stat emphasis) |
| **Logos** | Bottom-right, 60 × 60 px, white or charcoal as appropriate |

---

## Design Philosophy for LinkedIn

LinkedIn audiences expect:
- **Data-driven content** — lead with numbers, trends, and insights
- **Professional tone** — clean, minimal, authoritative
- **Thought leadership** — agent as industry expert, not just salesperson

Every LinkedIn template should prioritise Charcoal + Cream as base, with Gold and Olive as accent colours. Terracotta is used sparingly for CTA moments.

---

## Section 1: Agent Branding Posts (6 Templates)

### Type 1: Professional Headshot Layout

**Purpose:** Personal-branding post — announce new role, award, or milestone.

**Dimensions:** 1200 × 627 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │  ┌──────┐    ┌────────────────────────────────┐       │  │
│  │  │      │    │  [Agent Name]                    │       │  │  Split layout
│  │  │      │    │  [Title]                         │       │  │
│  │  │      │    │  [Brokerage]                     │       │  │  Left: headshot (circular)
│  │  │      │    │                                   │       │  │  Right: name + credentials
│  │  │      │    │  ✦ [Achievement/metric]          │       │  │
│  │  │      │    │  ✦ [Years] years of experience   │       │  │
│  │  │      │    │  ✦ [Number] homes sold           │       │  │
│  │  │      │    │                                   │       │  │
│  │  │      │    │  [Tagline / Philosophy sentence]  │       │  │
│  │  │      │    └────────────────────────────────┘       │  │
│  │  └──────┘                                             │  │
│  │                                                        │  │
│  │  ─── [Specialist Area] | [Location] | [Phone] ───    │  │  Contact strip
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Placeholders:**
- Circular headshot crop (350 × 350 px, Gold 4 px border)
- Name (Playfair Bold 40 pt, Charcoal)
- Title + Brokerage (Lato 18 pt, Olive)
- 3 achievement bullets with Gold checkmark icons
- Philosophy sentence (Playfair Italic 20 pt)
- Contact strip (Lato 12 pt, Terracotta dividers)

---

### Type 2: Achievement Highlight

**Purpose:** Announce a specific milestone or award.

**Dimensions:** 1200 × 627 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │         ┌────────────────────────────────┐              │  │
│  │         │          [Number]              │              │  │  Massive centre number
│  │         │          (Gold, 96 pt)          │              │  │  E.g., "150+", "98%", "12"
│  │         └────────────────────────────────┘              │  │
│  │                                                        │  │
│  │         [Achievement description]                       │  │  Playfair Italic
│  │         [Context / year]                                │  │  Lato body
│  │                                                        │  │
│  │              ─ ◆ ─                                     │  │  Gold diamond divider
│  │                                                        │  │
│  │         [Agent Name]  |  [Brokerage]                   │  │
│  │                                                        │  │
│  │         [Celebratory subtext or gratitude note]        │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Variations:**
- Homes Sold Milestone (e.g., "500+ Homes Sold")
- Years in Business (e.g., "15 Years of Excellence")
- Sales Volume (e.g., "KES 2B+ in Sales Volume")
- Client Satisfaction (e.g., "98% Client Satisfaction Rate")
- Award Announcement (e.g., "2026 Agent of the Year")

---

### Type 3: Thought Leadership Quote

**Purpose:** Share industry insight or market prediction.

**Dimensions:** 1200 × 627 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │  ❝                                                    │  │  Large Gold quote mark (72 pt)
│  │                                                        │  │
│  │  [Thought-leadership statement]                        │  │  Playfair Display Bold Italic
│  │  2–3 sentences                                         │  │  28 pt, Charcoal
│  │                                                        │  │
│  │  — [Agent Name]                                        │  │  Lato Regular 16 pt
│  │    [Title], [Brokerage]                                 │  │  Olive
│  │                                                        │  │
│  │  ──────────────────────────────────────────            │  │  Gold thin divider
│  │                                                        │  │
│  │  💡 Key insight from [context]                         │  │  Context tag
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Copy themes:**
- Market prediction for the coming quarter
- Advice for sellers in the current market
- Reflection on industry change
- Client experience philosophy
- Local market observation

---

### Type 4: "Meet the Agent" Carousel Cover

**Purpose:** First slide of a multi-page LinkedIn carousel about the agent.

**Dimensions:** For use in PDF carousel — each page 1200 × 1200 px

**Slide 1 — Cover:**
- Agent headshot centred, Gold circular border
- "Meet [Name]" — Playfair Bold
- "[Number] things you should know" — Lato
- Cream bg, Charcoal text

**Subsequent slides:**
Each slide = 1 fact/number with icon. Alternating colour backgrounds:
- Slide 2: Olive bg — "Background & Experience"
- Slide 3: Gold bg — "Specialisation"
- Slide 4: Terracotta bg — "Track Record"
- Slide 5: Charcoal bg — "Philosophy"
- Slide 6: Cream bg — "Let's Connect" CTA

---

### Type 5: Brokerage / Team Introduction

**Purpose:** Introduce the agency team to LinkedIn network.

**Dimensions:** 1200 × 627 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │  [Brokerage Name]                                       │  │  Playfair Bold, Charcoal
│  │  [Tagline]                                             │  │  Lato, Olive
│  │                                                        │  │
│  │  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐                  │  │
│  │  │  H1  │ │  H2  │ │  H3  │ │  H4  │                  │  │  4 circular headshots
│  │  │[Name]│ │[Name]│ │[Name]│ │[Name]│                  │  │  Names below
│  │  │[Role]│ │[Role]│ │[Role]│ │[Role]│                  │  │  Titles in Lato small
│  │  └──────┘ └──────┘ └──────┘ └──────┘                  │  │
│  │                                                        │  │
│  │  [Collective stat: X years combined | Y homes sold]    │  │  Team metric
│  │  [Brokerage logo]                    [Location]        │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

---

### Type 6: Service Offering Post

**Purpose:** Outline services for potential clients scrolling LinkedIn.

**Dimensions:** 1200 × 1500 px (portrait)

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │  How I Help My Clients                                 │  │  Header
│  │                                                        │  │
│  │  ┌───┐                                                 │  │
│  │  │ 1 │  Buying — [description]                         │  │  Numbered service list
│  │  └───┘                                                 │  │  Gold numbers
│  │                                                        │  │
│  │  ┌───┐                                                 │  │
│  │  │ 2 │  Selling — [description]                        │  │
│  │  └───┘                                                 │  │
│  │                                                        │  │
│  │  ┌───┐                                                 │  │
│  │  │ 3 │  Investing — [description]                      │  │
│  │  └───┘                                                 │  │
│  │                                                        │  │
│  │  ┌───┐                                                 │  │
│  │  │ 4 │  Property Management — [description]            │  │
│  │  └───┘                                                 │  │
│  │                                                        │  │
│  │  ┌───┐                                                 │  │
│  │  │ 5 │  Consulting — [description]                     │  │
│  │  └───┘                                                 │  │
│  │                                                        │  │
│  │  [CTA: Book a strategy call]                           │  │  Terracotta button
│  │  [Link in comments / DM me]                            │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

---

## Section 2: Market Reports (6 Templates)

### Type 1: Monthly Market Snapshot

**Purpose:** Monthly data summary — establish market authority.

**Dimensions:** 1200 × 1500 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │  [City] Market Snapshot                                 │  │  Playfair Bold, Charcoal
│  │  [Month] [Year]                                        │  │  Lato, Olive
│  │                                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐                   │  │
│  │  │ KES 12.5M    │  │ 22 Days      │                   │  │  4-KPI dashboard (2×2)
│  │  │ Median Price │  │ Avg DOM      │                   │  │  Gold numbers
│  │  ├──────────────┤  ├──────────────┤                   │  │  Olive labels
│  │  │ 142          │  │ 98           │                   │  │
│  │  │ New Listings │  │ Homes Sold   │                   │  │
│  │  └──────────────┘  └──────────────┘                   │  │
│  │                                                        │  │
│  │  ┌────────────────────────────────────────────────┐   │  │
│  │  │  [Line chart placeholder — 6-month trend]      │   │  │  Price trend chart
│  │  │  Gold line on Charcoal grid                    │   │  │  Gold line, Charcoal grid
│  │  └────────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Key Takeaway: [1-sentence insight]                   │  │  Playfair Italic
│  │  Source: [Data source]                                 │  │  Lato small, Olive
│  │  [Agent branding]                                     │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Data Placeholders:**
- Median price (current month)
- Average days on market
- Number of new listings
- Number of sold properties
- Price trend (6-month moving average)
- Month-over-month change percentage (Gold arrow up/down)

---

### Type 2: Year-over-Year Comparison

**Purpose:** Show annual trends and market trajectory.

**Dimensions:** 1200 × 1500 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │  Year-over-Year: [Market]                              │  │  Header
│  │                                                        │  │
│  │      2025              2026         CHANGE             │  │
│  │  ┌──────────┐    ┌──────────┐    ┌──────────┐        │  │
│  │  │ KES 11.2M│    │ KES 12.5M│    │  +11.6%  │        │  │  Side-by-side comparison
│  │  │ Med. Pr.│    │ Med. Pr.│    │          │        │  │  Right column: Change
│  │  └──────────┘    └──────────┘    └──────────┘        │  │
│  │                                                        │  │
│  │  [Repeat for DOM, Listings, Sales]                    │  │  3 comparison rows
│  │                                                        │  │
│  │  ┌────────────────────────────────────────────────┐   │  │
│  │  │  [Bar chart — 2025 vs 2026 side by side]       │   │  │  Visual comparison
│  │  │  Olive bars (2025) vs Gold bars (2026)          │   │  │
│  │  └────────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Insight: [1-2 sentence analysis]                     │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Colour Coding:**
- Positive changes: Gold arrow up, Gold text
- Negative changes: Terracotta arrow down, Terracotta text
- Neutral: Olive dash

---

### Type 3: Suburb Performance Ranking

**Purpose:** Rank neighbourhoods by key metrics — hyperlocal authority.

**Dimensions:** 1200 × 1500 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │  Top 5 Suburbs by [Metric]                              │  │  Header
│  │  [City] — [Month] [Year]                                │  │  Subtitle
│  │                                                        │  │
│  │  🥇  Suburb A  —  KES 18.5M  —  +15% YoY              │  │  Gold #1
│  │  🥈  Suburb B  —  KES 14.2M  —  +12% YoY              │  │  Olive #2
│  │  🥉  Suburb C  —  KES 11.8M  —  +9% YoY               │  │  Terracotta #3
│  │  4.  Suburb D  —  KES 9.5M   —  +6% YoY               │  │  Charcoal #4
│  │  5.  Suburb E  —  KES 7.2M   —  +4% YoY               │  │  Charcoal #5
│  │                                                        │  │
│  │  ──────────────────────────────────────────            │  │
│  │                                                        │  │
│  │  Methodology: Median sale price, single-family homes   │  │  Footer note
│  │  Source: [Data source]   [Agent Logo]                  │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Ranking metrics:** Median price, price growth %, rental yield, days on market, or sales volume.

---

### Type 4: Infographic — Buyer Profile

**Purpose:** Visualise who is buying in the current market.

**Dimensions:** 1200 × 1500 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │  Who's Buying in [City]?                               │  │  Header
│  │                                                        │  │
│  │  ┌────────────────────────────────────────────────┐   │  │
│  │  │  [Pie chart — buyer segments]                  │   │  │  Segments:
│  │  │                                                │   │  │  First-time (Olive) 35%
│  │  │  Olive 35% | Gold 28% | Terracotta 22% |      │   │  │  Upgraders (Gold) 28%
│  │  │  Charcoal 15%                                 │   │  │  Investors (Terr) 22%
│  │  └────────────────────────────────────────────────┘   │  │  Foreign (Char) 15%
│  │                                                        │  │
│  │  ┌────────────────────────────────────────────────┐   │  │
│  │  │  Average Buyer Age: 34 years                   │   │  │  Key stat cards
│  │  │  Average Budget: KES 8.5M                      │   │  │
│  │  │  Most Wanted: 3-bed apartment                   │   │  │
│  │  └────────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  [Agent insight — what this means for sellers]        │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

---

### Type 5: Infographic — Seller Profile

**Purpose:** Data on current seller behaviour and motivations.

**Dimensions:** 1200 × 1500 px

Same structure as Buyer Profile but with seller metrics:
- Why sellers are selling (relocation, downsizing, investment)
- Average time from listing to offer
- Percentage reducing price
- Average discount from asking price
- Most common sale reasons (pie chart or bar chart)

---

### Type 6: Investment Yield Comparison

**Purpose:** Compare ROI across property types and locations.

**Dimensions:** 1200 × 1500 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │  Where to Invest in [Year]                              │  │  Header
│  │  Rental Yield by Property Type                         │  │  Subtitle
│  │                                                        │  │
│  │  ┌────────────────────────────────────────────────┐   │  │
│  │  │  [Horizontal bar chart]                        │   │  │  Bars sorted high to low
│  │  │                                                │   │  │
│  │  │  Studio      ████████████████████  8.2%        │   │  │  Gold bars
│  │  │  1-Bed Apt   ██████████████████    7.5%        │   │  │
│  │  │  2-Bed Apt   ████████████████      6.8%        │   │  │
│  │  │  Townhouse   █████████████         5.4%        │   │  │
│  │  │  Villa       █████████              4.1%        │   │  │
│  │  │  Commercial  ████████████████      6.9%        │   │  │
│  │  └────────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  💡 Top Pick: Studio apartments in [suburb]            │  │  Recommendation
│  │  Average purchase price: KES 4.2M                      │  │  Supporting data
│  │                                                        │  │
│  │  "Want to build a portfolio? Let's talk."              │  │  CTA
│  │  [Agent Name]  [Phone]                                 │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

---

## Posting Schedule for LinkedIn

| Day | Content | Objective |
|---|---|---|
| Monday | Market Snapshot / Data Post | Authority |
| Wednesday | Thought Leadership Quote | Engagement |
| Thursday | Achievement / Milestone | Social Proof |
| Friday | Agent Intro / Team Post | Brand Building |
| Weekend | Long-form Carousel (PDF) | Deep Dive |

---

## LinkedIn-Specific Best Practices

1. **PDF carousels outperform single images** — Design multi-page documents for the "Document Post" format.
2. **First 3 lines of post copy are critical** — Templates should include a caption skeleton with hook, body, and CTA.
3. **Tagging** — Leave space in captions to tag collaborators, brokerages, and industry partners.
4. **No link in image** — LinkedIn doesn't make images clickable. Place links in the post copy or comments.
5. **Hashtags** — Use 3–5 industry hashtags at the end of the post (e.g., #RealEstateAfrica #PropertyInvestment).
6. **Accessibility** — Ensure minimum 14 pt font size for body text. High contrast between text and background.
