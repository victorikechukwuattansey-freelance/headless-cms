# Facebook — Template Specifications

Cover photos, property banners, and event promotions for the African real estate market. Optimised for Facebook's desktop and mobile layout requirements.

---

## Global Settings (All Facebook Assets)

| Setting | Value |
|---|---|
| **Cover Photo Dimensions** | 1640 × 856 px (recommended) — safe zone: 1230 × 717 px centre |
| **Banner Dimensions** | 1200 × 628 px |
| **Event Cover Dimensions** | 1920 × 1005 px |
| **Colour Mode** | RGB |
| **Resolution** | 72 DPI |
| **Heading Font** | Playfair Display Bold 36–48 pt (covers), 28–36 pt (banners) |
| **Body Font** | Lato Regular 16–22 pt |
| **Call-to-Action** | Lato Bold 18–20 pt |
| **Safe Zone (Cover)** | 1230 × 717 px centred — all critical content inside this area |
| **Profile Pic Overlap** | 170 × 170 px circle centred at left edge — leave this area clear of text on covers |

---

## Section 1: Cover Photos (3 Types × 3 Variations = 9 Templates)

### Type 1: Agent Profile Cover

**Purpose:** Professional brand cover for agent's personal Facebook page.

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │              [Hero background image]                   │  │  Full-bleed background
│  │                                                        │  │  (city skyline, property,
│  │                                                        │  │   or warm texture)
│  │                                                        │  │
│  │                         ┌──────────────┐               │  │
│  │                         │ [Agent Name]  │              │  │  Name: Playfair Bold 42 pt
│  │                         │ [Tagline]     │              │  │  Tagline: Lato 18 pt
│  │                         │ ✦ [Phone]    │              │  │  Contact in Gold
│  │                         └──────────────┘              │  │
│  │                                                        │  │
│  │                    ◌ (Profile pic zone — leave clear)  │  │  Empty zone bottom-left
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Variations (3):**
- **A — Cityscape** — Background: African city skyline at golden hour. Agent name overlaid in Cream. Contact info in Gold. Modern, aspirational.
- **B — Property Collage** — Background: 3×2 grid of property photos (low opacity, 50%). Agent branding centred. Shows portfolio breadth.
- **C — Warm Texture** — Background: Cream/Charcoal gradient with subtle African pattern texture. Agent name prominent. Minimalist and elegant.

---

### Type 2: Property Showcase Cover

**Purpose:** Highlight a single flagship listing on the page.

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │              [Full-bleed property photo]               │  │  Hero property image
│  │                                                        │  │
│  │  ┌──────────────────────┐  ┌──────────────────────┐   │  │
│  │  │ FOR SALE / FOR RENT  │  │   [Price]            │   │  Left badge, right price
│  │  │ (Terracotta badge)   │  │   (Gold text strip)  │   │
│  │  └──────────────────────┘  └──────────────────────┘   │  │
│  │                                                        │  │
│  │  [Property Name/Address]                               │  │  Cream text, shadow overlay
│  │  [Beds] [Baths] [Sq m]                                │  │  Stat strip
│  │                                                        │  │
│  │                ◌ (profile pic zone)                    │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Variations (3):**
- **A — Luxury Home** — Full exterior hero shot. Gold "Luxury Living" badge. Price prominent. Stats row at bottom.
- **B — New Development** — Artist's render or construction photo. "Coming Soon" overlay. Completion date.
- **C — Land/Plot** — Aerial drone shot. Plot dimensions overlaid. "Prime Land" badge.

---

### Type 3: Open House Cover

**Purpose:** Promote an upcoming open house event on the page.

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │              [Property exterior photo]                 │  │  Welcoming daytime shot
│  │                                                        │  │
│  │          ┌────────────────────────────┐                │  │
│  │          │     OPEN HOUSE             │                │  │  Gold badge, centred
│  │          │     This Sunday            │                │  │  Terracotta subtitle
│  │          │     2 PM – 5 PM            │                │  │
│  │          └────────────────────────────┘                │  │
│  │                                                        │  │
│  │  [Address]                    [RSVP: Phone/WhatsApp]   │  │  Bottom info strip
│  │                                                        │  │
│  │                ◌ (profile pic zone)                    │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Variations (3):**
- **A — Standard Open House** — Simple date/time/address. Gold badge. Agent contact.
- **B — Luxury Open House** — "By Invitation Only" messaging. Champagne glass icon. RSVP required.
- **C — Agent Meet & Greet** — Agent headshot included. "Meet [Name] & Tour the Property". Networking angle.

---

## Section 2: Property Banners (3 Types × 3 Variations = 9 Templates)

### Type 1: Listing Highlights Banner

**Purpose:** Shareable image for listing promotion in groups, ads, and posts.

**Dimensions:** 1200 × 628 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │  ┌──────┐              ┌─────────────────────────┐    │  │
│  │  │      │              │  [Property Name]         │    │  │
│  │  │ Photo│              │  [Price]                 │    │  │  Split: image 40%, info 60%
│  │  │      │              │                          │    │  │
│  │  │ 40%  │              │  🛏️ 3 Beds  🛁 2 Baths  │    │  │
│  │  │      │              │  📐 120 sq m  🚗 2 Park │    │  │
│  │  │      │              │                          │    │  │
│  │  │      │              │  ✦ Recently renovated   │    │  │
│  │  │      │              │  ✦ Corner unit          │    │  │
│  │  │      │              │  ✦ Gated community      │    │  │
│  │  └──────┘              └─────────────────────────┘    │  │
│  │                                                        │  │
│  │  [Agent Name]  [Phone]  [WhatsApp]  [Logo]            │  │  Agent strip
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Variations (3):**
- **A — Residential** — House/apt photo left, features right. Standard listing.
- **B — Commercial** — Building exterior left. Investment data right (ROI, sq m, lease rate).
- **C — Land** — Aerial photo left. Dimensions + location highlights right.

---

### Type 2: Featured Properties Banner

**Purpose:** Showcase 3–4 properties in a single image for portfolio overview.

**Dimensions:** 1200 × 628 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐            │  │
│  │  │ Prop 1   │  │ Prop 2   │  │ Prop 3   │            │  │  3-card grid (equal width)
│  │  │ [Photo]  │  │ [Photo]  │  │ [Photo]  │            │  │
│  │  │ [Price]  │  │ [Price]  │  │ [Price]  │            │  │
│  │  │ [Stats]  │  │ [Stats]  │  │ [Stats]  │            │  │
│  │  └──────────┘  └──────────┘  └──────────┘            │  │
│  │                                                        │  │
│  │  "Featured Properties"  [Agent Logo]                  │  │  Header + branding
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Variations (3):**
- **A — 3 Properties** — Standard 3-card grid. Header "Featured Listings".
- **B — 4 Properties** — 2×2 grid. Smaller cards. Header "Portfolio Highlights".
- **C — Price Range** — 3 properties at different price tiers. Header "Homes from KES 5M to KES 50M".

---

### Type 3: Just Sold Banner

**Purpose:** Celebrate a recent sale and attract seller clients.

**Dimensions:** 1200 × 628 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │              [Property photo — desaturated]            │  │  Background image
│  │                                                        │  │
│  │           ┌────────────────────────────┐               │  │
│  │           │          SOLD!             │               │  │  Large SOLD stamp
│  │           │    Another Happy Client    │               │  │  (Charcoal bg, Gold text)
│  │           └────────────────────────────┘               │  │
│  │                                                        │  │
│  │  [Property Address]   ✓ Sold Price: [Amount]           │  │  Bottom info
│  │  [Agent Name]         [Phone]         [Logo]           │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Variations (3):**
- **A — Standard Sold** — Property photo + SOLD stamp + price + agent.
- **B — Fast Sale** — "SOLD in 7 Days!" emphasis. Days-on-market callout. Gold urgency accent.
- **C — Above Asking** — "SOLD Above Asking Price!" Achievement messaging. Terracotta excitement accent.

---

## Section 3: Event Promotions (3 Types × 3 Variations = 9 Templates)

### Type 1: Open House Event Cover

**Purpose:** Facebook event cover for open house listings.

**Dimensions:** 1920 × 1005 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │              [Property photo — exterior]               │  │  Full-bleed hero
│  │                                                        │  │
│  │  ┌────────────────────────────────────────────────┐    │  │
│  │  │           OPEN HOUSE                           │    │  │  Gold banner, centred
│  │  │                                                │    │  │
│  │  │  📅 Sunday, 28 July 2026                      │    │  │  Olive calendar icon
│  │  │  ⏰ 2:00 PM – 5:00 PM                         │    │  │  Terracotta clock icon
│  │  │  📍 [Address]                                 │    │  │  Charcoal location icon
│  │  └────────────────────────────────────────────────┘    │  │
│  │                                                        │  │
│  │  [Agent Name]  [RSVP Phone]  [Logo]                   │  │  Bottom strip
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Variations (3):**
- **A — Standard Open House** — Date, time, address, agent contact.
- **B — Evening Open House** — "Twilight Open House" branding. Evening/blue hour photo. Wine & cheese mention.
- **C — Agent Co-Hosted** — Two agent headshots. "Hosted by [Name] & [Name]". Team branding.

---

### Type 2: Webinar / Educational Event

**Purpose:** Online events — first-time buyer seminars, investor webinars.

**Dimensions:** 1920 × 1005 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │  ┌────────────────────────────────────────────────┐    │  │
│  │  │     FREE WEBINAR                              │    │  │  Olive header bar
│  │  └────────────────────────────────────────────────┘    │  │
│  │                                                        │  │
│  │  [Webinar Title — Playfair Bold 48 pt]                │  │  E.g., "First-Time Home Buyer
│  │                                                        │  │   Masterclass"
│  │  [Subtitle / Description — Lato 20 pt]                │  │
│  │                                                        │  │
│  │  📅 [Date]   ⏰ [Time]   💻 Zoom Link                 │  │  Event details row
│  │                                                        │  │
│  │  ┌─────────────────────────────────────────────┐     │  │
│  │  │        REGISTER NOW — [Link]                │     │  │  Terracotta CTA button
│  │  └─────────────────────────────────────────────┘     │  │
│  │                                                        │  │
│  │  [Agent headshot]  [Name]  "Your Host"               │  │  Host section
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Variations (3):**
- **A — Buyer Seminar** — "First-Time Home Buyer Masterclass". Educational angle.
- **B — Investor Webinar** — "Real Estate Investing in [Year]". Data-driven tone.
- **C — Seller Workshop** — "How to Sell Your Home for Top Dollar". Seller-focused.

---

### Type 3: Property Viewing Day

**Purpose:** Scheduled group viewing event for a specific property.

**Dimensions:** 1920 × 1005 px

**Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│  ┌────────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │  ┌────────────────────────────────────────────────┐    │  │
│  │  │     EXCLUSIVE VIEWING DAY                      │    │  │  Gold header
│  │  └────────────────────────────────────────────────┘    │  │
│  │                                                        │  │
│  │  [Property Name/Address]                               │  │
│  │  [Price]                                                │  │
│  │                                                        │  │
│  │  🛏️ 3 Beds  🛁 2 Baths  📐 120 sq m                 │  │  Key stats
│  │                                                        │  │
│  │  📅 Saturday, 2 August 2026                            │  │
│  │  ⏰ Slots: 10 AM | 11 AM | 12 PM | 2 PM               │  │  Time slots
│  │                                                        │  │
│  │  "Limited slots available — book yours now!"           │  │
│  │  [Book: Phone / WhatsApp / Link]                       │  │
│  │                                                        │  │
│  │  [Agent branding]                                      │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**Variations (3):**
- **A — Residential Viewing** — Standard home viewing. Family-oriented.
- **B — Luxury Preview** — "By Appointment Only". Premium presentation. Champagne imagery.
- **C — Open Day (Multiple Properties)** — "View 5 Properties in One Day". Tour route map.

---

## Posting Specifications

| Element | Specification |
|---|---|
| **Text Overlay Max** | 20% of image area (Facebook's ad policy for text) |
| **Link Preview** | Always include link preview card when sharing to website |
| **Logo Size** | 60 × 60 px max for banner bottom-right |
| **QR Code** | 80 × 80 px minimum for reliable scanning |
| **Font Size Minimum** | 14 pt for body text on mobile readability |

---

## Facebook-Specific Best Practices

1. **Cover photo text:** Keep critical text within the 1230 × 717 px safe zone. The 170 × 170 px profile picture area (bottom-left) must remain clear.
2. **Mobile crop:** Facebook crops cover photos differently on mobile (aspect ratio 1.91:1 vs 2.7:1 on desktop). Test both views.
3. **Banners for ads:** 1200 × 628 px is the standard feed ad size. Always leave bottom 10% clear for the "Sponsored" label that Facebook appends.
4. **Event covers:** 1920 × 1005 px images appear in the event detail page. Ensure the title and date are visible in the top 60%.
5. **Alt text:** Each template should have an alt-text guideline (e.g., "Modern luxury home exterior with pool, overlaid with Open House event details").
