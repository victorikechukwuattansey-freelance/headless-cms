# Day 1 — Behind the Scenes

## Post Type
Behind-the-scenes / personal branding

## Caption Templates

**Template 1 — Office setup**
It's not just a desk — it's where {{AgentName}} helps families find their dream homes. Here's a peek at mission control today. Coffee? Check. Property listings? Check. Client calls lined up? Double check. What does your workspace look like? Drop a photo below 👇

**Template 2 — Property viewing prep**
This is what goes into a single property viewing. I've already called the agent, checked the documents, mapped the route, and studied the neighbourhood — all before my client steps out the door. Preparation is everything in real estate. Do you prep like this before a big appointment?

**Template 3 — Agent morning routine**
Rise and shine ☀️ A typical morning for {{AgentName}}: 6 AM market research, 7 AM client follow-ups, 8 AM out the door for viewings. Real estate doesn't start at 9-to-5, and that's exactly how {{AgentName}} likes it. What time does your day start?

## CTA
- Save this post if you want to see a full day-in-the-life with {{AgentName}}
- Drop a 👋 if you're an early riser too

## Suggested Hashtags
#BehindTheScenes #RealEstateAgentLife #AfricanRealEstate #LagosRealtor #NairobiAgent #AccraProperties #DayInTheLife #AgentLife #RealEstateTips #PropertyAgent

## Image Recommendation
A warm, well-lit photo of your desk/office setup with coffee, laptop, and property brochures. Or a selfie outside a property you're about to show. Natural light preferred.

## Story Idea
**"Prep With Me"** — 5–7 slide Story showing you getting ready for a property viewing: checking documents, reviewing client notes, grabbing keys, driving to the property. Use the question sticker: "What's the first thing you notice when viewing a house?"

## Reel Idea
**60-sec time-lapse** — Fast-motion clip of your morning routine or office setup process. Add trending African Lo-fi or Afrobeat instrumental. Overlay text: "POV: You're a real estate agent in {{Lagos/Nairobi/Accra}}."
