# Day 10 — Open House

## Post Type
Promotional / event announcement

## Caption Templates

**Template 1 — Standard announcement**
🚨 OPEN HOUSE ALERT 🚨

This {{DayOfWeek}}, I'm opening the doors at a stunning {{Bedrooms}}-bedroom {{PropertyType}} in {{PropertyLocation}}.

📅 Date: {{Date}}
⏰ Time: {{Time}}
📍 Location: {{Address}}

✨ {{Bedrooms}} bedrooms, {{Bathrooms}} bathrooms
✨ Modern finish throughout
✨ Walking distance to {{Amenity}}
✨ Price: {{ListingPrice}}

Come see it for yourself. Bring your questions, bring your vision. I'll bring the refreshments 😉

**Template 2 — Limited availability**
Only {{X}} units left in this {{PropertyLocation}} development — and this Saturday is your chance to see one in person.

This {{PropertyType}} offers:
✅ Open-plan living
✅ Rooftop access
✅ 24/7 security
✅ Parking included

Spaces are limited. Confirm your spot by DMing me "OPEN HOUSE."

**Template 3 — First-time buyer focus**
First-time buyers in {{City}} — this one's for YOU 🏡

I'm hosting an open house at {{PropertyLocation}} this {{DayOfWeek}}. Come view the property, ask ALL your questions, and get honest advice with zero pressure. Whether you buy or not, you'll leave smarter.

RSVP via DM. See you there!

## CTA
- DM me "RSVP" to confirm your spot
- Save the date and share with someone who's house-hunting
- Comment "🙋" if you're coming

## Suggested Hashtags
#OpenHouse #PropertyTour #AfricanRealEstate #LagosOpenHouse #NairobiProperty #AccraRealEstate #HomeViewing #HouseHunting #RealEstateEvent #ComeSeeThis

## Image Recommendation
The best exterior or establishing shot of the property. If possible, add a "Open House — {{Date}}" graphic overlay in your brand style. Bright, inviting, professional.

## Story Idea
**"Open House Countdown"** — 24-hour countdown sticker on a photo of the property. Behind-the-scenes slides showing you setting up: putting signs out, arranging refreshments, preparing info packs. Use the location tag to increase local visibility.

## Reel Idea
**30-sec "See You Saturday" teaser** — Quick cuts of the property's best features: kitchen → living room → bedroom → view. Overlay text: "Open House this Saturday. DM to RSVP." End with your photo and name. Energetic background music.
