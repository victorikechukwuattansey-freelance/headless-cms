# Template Build Guide — Affinity Designer

**Build all 8 property flyers and social templates in Affinity Designer 2.**

All instructions assume you've completed the [Affinity Brand Kit Setup](./Affinity-BrandKit-Setup.md) — swatches, text styles, and assets ready.

---

## Affinity Toolkit

### Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl + D` | Duplicate selected |
| `Ctrl + G` | Group selected |
| `Ctrl + Shift + G` | Ungroup |
| `Ctrl + L` | Lock/unlock layer |
| `Shift + drag` | Maintain proportions |
| `Ctrl + drag` (move) | Duplicate while moving |
| `Ctrl + J` | Duplicate layer |
| `Ctrl + [` | Move backward |
| `Ctrl + ]` | Move forward |
| `Ctrl + Shift + [` | Send to back |
| `Ctrl + Shift + ]` | Bring to front |
| `V` | Move tool |
| `M` | Rectangle tool |
| `T` | Text tool |
| `B` | Pen tool |

### Essential Concepts

**Global Colours:** Set via Swatches panel. Change one swatch and all layers using that colour update instantly — like Canva Brand Kit but without a subscription.

**Symbols:** Select a layer → **Layer > Create Symbol**. Duplicates of this symbol update everywhere when you edit any one instance. Use for agent footer, badge, logo — edit once, every flyer updates.

**Master Pages:** In **View > Studio > Pages**, right-click → **Add Master**. Design your base layout once. Apply it to all pages. Great for consistent footer and logo placement across all 8 flyers.

**Styles:** Text styles work like Canva. Change a style definition and every text using that style updates automatically.

---

## Property Flyers

All 8 flyers share the same base. Build the master once, then duplicate and customise.

### Base Document Setup

1. **File > New** → **Print > A4** (or 2480 × 3508 px)
2. DPI: **300** — Colour: **RGB/8** for digital, **CMYK/8** for print
3. Name: `Real Estate Flyers`
4. **View > Studio > Pages** — we'll use multiple pages within one document

### Create a Master Page (shared across all flyers)

1. In Pages panel, right-click → **Add Master** → name it `Flyer Base`
2. Double-click the master to enter edit mode:

**Layer 1 — Background:**
- Rectangle tool (`M`): 2480 × 3508 px
- Fill: Cream swatch (`#F5F0E8`)
- **Layer > Lock** (`Ctrl + L`)

**Layer 2 — Agent Footer:**
- Rectangle: 2480 × 180 px
- Fill: Charcoal swatch (`#2D2D2D`)
- Align bottom: **Layer > Align > Align to Bottom**
- Place headshot: **File > Place** your headshot, resize to 80×80 px, circle crop (Ellipse tool, `Shift` for perfect circle, **Layer > Mask to Below**)
- Place logo: Right side, 100×60 px
- Text — Agent Name: Apply `Body-Bold` style, colour Cream (`#F5F0E8`)
- Text — Phone/Email: Apply `Caption` style, colour Cream

3. When done, return to normal page mode: click the page thumbnail above the master

---

### Flyer Base Recipe (apply to each flyer page)

**Step 1 — New Page**
In Pages panel, click **Add Page** → choose the `Flyer Base` master

**Step 2 — Hero Image**
- **File > Place** your property photo
- Resize to 2480 × 1750 px, align top
- **Layer > Create Clipping Mask** (or use a Rectangle frame to crop)
- Opacity: 100%

**Step 3 — Overlay Badge**
- Rectangle tool: 300 × 90 px
- Fill: Gold swatch (`#C9A84C`)
- **Transform** panel: Rotate -3°
- Position: 60 px from top, 60 px from left
- Text tool (`T`): Inside badge, apply `Badge-Text` style
- Group (`Ctrl + G`) badge rect + text

**Step 4 — Property Title**
- Text tool: Property name
- Apply `Heading-1` style
- Position: Below hero image, 60 px from left

**Step 5 — Price**
- Text tool: Price with currency
- Apply `Price` style
- Position: Below title

**Step 6 — Stats Row**
- Create one stat: Rectangle 80×80 px (Olive swatch, rounded 10 px) + Label (`Body-Bold`) + Value (`Body-Bold`, 20 pt)
- Group all three
- Duplicate 3 times (`Ctrl + D`, drag)
- Space evenly: Select all 4 groups → **Layer > Align > Distribute Horizontally**

**Step 7 — Feature Bullets**
- Text tool: 3-5 features
- Font: Lato Regular, 14 pt, Charcoal
- Bullet: Type `●` (Alt + 7) in Gold or add a small Olive-filled circle before each line
- Position: Below stats row, 60 px left margin

**Step 8 — Export**
- **File > Export** (`Ctrl + Shift + Alt + S`)
- Format: **PNG** (digital) or **PDF** (print)
- DPI: **300**
- Area: **All Pages** to export all 8 flyers at once
- Click **Export**

---

### 1. Luxury Home Flyer

**Badge text:** "LUXURY LIVING"
**Price:** 32 pt, centre-aligned if on its own line
**Colour emphasis:** Gold throughout
**Back page:** Add page 2 to same document:
- Left: Agent bio (3-4 sentences, `Body` style)
- Right: Floor plan placeholder (import as image)
- Bottom: QR code (generate from URL, place as image)

### 2. Apartment Flyer

**Badge:** Terracotta swatch (`#C26A4A`) — "NEW LISTING"
**Amenities grid:** 2 rows × 3 columns below stats
- Each cell: Icon (Emoji or simple shape) + Label
- Icon fill: Olive swatch
- Position: Below stats row

### 3. Land Flyer

**Badge:** Gold — "PRIME LAND"
**Hero image:** Aerial/drone shot preferred
**Plot card:** Rectangle with Charcoal border (2 px), rounded 15 px
- Inside: Plot size, title type (C of O, etc.), zoning
- Background: Cream swatch
**Map:** **File > Place** a map screenshot or draw a simple location marker

### 4. Commercial Flyer

**Badge:** Terracotta — "COMMERCIAL SPACE"
**Features list:** Total area, frontage, parking bays, floors, lifts
- Format: Olive icon + number + label
**Investment highlights:** Gold upwards-trend arrow icons
**CTA button:** Rounded rectangle, Terracotta fill, Cream text — "Schedule a Viewing"

### 5. Rental Flyer

**Badge:** Terracotta (left side) — "FOR RENT"
**Price badge:** Gold rectangle, right side overlaid on hero image
**Price format:** "KES 45K/mo" — apply `Price` style
**Stat row extras:** Add "Furnished/Unfurnished" as 4th stat
**Contact buttons:** Two rounded rects side by side:
- "Call" — Terracotta fill
- "WhatsApp" — Olive fill

### 6. Just Listed Flyer

**Badge:** Gold, diagonal, -5° rotation — "NEW ON THE MARKET"
- Make it large, positioned over the centre of hero image
**Star bullets:** Use Gold star symbol (`✦` via Character Map or copy-paste from web)
**Date:** "Listed [Date]" in Olive italic (apply `Subheading` style and modify)
**SOLD stamp element:** A red (`#D94A4A`) rectangle, -5° rotation, 50% opacity, "SOLD" in Bold 72 pt

### 7. Sold Flyer

**SOLD overlay:** Large Charcoal rectangle, -5° rotation, over centre of hero image
- Text: "SOLD!" in Playfair Display Bold 72 pt, Gold fill
**Subtitle:** "Another Happy Client Served" — Lato Bold 24 pt, Cream
**Sold price:** Gold, 30 pt — apply `Price` style
**Days on market:** Olive text — "Sold in just 14 days"
**Testimonial:** Playfair Display Italic, 22 pt, centre-aligned
**CTA:** Terracotta button — "Looking to buy or sell? Call now!"

### 8. Open House Flyer

**Badge:** Gold — "OPEN HOUSE"
**Sub-badge:** Terracotta text below — "THIS SUNDAY"
**Date & time:** Day = Playfair Display 32 pt, Time = Lato 20 pt
**Refreshments card:** Cream rect with Terracotta border, wine/cheese icon
**Event highlights:** 4 items with icons (Tour, Meet Agent, Market Info, Financing)
**RSVP:** Phone + WhatsApp text, plus QR code placeholder

---

## Batch Export (All Flyers at Once)

1. Ensure all 8 flyers are separate **pages** in the same document (not separate files)
2. **File > Export** (`Ctrl + Shift + Alt + S`)
3. Format: **PNG**
4. Area: **All Pages**
5. DPI: **300** (for print) or **144** (for web)
6. Click **Export** → choose destination folder
7. Affinity names each file automatically: `filename-page-1.png`, etc.

For **social media templates**: Change document size to Instagram Post (1080×1080) or Story (1080×1920) and follow the same layer-by-layer approach.

---

## Affinity-Only Features (Canva Can't Do)

| Feature | What It Means For You |
|---------|----------------------|
| **Master Pages** | Change the footer once, all 8 flyers update. Canva requires editing each page. |
| **Symbols** | Create a badge as a symbol. Duplicate across flyers. Edit one, all update. |
| **Global Colours** | Change Charcoal to a darker shade. Every layer using that swatch updates instantly. |
| **Batch Export** | Export all 8 flyers as individual PNGs in one click. |
| **Macros** | Record yourself editing a photo (resize, colour grade, sharpen). Play it back on all 8 images in one click. |
| **Offline** | No internet required. Everything runs on your machine. |

---

## Export Settings Reference

| Use Case | Format | DPI | Colour | Notes |
|----------|--------|-----|--------|-------|
| Flyer (print) | PDF | 300 | CMYK/8 | Include bleed 3 mm |
| Flyer (digital) | PNG | 144 | RGB/8 | Good for email, WhatsApp |
| Instagram Post | PNG | 144 | RGB/8 | 1080×1080 px |
| Instagram Story | PNG | 144 | RGB/8 | 1080×1920 px |
| Facebook Cover | PNG | 144 | RGB/8 | 1640×856 px |
| Business Card | PDF | 300 | CMYK/8 | 1050×600 px + bleed |

---

Next: Return to [QUICK-START.md](./QUICK-START.md) or the main [README.md](./README.md).
