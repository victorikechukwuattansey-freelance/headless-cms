# Day 3 — Client Testimonial

## Post Type
Social proof / client success story

## Caption Templates

**Template 1 — Buyer success**
"{{AgentName}} made buying our first home stress-free." — {{ClientName}} 🏡

From the first search to handing over the keys, helping {{ClientName}} find their perfect {{PropertyType}} in {{PropertyLocation}} was an absolute privilege. They knew exactly what they wanted, and we found it. This is why I love what I do.

Ready to write your own story? Let's talk.

**Template 2 — Seller success**
Sold in {{X}} weeks — above asking price ✨

{{ClientName}} trusted {{AgentName}} to market and sell their {{PropertyType}} in {{PropertyLocation}}, and the results speak for themselves. Strategic pricing, professional staging, and the right buyers made all the difference.

Want the same result? DM me "SELL" for a free valuation.

**Template 3 — Short & punchy**
Don't take my word for it. Here's what {{ClientName}} had to say about working with {{AgentName}}:

"{{Short quote about service, professionalism, results}}"

Your story could be next. 📲

## CTA
- DM me to start your own journey
- Save this post for when you're ready to buy or sell

## Suggested Hashtags
#ClientTestimonial #HappyClients #RealEstateAgent #LagosRealEstate #NairobiHomes #AccraProperties #ClientLove #RealEstateSuccess #AfricanRealEstate #TestimonialTuesday

## Image Recommendation
Photo of the client holding keys in front of their new home (with written permission). Or a screenshot of a WhatsApp message/testimonial text. Or a photo of you with the client at closing.

## Story Idea
**"Client Says"** — 3-slide carousel: Slide 1 — Client photo + "Meet {{ClientName}}". Slide 2 — Screenshot of their testimonial text. Slide 3 — "Want the same experience? DM me." Use the question sticker: "What matters most to you when choosing an agent?"

## Reel Idea
**45-sec testimonial highlight** — Video of client (or you reading their words) with photos of the property they bought/sold. Add upbeat instrumental. Text overlay rotates through key phrases: "Stress-free" → "Above asking price" → "Dream home found."
