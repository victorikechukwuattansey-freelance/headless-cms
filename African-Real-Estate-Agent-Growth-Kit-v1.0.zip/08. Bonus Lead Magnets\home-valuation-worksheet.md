# Home Valuation Worksheet

> **Target audience:** Homeowners and real estate agents
> **Format:** Print-ready PDF / Digital worksheet
> **Goal:** Estimate a property's market value using comparable sales and a scoring system

---

## How to Use This Worksheet

1. Fill out Sections 1–4 with the property's details
2. Find 3–5 comparable sales in Section 5
3. Calculate the score in Section 6
4. Arrive at the estimated value range in Section 7

---

## Section 1: Property Information

| Field | Value |
|---|---|
| Property address | |
| City / Town | |
| Neighborhood / Estate | |
| Property type | ☐ Bungalow ☐ Duplex ☐ Terrace ☐ Flat ☐ Penthouse ☐ Land |
| Bedrooms | |
| Bathrooms | |
| Toilets | |
| Parking spaces | |
| Land size (sqm) | |
| Floor area (sqm) | |
| Year built | |
| Property condition | ☐ New ☐ Excellent ☐ Good ☐ Fair ☐ Needs renovation |

---

## Section 2: Location Factors

Rate each factor from 1 (poor) to 10 (excellent).

| Factor | Rating (1–10) | Notes |
|---|---|---|
| Road accessibility | | Is the road tarred? All-season access? |
| Security | | Neighborhood crime rate, security patrols? |
| Proximity to CBD | | Distance to city/business center |
| Proximity to schools | | Within 2 km? |
| Proximity to hospitals | | Within 3 km? |
| Proximity to markets | | Grocery, supermarket within 1 km? |
| Public transport | | Bus stop, BRT, taxi rank nearby? |
| Drainage / flood risk | | Any history of flooding in rainy season? |
| Power supply (grid) | | Average hours/day of grid electricity |
| Noise level | | Quiet neighborhood or busy road? |
| **Location Score (total / 100)** | | |

---

## Section 3: Property Specifications

| Feature | Property | Notes |
|---|---|---|
| **Construction quality** | ☐ Standard ☐ Premium ☐ Luxury | |
| **Wall finish** | ☐ Paint ☐ Tile ☐ Stone ☐ Plaster | |
| **Flooring** | ☐ Tiles ☐ Wood ☐ Marble ☐ Vinyl ☐ Concrete | |
| **Windows** | ☐ Lourvers ☐ Casement ☐ Sliding ☐ French | |
| **Ceiling** | ☐ PVC ☐ POP ☐ Asbestos ☐ Wood | |
| **Kitchen** | ☐ Basic ☐ Standard ☐ Modern ☐ Luxury | |
| **Bathroom finish** | ☐ Standard ☐ Modern ☐ Luxury | |
| **AC units** | Number: ___ Type: ☐ Split ☐ Central ☐ Window | |
| **Generator** | Yes / No | Rating: ___ kVA |
| **Inverter / Solar** | Yes / No | Capacity: ___ kW |
| **Borehole** | Yes / No | Depth: ___ ft |
| **Water tank** | Yes / No | Capacity: ___ L |
| **CCTV / Security** | Yes / No | Camera count: ___ |
| **Swimming pool** | Yes / No | |
| **Garden / Yard** | Yes / No | Size: ___ sqm |
| **Staff quarters** | Yes / No | |
| **Servant's bathroom** | Yes / No | |
| **Gated estate** | Yes / No | |
| **Parking** | Open / Carport / Garage | Capacity: ___ |

### Condition Assessment

| Area | Condition | Notes |
|---|---|---|
| Roof | ☐ New ☐ Good ☐ Fair ☐ Poor | |
| Electrical | ☐ New ☐ Good ☐ Fair ☐ Poor | |
| Plumbing | ☐ New ☐ Good ☐ Fair ☐ Poor | |
| Interior paint | ☐ Fresh ☐ Good ☐ Fair ☐ Needs repaint | |
| Exterior paint | ☐ Fresh ☐ Good ☐ Fair ☐ Needs repaint | |
| Kitchen | ☐ Modern ☐ Functional ☐ Needs update | |
| Bathrooms | ☐ Modern ☐ Functional ☐ Needs update | |

---

## Section 4: Market Conditions

### Local Market Indicators

| Indicator | Your Market |
|---|---|
| Average days on market | ☐ < 30 days ☐ 30–90 days ☐ > 90 days |
| Price trend (last 6 months) | ☐ Rising ☐ Stable ☐ Declining |
| Buyer activity level | ☐ High ☐ Moderate ☐ Low |
| Inventory level | ☐ Low (seller's market) ☐ Balanced ☐ High (buyer's market) |
| Season | ☐ Peak season ☐ Off-peak |
| Economic factors | ☐ Stable ☐ Inflation/high rates ☐ Recession |

### Market Adjustment Factors

| Factor | Adjustment |
|---|---|
| Seller's market (low inventory) | +5–10% |
| Buyer's market (high inventory) | -5–10% |
| Peak buying season | +3–5% |
| Off-peak | -3–5% |
| High inflation / interest rates | -5–15% |
| New infrastructure nearby (new road, rail, mall) | +5–15% |
| Upcoming negative development (power plant, dump) | -10–20% |

---

## Section 5: Comparable Sales (Comps)

Find 3–5 similar properties sold in the last 6 months within a 1 km radius.

### Property Features Weighting

| Feature | Weight |
|---|---|
| Location | 30% |
| Size (floor area) | 25% |
| Condition | 20% |
| Amenities | 15% |
| Age | 10% |

### Comparable Sale #1

| Field | Value |
|---|---|
| Address | |
| Sale price | ₦ |
| Sale date | |
| Bedrooms | |
| Floor area (sqm) | |
| Condition | ☐ Excellent ☐ Good ☐ Fair |
| Age | years |
| Key differences from subject property | |

### Comparable Sale #2

| Field | Value |
|---|---|
| Address | |
| Sale price | ₦ |
| Sale date | |
| Bedrooms | |
| Floor area (sqm) | |
| Condition | ☐ Excellent ☐ Good ☐ Fair |
| Age | years |
| Key differences from subject property | |

### Comparable Sale #3

| Field | Value |
|---|---|
| Address | |
| Sale price | ₦ |
| Sale date | |
| Bedrooms | |
| Floor area (sqm) | |
| Condition | ☐ Excellent ☐ Good ☐ Fair |
| Age | years |
| Key differences from subject property | |

### Comparable Sale #4 (Optional)

| Field | Value |
|---|---|
| Address | |
| Sale price | ₦ |
| Sale date | |
| Bedrooms | |
| Floor area (sqm) | |
| Condition | ☐ Excellent ☐ Good ☐ Fair |
| Age | years |
| Key differences from subject property | |

### Comparable Sale #5 (Optional)

| Field | Value |
|---|---|
| Address | |
| Sale price | ₦ |
| Sale date | |
| Bedrooms | |
| Floor area (sqm) | |
| Condition | ☐ Excellent ☐ Good ☐ Fair |
| Age | years |
| Key differences from subject property | |

### Comps Summary

| Comp | Price | Price/sqm | Adjustment | Adjusted Price |
|---|---|---|---|---|
| #1 | ₦ | ₦ | ± % | ₦ |
| #2 | ₦ | ₦ | ± % | ₦ |
| #3 | ₦ | ₦ | ± % | ₦ |
| #4 | ₦ | ₦ | ± % | ₦ |
| #5 | ₦ | ₦ | ± % | ₦ |
| **Average** | | | | **₦** |

### Adjustment Guidelines

| Difference | Adjustment |
|---|---|
| Subject has 1 more bedroom | +10% to comp |
| Subject is in better condition | +10–15% to comp |
| Subject has AC/generator/inverter | +5–10% each |
| Subject is older by 5+ years | -5–10% from comp |
| Comp sold 6+ months ago | +2–3% per month (appreciation) |

---

## Section 6: Scoring System

This system gives a quick valuation based on property quality.

### Score Points

| Category | Max Points |
|---|---|
| Location (Section 2 score / 10) | 10 |
| Construction quality | 10 |
| Bedroom count (2pts each, max 10) | 10 |
| Amenities (AC, generator, inverter, borehole, pool — 2pts each) | 10 |
| Condition (new=10, excellent=8, good=6, fair=4, poor=2) | 10 |
| Age (<5yr=10, <10yr=8, <20yr=5, 20+=2) | 10 |
| Floor area (large=10, medium=7, small=4) | 10 |
| Parking (garage=5, carport=3, open=1) | 5 |
| Security features | 5 |
| Market adjustment (Section 4) | 5 |

### Score Sheet

| Category | Points | Max |
|---|---|---|
| Location | | 10 |
| Construction quality | | 10 |
| Bedroom count | | 10 |
| Amenities | | 10 |
| Condition | | 10 |
| Age | | 10 |
| Floor area | | 10 |
| Parking | | 5 |
| Security | | 5 |
| Market adjustment | | 5 |
| **Total Score** | | **85** |

### Score-to-Value Mapping

| Score | Value per sqm (Nigeria — approximate) |
|---|---|
| 70–85 | Premium — top 20% of market |
| 55–69 | Above average |
| 40–54 | Average |
| 25–39 | Below average |
| 0–24 | Needs significant work |

**Your score:** ___ / 85 → Category: ________________

---

## Section 7: Estimated Value Range

### Method A — Comparable Sales Approach

**Average adjusted price from comps:** ₦________________

### Method B — Score-Based Approach

| Component | Value |
|---|---|
| Average price/sqm in area | ₦ |
| Your property size (sqm) | |
| Base value (price/sqm × size) | ₦ |
| Score multiplier (score/85) | |
| Score-adjusted value | ₦ |

### Final Value Range

| Value | Amount |
|---|---|
| **Conservative estimate** (Method A × 0.9) | ₦ |
| **Fair market value** (average of both methods) | ₦ |
| **Optimistic estimate** (Method A × 1.1) | ₦ |

### Recommendation

| Suggested asking price | ₦ |
|---|---|
| Minimum acceptable price | ₦ |
| Suggested listing price range | ₦ – ₦ |

---

## Notes & Observations

- 

---

## Disclaimer

This worksheet provides an **estimate only** and does not constitute a professional valuation. For an official valuation, engage a certified estate surveyor and valuer registered with the Nigerian Institution of Estate Surveyors and Valuers (NIESV) or the equivalent body in your country.
