# Mortgage Calculator Guide & Sample Amortization Table

> **Target markets:** Nigeria, Ghana, Kenya
> **Format:** Digital download (recreate in Excel / Google Sheets)
> **Goal:** Help buyers understand mortgage costs and plan their budget

---

## Current African Mortgage Context (2026)

### Nigeria

| Metric | Value |
|---|---|
| Average mortgage interest rate | 18–25% per annum |
| Typical LTV (Loan-to-Value) | 70–75% (buyer pays 25–30% deposit) |
| Maximum tenure | 15–20 years |
| Typical monthly payment (₦10M loan, 20%, 15yr) | ~₦180,000 – ₦220,000 |
| Primary lenders | Access Bank, Fidelity, GTBank, First Bank, Sterling |
| NHF (National Housing Fund) rate | 6% (limited availability, capped at ₦15M) |

### Ghana

| Metric | Value |
|---|---|
| Average mortgage interest rate | 25–30% per annum |
| Typical LTV | 60–70% |
| Maximum tenure | 10–15 years |
| Primary lenders | Fidelity Bank Ghana, Stanbic, Republic Bank, HFC Bank |

### Kenya

| Metric | Value |
|---|---|
| Average mortgage interest rate | 10–14% per annum |
| Typical LTV | 80–90% (with mortgage insurance) |
| Maximum tenure | 20–25 years |
| Primary lenders | KCB, Equity Bank, Stanbic, HF Group, NCBA |

---

## Key Mortgage Terms

| Term | Definition |
|---|---|
| **Principal (P)** | The loan amount you borrow |
| **Interest Rate (r)** | Annual interest rate, divided by 12 for monthly rate |
| **Tenure (n)** | Total number of monthly payments (e.g., 15 years = 180 months) |
| **LTV (Loan-to-Value)** | Loan amount as a percentage of property price |
| **Amortization** | Gradual repayment of principal over time |
| **Equity** | Your ownership stake (property value minus loan balance) |

---

## Mortgage Payment Formula

### Monthly Payment (Fixed Rate)

The standard formula for calculating your monthly mortgage payment:

```
M = P × [r(1+r)^n] / [(1+r)^n - 1]
```

Where:
- **M** = Monthly payment
- **P** = Principal loan amount
- **r** = Monthly interest rate (annual rate ÷ 12)
- **n** = Total number of payments (years × 12)

### Example Calculation

**Scenario:** ₦15,000,000 loan at 20% per annum for 15 years

```
P = ₦15,000,000
r = 20% / 12 = 1.667% = 0.01667
n = 15 × 12 = 180 months

M = 15,000,000 × [0.01667(1.01667)^180] / [(1.01667)^180 - 1]
M = 15,000,000 × 0.01736
M = ₦260,447 per month
```

**Total repayment over 15 years:** ₦260,447 × 180 = **₦46,880,460**
**Total interest paid:** ₦46,880,460 - ₦15,000,000 = **₦31,880,460**

---

## Excel / Google Sheets Formula

```excel
=PMT(rate, nper, pv, [fv], [type])
```

### Usage

| Cell | Value | Formula |
|---|---|---|
| A1 | Interest Rate (annual) | 20% |
| A2 | Tenure (years) | 15 |
| A3 | Loan Amount | 15,000,000 |
| A4 | Monthly Payment | `=PMT(A1/12, A2*12, -A3)` |

**Result:** ₦260,447

### Functions You'll Need

| Function | Purpose |
|---|---|
| `=PMT(rate, nper, pv)` | Calculate monthly payment |
| `=PPMT(rate, per, nper, pv)` | Principal portion of a specific payment |
| `=IPMT(rate, per, nper, pv)` | Interest portion of a specific payment |
| `=CUMIPMT(rate, nper, pv, start, end, type)` | Cumulative interest between two periods |
| `=CUMPRINC(rate, nper, pv, start, end, type)` | Cumulative principal between two periods |

---

## Sample Amortization Table (First 12 Months)

**Loan:** ₦15,000,000 | **Rate:** 20% | **Tenure:** 15 years | **Monthly Payment:** ₦260,447

| Month | Opening Balance | Monthly Payment | Interest Paid | Principal Paid | Closing Balance |
|---|---|---|---|---|---|
| 1 | ₦15,000,000 | ₦260,447 | ₦250,000 | ₦10,447 | ₦14,989,553 |
| 2 | ₦14,989,553 | ₦260,447 | ₦249,826 | ₦10,621 | ₦14,978,932 |
| 3 | ₦14,978,932 | ₦260,447 | ₦249,649 | ₦10,798 | ₦14,968,134 |
| 4 | ₦14,968,134 | ₦260,447 | ₦249,469 | ₦10,978 | ₦14,957,156 |
| 5 | ₦14,957,156 | ₦260,447 | ₦249,286 | ₦11,161 | ₦14,945,995 |
| 6 | ₦14,945,995 | ₦260,447 | ₦249,100 | ₦11,347 | ₦14,934,648 |
| 7 | ₦14,934,648 | ₦260,447 | ₦248,911 | ₦11,536 | ₦14,923,112 |
| 8 | ₦14,923,112 | ₦260,447 | ₦248,719 | ₦11,729 | ₦14,911,383 |
| 9 | ₦14,911,383 | ₦260,447 | ₦248,523 | ₦11,924 | ₦14,899,459 |
| 10 | ₦14,899,459 | ₦260,447 | ₦248,324 | ₦12,123 | ₦14,887,336 |
| 11 | ₦14,887,336 | ₦260,447 | ₦248,122 | ₦12,325 | ₦14,875,011 |
| 12 | ₦14,875,011 | ₦260,447 | ₦247,917 | ₦12,530 | ₦14,862,481 |

### Year-End Summary

| Year | Total Payment | Total Interest | Total Principal | Balance |
|---|---|---|---|---|
| 1 | ₦3,125,364 | ₦2,983,845 | ₦141,519 | ₦14,858,481 |
| 5 | ₦15,626,820 | ₦13,831,702 | ₦1,795,118 | ₦13,204,882 |
| 10 | ₦31,253,640 | ₦22,395,917 | ₦8,857,723 | ₦6,142,277 |
| 15 | ₦46,880,460 | ₦31,880,460 | ₦15,000,000 | ₦0 |

---

## Affordability Calculator

Use this worksheet to determine what you can afford.

### Inputs

| Item | Your Value |
|---|---|
| Monthly net income | ₦ |
| Other loan payments (car, personal) | ₦ |
| Monthly expenses (living costs) | ₦ |
| **Available for mortgage** | ₦ |
| Desired property price | ₦ |
| Available deposit (25–30%) | ₦ |

### Affordability Check

| Rule | Calculation |
|---|---|
| **Debt-to-Income (DTI)** ≤ 40% | Total monthly debts ÷ Monthly income × 100 = ___% |
| **Mortgage Payment** ≤ 30% of income | Estimated payment ÷ Monthly income × 100 = ___% |
| **Emergency Fund** ≥ 3 months payments | 3 × Monthly payment = ₦ |

### Maximum Loan Calculator

| Loan Amount | Monthly Payment (20%, 15yr) | Monthly Payment (20%, 20yr) |
|---|---|---|
| ₦5,000,000 | ₦86,816 | ₦82,828 |
| ₦10,000,000 | ₦173,631 | ₦165,656 |
| ₦15,000,000 | ₦260,447 | ₦248,484 |
| ₦20,000,000 | ₦347,262 | ₦331,312 |
| ₦25,000,000 | ₦434,078 | ₦414,140 |
| ₦30,000,000 | ₦520,893 | ₦496,968 |

---

## Total Cost of Ownership (Year 1)

| Expense | Monthly | Annual |
|---|---|---|
| Mortgage payment | ₦260,447 | ₦3,125,364 |
| Property insurance | ₦12,500 | ₦150,000 |
| Estate service charge | ₦8,333 | ₦100,000 |
| Maintenance (1% of value/year) | ₦20,833 | ₦250,000 |
| Utilities (estate levy) | ₦5,000 | ₦60,000 |
| Generator fuel | ₦30,000 | ₦360,000 |
| **Total** | **₦337,113** | **₦4,045,364** |

---

## Tips for Buyers

1. **Pay a larger deposit** — A 30% deposit vs. 20% can save ₦millions in interest over the loan term.
2. **Negotiate the interest rate** — Banks often quote their upper range first. Ask for a reduction, especially if you have an existing relationship.
3. **Shorter tenure = lower total interest** — A 10-year mortgage costs less overall than 15 years, even if monthly payments are higher.
4. **Watch for hidden fees** — Banks may charge processing fees (1–2% of loan), legal fees, and valuation fees. Ask for an all-in quote.
5. **Consider NHF mortgage** (Nigeria) — If eligible, 6% interest on up to ₦15M is significantly cheaper than commercial rates.
6. **Factor in inflation** — In Nigeria (20%+ inflation), your effective mortgage cost decreases over time as the naira devalues. Fixed-rate mortgages are advantageous in high-inflation environments.
