# First-Time Home Buyer Checklist — African Markets

> **Target market:** Nigeria, Ghana, Kenya, South Africa
> **Format:** Print-ready PDF / Digital download
> **Goal:** Guide first-time buyers through every step of purchasing their first home

This checklist covers the complete journey from financial readiness to closing. Tick off each item as you complete it.

---

## Section 1: Financial Readiness

Before you start viewing properties, make sure your finances are in order.

### 1.1 Savings & Budget

- [ ] Calculate total budget (property price + legal fees + agency fee + moving costs)
- [ ] Confirm minimum 20–30% deposit for mortgage (Nigerian banks typically require 25–30%)
- [ ] Set aside 7–10% of property price for closing costs (legal, registration, stamp duty)
- [ ] Have 3–6 months of mortgage payments in emergency savings
- [ ] Factor in service charge / estate dues (₦50,000–₦200,000/year for Lagos estates)

### 1.2 Credit & Documentation

- [ ] Obtain your credit report (CRC Credit Bureau or FirstCentral in Nigeria)
- [ ] Check credit score — Nigerian mortgage lenders prefer 650+ (on a 500–900 scale)
- [ ] Dispute any errors on your credit report
- [ ] Gather 6 months of bank statements
- [ ] Collect 3 months of payslips (employed) or 2 years of audited accounts (self-employed)
- [ ] Prepare tax clearance certificate (last 3 years)

### 1.3 Mortgage Pre-Approval

- [ ] Compare offers from at least 3 banks (e.g., Access, GTBank, Fidelity for Nigeria)
- [ ] Submit pre-approval application
- [ ] Receive pre-approval letter (valid for 90 days typically)
- [ ] Understand interest rate type: fixed vs. floating
- [ ] Confirm maximum Loan-to-Value (LTV) ratio (typically 70–75% in Nigeria)

**Nigerian Context:** Most mortgage lenders offer 15–20 year tenures with interest rates between 18–25% per annum. Ghanaian mortgages average 25–30% with 10–15 year tenures. Kenyan rates are lower at 10–14% with up to 25 years.

---

## Section 2: Property Search

### 2.1 Define Requirements

- [ ] Determine minimum square footage / room count
- [ ] Choose preferred locations (consider commute, security, amenities)
- [ ] Decide on property type (flat, duplex, terrace, detached bungalow)
- [ ] List must-have vs. nice-to-have features
- [ ] Set maximum price

### 2.2 Search Channels

- [ ] Browse property listing sites (PropertyPro.ng, Jiji.ng, Meqasa.com, BuyRentKenya)
- [ ] Contact 3–5 real estate agents in target locations
- [ ] Join local real estate WhatsApp/Facebook groups
- [ ] Drive around target neighborhoods — look for "For Sale" signs
- [ ] Ask friends, family, and colleagues for referrals

### 2.3 Viewing Preparation

- [ ] Schedule viewings (best during daylight)
- [ ] Bring this checklist to each viewing
- [ ] Take photos and videos (with agent's permission)
- [ ] Time the commute from property to work
- [ ] Visit at different times of day (traffic, noise, security at night)

---

## Section 3: Documentation Needed

In African real estate markets, proper documentation is critical. Missing documents can lead to loss of property.

### 3.1 Seller's Documents to Request

- [ ] **Certificate of Occupancy (C of O)** — Confirms government ownership grant (Nigerian requirement)
- [ ] **Governor's Consent** — Required for property transfer in Lagos and some other states
- [ ] **Survey Plan** — Shows property boundaries and measurements
- [ ] **Deed of Assignment / Conveyance** — Proves previous transfer of ownership
- [ ] **Building Plan Approval** — Confirms structure was legally approved
- [ ] **Receipts for Ground Rent / Property Tax** — Proof of payments
- [ ] **Land Use Charge Receipts** — Lagos property tax evidence
- [ ] **Certificate of Occupancy (for land)** — If purchasing undeveloped land
- [ ] **Power of Attorney** — If seller is not the direct owner

### 3.2 Buyer's Documents

- [ ] Valid government-issued ID (International Passport, Driver's License, National ID)
- [ ] Passport photographs (6 copies minimum)
- [ ] 6 months bank statements
- [ ] Payslips / employment letter / proof of income
- [ ] Tax Identification Number (TIN)
- [ ] Completed offer letter / expression of interest

---

## Section 4: Property Inspection Checklist

Take this with you to every viewing.

### 4.1 Structure & Exterior

- [ ] Check walls for cracks (horizontal cracks may indicate foundation issues)
- [ ] Inspect ceiling for water stains or leaks
- [ ] Test all windows and doors (open, close, lock)
- [ ] Check roof condition from inside (attic/ceiling board)
- [ ] Examine external drainage — no standing water near foundation
- [ ] Verify property boundary matches survey plan

### 4.2 Interior

- [ ] Turn on all lights — check electrical wiring
- [ ] Test all power outlets with a phone charger
- [ ] Flush all toilets — check water pressure and drainage
- [ ] Run taps in kitchen and bathrooms — hot and cold
- [ ] Check under sinks for leaks or mold
- [ ] Open kitchen cabinets — check for pests or water damage

### 4.3 African-Specific

- [ ] **Generator:** Check model, age, service history, fuel consumption
- [ ] **Inverter/Solar:** Confirm capacity (kVA), battery type, inverter brand, age
- [ ] **Water Tank:** Capacity (liters), material (plastic vs. concrete), pump condition
- [ ] **Borehole:** Depth, pump type, water quality test, age of system
- [ ] **Security:** Gates, guard house, CCTV, neighborhood security arrangement
- [ ] **Waste Disposal:** Septic tank / sewage connection, last emptying date

---

## Section 5: Legal Due Diligence

**Do not skip this section.** Land disputes are the #1 cause of property loss in Nigeria.

- [ ] Engage a licensed property lawyer (notary public is NOT enough)
- [ ] Conduct **Land Registry Search** — verify seller is the legal owner
- [ ] Conduct **Land Use Charge Search** — confirm no outstanding government charges
- [ ] Verify **Governor's Consent** has been obtained for previous transfers
- [ ] Conduct **Physical Inspection** of property to check for disputes
- [ ] Request **Family Meeting** (if property is family land) — get all family members' consent
- [ ] Check for **statutory mortgages** — property must not be used as collateral elsewhere
- [ ] Confirm **no demolition order** or acquisition notice from government
- [ ] Verify **Building Plan Approval** — unauthorized buildings can be demolished
- [ ] Obtain **Encumbrance Certificate** — confirms no legal claims against property

### Red Flags — Walk Away If:

- [ ] Seller refuses to provide original C of O
- [ ] Multiple "owners" claim the same property
- [ ] Property is under litigation (pending court case)
- [ ] Survey plan doesn't match physical boundaries
- [ ] Seller insists on "family receipt" instead of proper title documents
- [ ] Price is significantly below market value
- [ ] Seller demands cash-only payment (no bank transfer trail)

---

## Section 6: Closing Steps

### 6.1 Before Payment

- [ ] Sales agreement / Contract of Sale reviewed by lawyer
- [ ] Payment schedule agreed (typically: 10% deposit → 40% → 50%)
- [ ] Payment method confirmed (bank transfer — never cash)
- [ ] Clear timeline for each payment milestone
- [ ] Agree on who pays for: stamp duty, registration fees, legal fees, agency commission

### 6.2 During Payment

- [ ] Obtain stamped receipt for every payment
- [ ] Keep all bank transfer confirmations
- [ ] Ensure deed of assignment is signed at payment completion
- [ ] Apply for Governor's Consent (buyer's responsibility in Lagos)
- [ ] Register the property at the Land Registry in buyer's name

### 6.3 After Closing

- [ ] Collect all original documents (C of O, survey, deed, receipts)
- [ ] Update utility accounts to your name (electricity, water, waste)
- [ ] Pay service charge / estate dues
- [ ] Change locks and security codes
- [ ] Set up home insurance (building insurance recommended in Nigeria)
- [ ] Introduce yourself to neighbors and estate management

---

## Estimated Timeline

| Stage | Duration |
|---|---|
| Financial preparation | 2–6 months |
| Property search & viewings | 1–3 months |
| Legal due diligence | 2–4 weeks |
| Payment & transfer | 2–4 weeks |
| Governor's Consent | 3–6 months (Lagos) |
| **Total** | **6–14 months** |

> **Pro Tip:** Start the Governor's Consent application process immediately after payment — it's the longest step in Nigerian property purchase.
