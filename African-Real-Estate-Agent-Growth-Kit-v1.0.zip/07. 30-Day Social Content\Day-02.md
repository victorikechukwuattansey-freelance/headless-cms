# Day 2 — Luxury Property

## Post Type
Lifestyle / high-end listing showcase

## Caption Templates

**Template 1 — The lifestyle pitch**
Step inside this {{Bedrooms}}-bedroom luxury apartment in the heart of {{PropertyLocation}}. Floor-to-ceiling windows, premium finishes, and a view that will take your breath away. This isn't just a home — it's a lifestyle upgrade. Who's ready to live like this? 🏡✨

**Template 2 — Feature spotlight**
Let's talk about this kitchen 😍 Custom cabinetry, quartz countertops, and a layout designed for entertaining. This {{PropertyType}} in {{PropertyLocation}} was built for people who love to host. Which room would you spend the most time in?

**Template 3 — Investment-grade luxury**
Luxury real estate in Africa is growing — and {{PropertyLocation}} is leading the way. This {{PropertyType}} isn't just beautiful; it's a smart investment in one of the continent's fastest-appreciating markets. Priced at {{ListingPrice}}. Let's talk.

## CTA
- DM me "LUXURY" for an exclusive video tour
- Tag someone who deserves to live here

## Suggested Hashtags
#LuxuryRealEstate #AfricanLuxury #LagosLuxury #NairobiRealEstate #AccraRealEstate #DreamHome #LuxuryLiving #PropertyTour #RealEstateAfrica #HomeGoals

## Image Recommendation
High-quality, well-lit wide shot of the living room or outdoor area. Natural light, no clutter. If exterior, golden hour is best. Professional photos only.

## Story Idea
**"Luxury Countdown"** — Carousel of 5 premium features (pool, view, kitchen, master suite, rooftop). Add a "Swipe up to tour" link or "DM for price" sticker on each slide. Use the poll sticker: "Modern or Classic style?"

## Reel Idea
**30-sec cinematic tour** — Slow-motion walkthrough with smooth transitions. Start wide, move through hallway, end at the best view. Sound: trending chill RnB or piano track. Text overlay: "Luxury lives here — {{PropertyLocation}}."
