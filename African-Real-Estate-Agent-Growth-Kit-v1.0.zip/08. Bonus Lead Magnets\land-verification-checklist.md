# Land Verification Checklist — African Real Estate

> **Target markets:** Nigeria (primary), Ghana, Kenya
> **Format:** Print-ready PDF / Digital download
> **Goal:** Help buyers verify land ownership before purchase — avoid land disputes and scams

**Warning:** Land disputes account for over 30% of court cases in Nigeria. Never purchase land without completing every step in this checklist.

---

## Why Land Verification Matters

| Risk | Consequence |
|---|---|
| Purchasing from a non-owner | Total loss of investment |
| Family land sold without consent | Court case, property revoked |
| Government acquisition | Property demolished, no compensation |
| Multiple sales of same plot | Long legal battle, potential loss |
| Encumbered property (used as collateral) | Bank repossesses the land |

---

## Step 1: Survey Plan Verification

A survey plan is the official map showing the land's boundaries, dimensions, and location.

### Checklist

- [ ] Survey plan prepared by a **licensed surveyor** (confirmed with SURCON — Surveyors Council of Nigeria)
- [ ] Surveyor's seal and signature present and authentic
- [ ] Plan shows the **land's coordinates** (GPS / geodetic)
- [ ] Plan shows **beacon numbers** and positions (physical markers on the ground)
- [ ] Plan is **stamped and registered** at the State Surveyor General's office
- [ ] Verify the plan number at the State Survey Department — confirm it belongs to this parcel
- [ ] Cross-check the survey plan with **physical beacons** on site — do the boundaries match?
- [ ] Confirm the plan is not a **"carved out"** plan from a larger unregistered survey

### What to Look For

- **Authentic survey plans** have a file number, sheet number, and surveyor's registration number.
- **Red flags:** No GPS coordinates, no surveyor's seal, claimed land size does not match physical measurement, photocopy instead of original.
- If the land is in a government-acquired area (e.g., some parts of Lekki, Ibeju-Lekki corridor), the survey plan may be rejected during registration.

### Cost

- Survey plan verification at Surveyor General's office: ₦5,000–₦15,000

---

## Step 2: Certificate of Occupancy (C of O) Verification

The C of O is the most important land document in Nigeria. It proves the government has granted the owner a statutory right of occupancy.

### Checklist

- [ ] Request the **original** C of O (not photocopy)
- [ ] Verify the C of O number with the State Land Registry
- [ ] Confirm the C of O is in the **seller's name** (or assignor's name with valid transfer)
- [ ] Check the C of O **expiry date** (statutory right of occupancy is typically 99 years)
- [ ] Verify the property **description** on C of O matches the survey plan
- [ ] Confirm the **size of land** matches between C of O and survey plan
- [ ] Check for **encumbrances/conditions** on the C of O (e.g., state government reserved rights)
- [ ] Ensure the C of O is **stamped** with the Land Registry stamp
- [ ] Confirm **ground rent** has been paid — request current receipts

### What to Look For

- A genuine C of O has watermarks, security features, and Registry stamps.
- **Red flags:** Seller claims C of O is "in process" but cannot produce acknowledgment letter — this often means no C of O exists.
- C of Os issued before 1978 may have different terms — check validity carefully.

### Cost

- C of O verification at Land Registry: ₦5,000–₦30,000 (depending on state)

---

## Step 3: Governor's Consent

In Lagos State (and some others), the Governor's Consent is required for any transfer of land ownership. Without it, the sale is legally incomplete.

### Checklist

- [ ] If property has previously been transferred, confirm **Governor's Consent was obtained**
- [ ] If not yet obtained, confirm that **application for Consent is in process** — request the acknowledgment letter
- [ ] Check the **Consent status** at the Lands Bureau
- [ ] If seller is selling for the first time after receiving C of O, **Consent is still required** to transfer to you
- [ ] Budget for Consent fees: typically **2–4% of the property value** (paid by buyer)

### Important Notes

- **Lagos State:** Consent processing takes 3–6 months after application. Start immediately after payment.
- **Ogun State:** Faster — typically 4–8 weeks.
- **Rivers State:** Similar to Lagos, 3–6 months.
- **FCT Abuja:** Uses "Right of Occupancy" — similar process through the FCT Administration.

---

## Step 4: Family Land History Check

Many land disputes in Nigeria arise from family land being sold without all family members' consent.

### Checklist

- [ ] Determine if the land is **family land** or **individual property**
- [ ] If family land, meet with the **family head / principal members**
- [ ] Obtain a **Family Consent Letter** signed by all principal family members
- [ ] Verify the consent letter with the **family lawyer** (if any)
- [ ] Confirm the **sale proceeds** are being distributed to the family (not just one person)
- [ ] Check if any family member has previously sold or transferred their portion
- [ ] Ask about **pending family disputes** over the land
- [ ] Speak to **neighbors** — do they know the family? Any history of disputes?

### Red Flags

- One person claiming to represent "the entire family" without written authorization
- Family members refusing to be present at the meeting
- No clear documentation of how the family acquired the land
- Pressure to complete sale within 24–48 hours

---

## Step 5: Encroachment Check

Encroachment occurs when a neighbor has built on or occupied part of the land.

### Physical Inspection

- [ ] Walk the **entire boundary** with the survey plan in hand
- [ ] Identify all **beacons** — are they still in place?
- [ ] Measure from beacons to confirm the boundary lines
- [ ] Note any structures built over or near the boundary
- [ ] Check if **neighbors have fenced** beyond their proper boundary
- [ ] Look for **makeshift structures** on the land
- [ ] Ask neighbors: "How long has this land been open? Who do you know as the owner?"

### Signs of Encroachment

- Fences that cut across the surveyed boundary
- Buildings that extend beyond where the beacon indicates
- Neighbors claiming portions of the land as their own
- Discrepancies between survey plan dimensions and actual land dimensions

---

## Step 6: Local Authority Search

Check with the local government or planning authority for government acquisition and development plans.

### Checklist

- [ ] **Visit the Local Government secretariat** where the land is located
- [ ] Check if the land is in a **government acquisition zone**
- [ ] Ask about **road expansion plans** — some roads may eat into the land
- [ ] Check **zoning regulations** — can you build residential/commercial on this land?
- [ ] Enquire about **upcoming government projects** (new road, flyover, railway) that may affect the land
- [ ] Check if there is an **existing demolition order** on the land
- [ ] **Letter of no objection / consent to build** available in this area?

### Why This Matters

- Land acquired by the government for "public interest" may not be compensated if developed
- Planned roads can significantly reduce your land size
- Some areas are designated for specific use (e.g., only residential, not commercial)

---

## Step 7: Land Registry Search

The official search at the State Land Registry is the most authoritative way to verify ownership.

### What to Request

- **Form 1C (Search Application)** — available at the Land Registry
- Pay the search fee and obtain a **Search Report**
- The report will confirm:
  - [ ] **Current registered owner** of the land
  - [ ] **Outstanding charges** (ground rent, land use charge)
  - [ ] **Encumbrances** (loans, mortgages, caveats)
  - [ ] **Pending litigation** involving the land
  - [ ] **Previous transactions** recorded against the land

### Types of Search

| Search Type | What It Covers | Cost (Approx.) |
|---|---|---|
| **Registry Search** | C of O records, registered deeds | ₦10,000–₦25,000 |
| **Land Use Charge Search** | Outstanding LUC payments (Lagos) | ₦5,000–₦10,000 |
| **GIS Search** | GIS survey data, property coordinates | ₦10,000–₦20,000 |
| **Caveat Search** | Any caveat/lis pendens on the land | ₦5,000–₦10,000 |

### Instructions

- Searches can be done at the **Land Registry** in the state where the property is located
- **Lagos:** Lands Bureau, Alausa, Ikeja
- **Abuja:** FCT Land Administration, Area 1 Layout
- Use a registered lawyer or a licensed search agent — they know the process
- A clean search report means the seller has clear title — proceed with confidence

---

## Step 8: Engage a Property Lawyer

**Never** complete a land purchase without an independent lawyer who represents you — not the seller.

- [ ] Engage a lawyer who specializes in **property/conveyancing law**
- [ ] Lawyer to conduct **independent search** at Land Registry (not relying on seller's search)
- [ ] Lawyer to draft or review the **Deed of Assignment**
- [ ] Lawyer to witness **signing of agreements**
- [ ] Lawyer to ensure **stamp duty** is paid and document is registered
- [ ] Lawyer to follow up on **Governor's Consent** application

### Recommended Lawyer Fee

- Typically **5–10% of property value** for full conveyancing service
- Some lawyers charge a flat fee of ₦150,000–₦500,000 depending on complexity

---

## Summary: Complete Before You Pay

| # | Step | Status | Notes |
|---|---|---|---|
| 1 | Survey Plan Verification | ☐ | |
| 2 | C of O Verification | ☐ | |
| 3 | Governor's Consent Check | ☐ | |
| 4 | Family Land History | ☐ | |
| 5 | Encroachment Check | ☐ | |
| 6 | Local Authority Search | ☐ | |
| 7 | Land Registry Search | ☐ | |
| 8 | Lawyer Engagement | ☐ | |

**Do not make any payment until Steps 1–7 are complete and a lawyer has reviewed the documents.**

---

## Estimated Costs

| Item | Cost (₦) |
|---|---|
| Survey Plan Verification | 5,000 – 15,000 |
| C of O Verification | 5,000 – 30,000 |
| Land Registry Search | 10,000 – 25,000 |
| GIS Search | 10,000 – 20,000 |
| Local Authority Check | 5,000 – 10,000 |
| Lawyer Fee | 150,000 – 500,000 |
| Stamp Duty (buyer portion) | ~0.5% of property value |
| Governor's Consent | 2–4% of property value |
| **Total estimated** | **₦400,000 – ₦1,500,000+** |

> **Pro Tip:** Never skip the Land Registry Search and physical inspection. These two steps catch 90% of land fraud cases in Nigeria.
