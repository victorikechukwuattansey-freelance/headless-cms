# TikTok Ads — Ready-to-Film Scripts for African Real Estate Agents

---

## Script 1: "Stop Designing Like This" (30–60 seconds)

### Hook Analysis

The first 3 seconds compare an ugly flyer to a professional one — a visual shock that stops the scroll. Viewers instantly categorise themselves on one side or the other.

### Script Breakdown

| Time | Visual | Text Overlay | Audio / Voiceover |
|---|---|---|---|
| 0:00–0:04 | Close-up on an ugly, poorly designed property flyer. Bad font. Blurry image. Cluttered layout. Hand holding it slightly tilted. | POV text: "You're still designing like this?" | Audio: Trend transition sound (whoosh / vinyl scratch) |
| 0:04–0:08 | Zoom out. Same hand, same phone/tablet. Now showing a **stunning Canva template** from the kit. Clean layout, professional fonts, beautiful property image. | Text: "Imagine posting like this instead." | VO: "What if I told you professional listings are just one click away?" |
| 0:08–0:15 | Quick montage — 4–5 templates flipping on screen (listing post, story, reel cover, flyer, open house sign). Each holds for ~1.5 seconds. | Text (each card): "Listing Post / Story / Reel / Flyer / Open House" | Audio: Upbeat, trending background track (low volume) |
| 0:15–0:25 | Cut to a mockup phone screen showing a "Download — Instant Access" page. Finger taps the button. | Text: "300+ Real Estate Canva Templates. Instant Download." | VO: "300+ templates. Done for you. Ready to customize." |
| 0:25–0:30 | Headshot-style selfie clip with the creator (you) holding a tablet showing the kit dashboard. Smiling, confident. | Text: "Link in bio. Go get it." | VO: "Stop designing like an amateur. Start booking inspections." |
| 0:30–0:35 | End card — Kit title, price ($39), checkmark list of 3 key features, CTA arrow pointing to link in bio. | Text: "African Real Estate Agent Growth Kit / $39 / 300+ Templates / Content Calendar / WhatsApp Scripts" | Audio: Sound fades out. |

### Audio Suggestions

| Element | Recommendation |
|---|---|
| **Transition** | Whoosh or vinyl scratch sound effect (stock TikTok sounds) |
| **Background** | Chill afrobeats instrumental (e.g., instrumental Amapiano, Afrobeat type beat) — royalty-free from TikTok sound library |
| **Voiceover** | Warm, confident, mid-tempo. Record on a decent microphone (or phone with quiet room). |

### Text Overlay Specs

| Element | Spec |
|---|---|
| Font | Sans-serif, bold (TikTok default or Montserrat) |
| Position | Centre-safe zone (avoid bottom 20% for caption overlap) |
| Duration | Matches scene; minimum 1.5s for readability |
| Animation | Fade-in or typewriter effect for POV text; quick zoom for punchlines |

### Timing Notes

- **0–3 seconds**: Must hook. Ugly flyer vs. implication. No time to waste.
- **3–8 seconds**: Value reveal. Show the solution. Keep it visual.
- **8–20 seconds**: Proof. Show the product (templates flipping). Let them imagine using it.
- **20–28 seconds**: Social proof / CTA. Selfie clip builds trust. Link in bio.
- **28–35 seconds**: End card. Reinforce value. Restate price. CTA.

---

## Script 2: "Everything I Use to Market Million-Naira Properties" (15–30 seconds)

### Script Breakdown

| Time | Visual | Text Overlay | Audio |
|---|---|---|---|
| 0:00–0:04 | POV — looking down at a laptop folder titled "REAL ESTATE KIT" with thumbnails of templates visible inside. Hand hovers over mouse. | Hook text: "Everything I use to market million-naira properties... fits inside ONE folder." | Audio: Satisfying typing sound + quiet lo-fi beat |
| 0:04–0:10 | Fast scroll through the folder — template files flash by (listing posts, stories scripts, WhatsApp PDFs, ad copy docs). Each file type visible briefly. | Text: "300+ Canva Templates / WhatsApp Scripts / FB Ads / TikTok Scripts" | VO: "Templates. Scripts. Ads. A full content calendar. All here." |
| 0:10–0:15 | Cut to selfie — creator (you) leaning in, phone showing the Gumroad/Selar download page. | Text: "Link in bio. $39. Start today." | VO: "Professional marketing for African real estate agents. Link in bio." |

### HashTag Strategy

#### Nigerian Real Estate

```
#LagosRealEstate #NigeriaProperty #LagosAgent #NigeriaRealEstate #PropertyNaija #LagosRealtor #AfricaRealEstate #CanvaTemplates #RealEstateMarketing #DigitalMarketingNigeria
```

#### Ghanaian Real Estate

```
#AccraRealEstate #GhanaProperty #AccraAgent #GhanaRealEstate #PropertyGhana #GhanaRealtor #AccraProperties #RealEstateTips #CanvaTemplates #MarketingGhana
```

#### Kenyan Real Estate

```
#NairobiRealEstate #KenyaProperty #NairobiAgent #KenyaRealEstate #PropertyKE #NairobiRealtor #KenyanAgent #RealEstateMarketing #CanvaTemplates #MarketingKE
```

#### General / Pan-African

```
#AfricanRealEstate #RealEstateAgent #PropertyMarketing #CanvaForRealEstate #RealEstateTips #RealEstateHack #RealtorLife #ProptechAfrica #RealEstateBranding #AgentGrowth
```

### Best Performing Posting Times (Local Time)

| Market | Best Times | Second Best |
|---|---|---|
| **Nigeria (WAT)** | 12:00–14:00, 18:00–20:00 | 20:00–22:00 |
| **Ghana (GMT)** | 12:00–14:00, 17:00–19:00 | 19:00–21:00 |
| **Kenya (EAT)** | 12:30–14:30, 18:00–20:00 | 20:00–22:00 |
| **South Africa (SAST)** | 12:00–14:00, 17:00–19:00 | 19:00–21:00 |

*Optimal days: Tuesday–Thursday. Avoid Monday mornings and Sunday evenings.*

---

## General TikTok Best Practices for African Real Estate Marketing

### 1. Hook Strategy

The first 3 seconds decide whether a user watches or scrolls. Use these proven hooks:

| Hook Type | Example |
|---|---|
| **Pattern Interrupt** | "Stop scrolling." (with direct eye contact) |
| **Before/After** | Ugly flyer → stunning template (visual only, no intro) |
| **Curiosity Gap** | "The one tool that doubled my real estate leads in a week." |
| **Direct Question** | "Are your property posts getting 10 likes or 100?" |
| **Promise** | "I'll show you how to market any property in under 5 minutes." |

### 2. Trending Audio & Niche

- Use TikTok's "Add Sound" to find trending audio. Filter by region (Nigeria, Ghana, Kenya, South Africa) to find sounds trending in your target market.
- Pair trending audio with niche content — the algorithm boosts videos using trending sounds, and the niche (real estate) targets the right audience.
- **Recommended audio niches**: Afrobeats, Amapiano instrumental, Gen Z business chatter, "day in my life" vlog-style audio.

### 3. Content Pillars for Real Estate TikTok

| Pillar | Examples | Frequency |
|---|---|---|
| **Education** | "3 things buyers look for in a property listing" | 40% |
| **Behind-the-Scenes** | "How I film a property for Instagram" | 25% |
| **Product Showcase** | "This template doubled my engagement" | 20% |
| **Personal / Story** | "Why I created this kit for agents like you" | 15% |

### 4. Video Format Best Practices

| Element | Recommendation |
|---|---|
| **Aspect Ratio** | 9:16 vertical (1080 × 1920) |
| **Length** | 15–45 seconds (longer if high retention) |
| **Captions** | Always add captions — TikTok auto-captions or manual |
| **Text Overlay** | Keep in centre-safe zone (avoid bottom 20% for caption overlap and top 10% for system UI) |
| **First Frame** | Must communicate value immediately — no black screens or slow fade-ins |
| **Call to Action** | "Link in bio" or "Follow for more real estate tips" — never an external link in video |
| **Posting Frequency** | 1× per day minimum during campaign; 3–5× per week for organic growth |

### 5. CTA Strategy on TikTok

TikTok **does not allow clickable links in captions** (except for Branded Content ads and the bio link). Use:

- **Organic**: "Link in bio" — then update your bio link to the checkout page.
- **Paid (Spark Ads / In-Feed Native)**: Use TikTok Ads Manager to create In-Feed Native ads with a clickable CTA button (Download Now, Learn More, Get Started). Boost top-performing organic content as Spark Ads for authenticity.

### 6. Engagement Tactics

| Tactic | How |
|---|---|
| **Reply with Video** | When someone comments a question, reply with a video showing the answer (boosts engagement and reach) |
| **Duet / Stitch** | Duet or stitch testimonials or reviews from buyers who recommend the kit |
| **Series** | Create a 3-part series: Part 1 (Problem), Part 2 (Solution), Part 3 (Results) — keeps viewers coming back |
| **Sound Sync** | Align template reveal or flyer transformation with a beat drop in the music |
| **Text Overlay Animations** | Use TikTok's text animation presets (Typewriter, Fade, Zoom) to keep visual interest high |

### 7. Paid Campaign Setup Checklist

- [ ] TikTok Ads Manager account created
- [ ] Target: African countries (Nigeria, Ghana, Kenya, South Africa)
- [ ] Age: 25–45
- [ ] Interests: Real Estate, Property, Home Improvement, Business, Entrepreneurship, Canva, Design
- [ ] Placement: For You Feed (exclude Pangle)
- [ ] Daily budget: $10–$30 to start
- [ ] Creative: Use Script 1 or 2 above as in-feed native ad
- [ ] CTA: "Download Now" or "Learn More"
- [ ] Landing page: Gumroad, Selar, or direct checkout page
- [ ] Pixel installed on landing page for retargeting

### 8. Ad Creative Specs for TikTok

| Specification | Requirement |
|---|---|
| Resolution | 1080 × 1920 px (9:16) |
| File Type | MP4 or MOV |
| Duration | 5–60 seconds (recommended 15–30s) |
| File Size | Max 500 MB |
| Captions | Required (burned in or SRT) |
| Text Overlay | Keep within safe zone (centre 60% of screen) |
| Sound | Original or royalty-free TikTok sound |
| Aspect Ratio | 9:16 only |
| Frames Per Second | 30 fps minimum |

### 9. Tracking & Measurement

| Metric | Target | What It Means |
|---|---|---|
| **View Rate** | 70%+ at 3s | Strong hook |
| **Average Watch Time** | 15s+ (for 30s video) | High retention |
| **CTR** | 0.5%–1% | Effective CTA |
| **CPM** | $5–$15 | Competitive for African markets |
| **Conversion Rate** | 2%+ | Landing page working |
| **Cost Per Result** | < $5 per download | Profitable campaign |

---

## Quick-Reference Summary Card

```
┌──────────────────────────────────────────┐
│  TIKTOK AD QUICK REFERENCE               │
│                                          │
│  Posting: Tue–Thu, 12–2pm & 6–8pm        │
│  Length:  15–30 seconds                  │
│  Format:  9:16 vertical (1080×1920)      │
│  Hook:    First 3 seconds or nothing      │
│  Audio:   Trending + Afrobeats/Amapiano  │
│  CTA:     Link in bio (organic)          │
│           Download Now (paid)            │
│  Budget:  Start at $10/day               │
│  Hashtags: 5–10 per post (mix broad+niche)│
└──────────────────────────────────────────┘
```
