# Day 4 — Buying Tips

## Post Type
Educational / first-time home buyer advice

## Caption Templates

**Template 1 — The checklist**
Buying your first home in {{Country/City}}? Here are 5 things you need to do BEFORE you start viewing properties:

1. ✅ Check your credit score
2. ✅ Get pre-approved for a mortgage
3. ✅ List your must-haves vs nice-to-haves
4. ✅ Research neighbourhoods thoroughly
5. ✅ Find a trusted agent (hi, that's me 👋)

Which step are you stuck on? Let's talk in the comments.

**Template 2 — The money talk**
Here's the truth about buying your first home: you don't need 100% of the money today. But you DO need a plan. Between mortgages, cooperative societies, and rent-to-own options, there are more paths to homeownership in Africa than ever before. Let's find yours.

**Template 3 — The dream starter**
You've been scrolling through listings for months. You know exactly what you want. But something's holding you back. Here's my advice: start the conversation. One DM, one consultation, one step. You don't have to buy today — but you can plan today.

## CTA
- DM me "PLAN" for a free first-time buyer consultation
- Save this post for your home-buying journey
- Share with someone who's ready to buy

## Suggested Hashtags
#FirstTimeHomeBuyer #BuyingTips #RealEstateAdvice #AfricanRealEstate #LagosProperties #NairobiRealEstate #AccraRealEstate #HomeBuyingTips #RealEstateTips #PropertyAdvice

## Image Recommendation
Clean flat lay: a notebook, pen, calculator, house keys, and a "SOLD" graphic on a desk. Or a photo of you looking at a property with a client, pointing something out.

## Story Idea
**"Home Buyer Quiz"** — 5-slide quiz: "True or False — You need 20% deposit to buy a home." Reveal the answer on the next slide. End with "DM me if you got less than 3/5 — I'll help you build a plan."

## Reel Idea
**60-sec "5 Mistakes First-Time Buyers Make"** — Hold up 5 fingers, count them down one by one with text overlays. Mistakes: No pre-approval, skipping inspection, ignoring hidden costs, emotional buying, no agent. Fast cuts, conversational tone, direct-to-camera.
