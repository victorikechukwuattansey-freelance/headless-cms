# Day 26 — Agent Q&A

## Post Type
Interactive / engagement

## Caption Templates

**Template 1 — Open floor**
You ask, I answer 🎤

For the next 24 hours, I'm opening the floor. Drop any real estate question you have — about buying, selling, renting, investing, or the market in {{City}}.

Nothing is too basic, too silly, or too complicated. I'll answer every single question in the comments and on my Stories.

Go ahead — hit me with your best question 👇

**Template 2 — From the DMs**
I get a LOT of questions in my DMs. Here are a few I haven't answered publicly yet:

Q: "Is it safe to buy property as a diaspora buyer?"
A: {{Answer}}

Q: "Can I use my pension fund to buy a house?"
A: {{Answer}}

Q: "What's the one thing you wish every buyer knew?"
A: {{Answer}}

Got a question that's not here? Drop it below 👇

**Template 3 — Rapid fire**
Rapid-fire Q&A — {{AgentName}} edition 🔥

Q: Favourite neighbourhood in {{City}}?
A: {{NeighborhoodName}}

Q: Best time of year to buy?
A: {{Answer}}

Q: One advice for new agents?
A: {{Answer}}

Q: Biggest myth about African real estate?
A: {{Answer}}

Your turn — ask me anything in the comments.

## CTA
- Drop your question in the comments
- DM me if your question is personal/private
- Save this post to come back and check my answers

## Suggested Hashtags
#AskMeAnything #QandA #RealEstateQandA #AfricanRealEstate #LagosAgent #NairobiRealtor #AccraAgent #RealEstateQuestions #AgentAnswers #CommunityEngagement

## Image Recommendation
A photo of you with a microphone, or a casual selfie with a "Ask Me Anything" text overlay, or a graphic with a Q&A theme in your brand colours. Relaxed, approachable vibe.

## Story Idea
**"Live Q&A"** — Use the question sticker: "Ask me anything about real estate in {{City}}." Let questions come in throughout the day. Pick the best 5 and answer each on a separate story slide. Tag the users who asked.

## Reel Idea
**60-sec "Answering Your Questions"** — Direct-to-camera. Pick 3–4 real questions you've received. Answer each in 10–15 seconds. Fast cuts between questions. Text overlay shows each question before you answer. End with "Got a question? Drop it in the comments."
