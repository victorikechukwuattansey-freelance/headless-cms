# Video 2: Creating Reels for Real Estate

> **Length:** 25–35 minutes
> **Level:** Beginner
> **Prerequisites:** Instagram or Facebook account, CapCut app (free)

---

## Learning Objectives

By the end of this video, the viewer will be able to:

1. Plan and storyboard a real estate Reel
2. Film property walkthroughs that look professional
3. Edit Reels in-app (Instagram) or in CapCut
4. Use trending audio and hashtags for real estate
5. Post Reels that get views and leads

---

## Script Outline

### Hook (0:00–0:30)

"Properties filmed on a phone with no planning get zero engagement. Properties filmed with this simple formula get 10x more views. I'm going to show you the formula."

### Introduction (0:30–1:30)

- Why Reels matter for real estate in 2026
- The Instagram algorithm prioritizes Reels over static posts
- Real estate Reels can generate DM leads without ads

### Main Content

#### Part 1: Reel Types That Work for Real Estate (1:30–7:00)

1. **Property tour** (walkthrough with music — 15–30 sec)
2. **Before/After** (renovation, staging transformation)
3. **Neighborhood tour** (local market, school, park — 10 sec)
4. **Client testimonial** (happy buyer/seller — 30–60 sec)
5. **Tips & education** ("3 things to check before buying a house")
6. **Behind the scenes** (agent life, showing prep)
7. **Show screen recording of examples** of each type

#### Part 2: Filming Like a Pro on Your Phone (7:00–14:00)

1. Clean your lens (yes, this matters!)
2. Shoot horizontally and vertically (separate takes)
3. Walk slowly — 2 seconds per room minimum
4. Use a gimbal or stabilizer (or brace phone against chest)
5. Natural light is your best friend — film between 10 AM – 2 PM
6. Start each room at the doorway (establish the space)
7. **Camera settings:** 4K at 30fps or 60fps
8. **Audio:** External microphone if speaking, music otherwise
9. **Screen recording:** Show good vs. bad filming examples

#### Part 3: Editing in CapCut (14:00–22:00)

1. Import clips to CapCut
2. Trim and arrange (doorway → room → next doorway)
3. Add transitions (none or very subtle — dissolves only)
4. Add background music (trending or royalty-free)
5. Text overlays (property price, location, bedrooms, your name)
6. Auto-captions (if speaking)
7. Export settings (1080p, 30fps, high quality)
8. **Exercise:** Edit a 15-second Reel from 3 raw clips

#### Part 4: Posting & Optimizing (22:00–28:00)

1. In Instagram: Cover image (pick the best frame)
2. Caption formula:
   - Hook (first line — most important)
   - 2–3 emojis
   - Property details (3–4 bullet points)
   - Call to action ("DM for viewing")
   - 5–10 hashtags
3. Tag location (do this every time)
4. Post at optimal times (12 PM – 2 PM or 6 PM – 8 PM local time)
5. Share to Feed AND Story after posting
6. **Exercise:** Write a caption for your Reel

### Key Takeaways (28:00–33:00)

1. First 3 seconds determine if someone watches — hook immediately
2. Show the best room first, not the living room by default
3. Music should match the vibe (luxury = chill, family = upbeat)
4. Consistency beats perfection — post 3–4 Reels per week
5. Always include a clear CTA — what should the viewer do next?

### CTA (33:00–35:00)

- "Film one property this week and post a Reel"
- Next video: "Running Facebook & Instagram Ads"

---

## Practical Exercise

**Assignment:** Film a 15–30 second Reel of a property (yours or a client's). Edit in CapCut. Post to Instagram with the caption formula above.

**Submission:** Link to the published Reel

---

## Reel Length Guidelines

| Platform | Optimal Length | Max Length |
|---|---|---|
| Instagram Reel | 15–30 sec | 90 sec |
| Facebook Reel | 15–30 sec | 60 sec |
| TikTok | 15–60 sec | 10 min |
| YouTube Shorts | 15–60 sec | 60 sec |

## Trending Real Estate Hashtags (Nigeria/Africa)

```
#LagosRealEstate #AbujaProperty #NigeriaRealEstate #PropertyNigeria
#RealEstateAgent #HouseHunting #DreamHome #PropertyTour #LuxuryHomes
#RealEstateNigeria #AfricanRealEstate #HomeBuying #FirstTimeBuyer
#PropertyInvestor #RealEstateMarketing #RealEstateTips
```

## Resource Links

- CapCut: https://www.capcut.com (free)
- InShot (alternative): https://inshot.com
- Trending audio finder: Instagram Reels tab → search "real estate"
- Royalty-free music: https://www.epidemicsound.com (paid), https://pixabay.com/music (free)
