# 30-Day Social Content Calendar

## Overview

This module gives you **30 days of ready-to-post social media content** purpose-built for the African real estate market. Every post is designed to position you as a trusted, professional, and relatable agent — whether you work in Lagos, Nairobi, Accra, Johannesburg, or any other African city.

## How It Works

Each day's file contains:

| Element | Purpose |
|---|---|
| **Post Type** | The content format and category |
| **Caption Templates** | 2–3 fill-in-the-blank variations you can customise |
| **CTA** | Clear calls to action to drive engagement or leads |
| **Hashtags** | 5–10 per post mixing popular and niche African real estate tags |
| **Image Recommendation** | What visual to pair with the post |
| **Story Idea** | An interactive Instagram Story concept |
| **Reel Idea** | A 30–60 second video concept |

## How to Adapt Month-to-Month

### 1. Keep the Structure, Swap the Content

The 30-day framework is reusable every month. Just update:

- **Market data** — refresh Day 9 (Market Update) and Day 19 (Market Analysis) with current numbers
- **Seasonal references** — swap holidays (Day 24) for the current month (e.g. Ramadan, Christmas, Easter, New Year)
- **Listings** — replace featured properties on Day 2, 18, 21, 25, and 27 with active inventory
- **Testimonials** — rotate in fresh client stories for Day 3, 13, 17, and 28

### 2. Follow the Engagement Rhythm

| Day | Theme | Goal |
|---|---|---|
| 1–7 | Relationship building & education | Warm trust, show personality |
| 8–14 | Value demonstration | Prove expertise, answer questions |
| 15–21 | Niche deep-dives | Cover specific buyer/seller needs |
| 22–28 | Authority & community | Establish expertise, nurture leads |
| 29–30 | Review & preview | Recap wins, tease what's next |

### 3. Mix Platforms

| Post | Where to Publish |
|---|---|
| Caption + Image | Instagram Feed, Facebook, LinkedIn |
| Story | Instagram Story, Facebook Story |
| Reel | Instagram Reels, TikTok, YouTube Shorts, Facebook Reels |

### 4. Track What Works

- Use Instagram Insights / Facebook Analytics to note which post types get the most saves, shares, and DMs
- After 30 days, double down on the 5–7 highest-performing formats
- Archive underperforming day templates and swap in new angles

## Personalisation Placeholders

All templates use these placeholders — replace them before posting:

| Placeholder | What to put |
|---|---|
| `{{AgentName}}` | Your name |
| `{{AgencyName}}` | Your agency/brand |
| `{{PropertyLocation}}` | City, neighbourhood, or estate |
| `{{ListingPrice}}` | Price in local currency |
| `{{Bedrooms}}` | Number of bedrooms |
| `{{PropertyType}}` | e.g. apartment, duplex, bungalow, land |
| `{{ClientName}}` | Client's name (with permission) |
| `{{NeighborhoodName}}` | Name of the area featured |
| `{{Month}}` | Current month |
| `{{Year}}` | Current year |

## Recommended Posting Schedule

| Day | Time (local) | Platform Priority |
|---|---|---|
| Mon–Fri | 12:00–13:00 or 18:00–20:00 | Instagram > LinkedIn > Facebook |
| Saturday | 10:00–12:00 | Instagram > Facebook > TikTok |
| Sunday | 16:00–18:00 | Facebook > Instagram > LinkedIn |

## Tools to Prepare

- **Canva** — Create branded templates so you can swap images in seconds
- **Your Camera Roll** — Take 10–15 property, neighbourhood, and behind-the-scenes photos this week
- **Content Folder** — Save all 30 images/videos in a dated folder for quick access
- **Scheduler** — Use Meta Business Suite, Hootsuite, or Buffer to batch-schedule weekly

## Results to Expect

If you post consistently for 30 days:

- **Week 1**: Profile visits increase 2–3×
- **Week 2**: DMs and inquiries begin
- **Week 3**: Shares and saves grow as value content builds trust
- **Week 4**: Inbound leads from people who have been watching all month
