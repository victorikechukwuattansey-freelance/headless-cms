# Abandoned Checkout Recovery — WhatsApp Autoresponder Drip

> **Use with:** Selar, Paystack, or Flutterwave payment links
> **Trigger:** Customer visits checkout page but does not complete payment
> **Tool:** WhatsApp Business API or third-party broadcast tool (WATI, WABA, Interakt, etc.)
> **Duration:** 5 days | **Message type:** Template messages (pre-approved)

## Compliance Notice

Under **WhatsApp Business Messaging Policy** (2024–2026):

- All messages in this drip must be sent as **pre-approved template messages** (not free-form).
- Templates must be **submitted to Meta for approval** before use.
- Customers must have **opted in** to receive marketing/retargeting messages from your business.
- Include an **opt-out mechanism** (e.g., "Reply STOP to unsubscribe") in at least the first message.
- Do not send messages outside **8 AM – 8 PM** local time.
- This drip is classified as **post-purchase / customer care** — it has a higher template quality rating than promotional messages.

> **Disclaimer:** WhatsApp messaging regulations change frequently. Consult a legal professional for compliance in your specific jurisdiction (Nigeria, Ghana, Kenya, South Africa, etc.).

---

## Drip Sequence

### Day 1 — Recovery (30–60 minutes after abandonment)

**Template name:** `abandoned_checkout_day1`

```
Hi {{FirstName}},

Looks like you were checking out the African Real Estate Agent Growth Kit but didn't complete your order.

If you had any issues with payment, simply reply to this message and I'll help you out.

Your instant download is waiting whenever you're ready.

👉 {{CheckoutLink}}

Reply STOP to opt out of these messages.
```

**Send window:** 30–60 minutes post-abandonment
**Goal:** Remove friction, offer support

---

### Day 2 — Urgency (24 hours after Day 1)

**Template name:** `abandoned_checkout_day2`

```
Quick reminder, {{FirstName}}:

Every day you delay is another day your competitors look more professional online while your listings blend in.

Get instant access to the full kit below.

{{CheckoutLink}}
```

**Send window:** 24 hours after Day 1
**Goal:** Trigger FOMO / competitive instinct

---

### Day 3 — Value Breakdown (48 hours after Day 1)

**Template name:** `abandoned_checkout_day3`

```
{{FirstName}}, here's exactly what you're getting:

✅ Canva Templates — edit & post in minutes
✅ Social Media Content — 30 days scheduled
✅ Facebook & Instagram Ads — done-for-you creatives
✅ TikTok Ads — trending scripts included
✅ WhatsApp Scripts — convert chats into clients
✅ Lead Magnets — build your email list fast

Everything is ready for immediate download.

{{CheckoutLink}}
```

**Send window:** 48 hours after Day 1
**Goal:** Reinforce value proposition

---

### Day 4 — Problem/Solution (72 hours after Day 1)

**Template name:** `abandoned_checkout_day4`

```
{{FirstName}}, many agents spend hours every week creating posts, designing graphics, and writing captions from scratch.

This kit helps reduce that effort with 40+ ready-to-customize templates so you can focus on what matters — closing deals.

Access yours here:

{{CheckoutLink}}
```

**Send window:** 72 hours after Day 1
**Goal:** Highlight pain point (time waste)

---

### Day 5 — Final Notice (96 hours after Day 1)

**Template name:** `abandoned_checkout_day5`

```
Final reminder, {{FirstName}}.

If you're still interested in the African Real Estate Agent Growth Kit, you can complete your order below.

{{CheckoutLink}}

Questions? Just reply to this message and I'll be happy to help.

This is the last message you'll receive about this.
```

**Send window:** 96 hours after Day 1
**Goal:** Last chance + open support channel

---

## Setup Instructions

1. **Create templates** in WhatsApp Business Manager → Message Templates → Create
2. Submit each of the 5 templates above for Meta approval (allow 24–48 hours)
3. **Map your checkout integration:**
   - **Selar:** Use the webhook/API to capture abandoned carts
   - **Paystack:** Enable transaction verification + abandoned cart event
   - **Flutterwave:** Use the event hooks for failed/incomplete transactions
4. **Connect** your broadcast tool (WATI, Interakt, WABA Cloud API) to trigger each template at the specified interval
5. **Test the flow** end-to-end with a test transaction

## Opt-Out Management

- Add `Reply STOP to opt out` to Day 1 message (required by Meta policy)
- Process opt-outs within 24 hours
- Maintain a suppression list in your CRM/Google Sheet
- Do not re-send to opted-out numbers for 90 days

## Performance Benchmarks

| Metric | Good | Great |
|---|---|---|
| Day 1 Click Rate | 8–12% | 15%+ |
| Overall Recovery Rate | 5–10% | 12%+ |
| Opt-Out Rate | < 2% | < 1% |
| Template Rejection Rate | < 5% | 0% |
