# Affinity Brand Kit Setup Guide

Set up your Affinity Photo 2 or Affinity Designer 2 workspace with the complete brand palette, styles, and assets in under 10 minutes.

---

## What You'll Need

- Affinity Photo 2 or Affinity Designer 2 (v2.0+)
- Your logo (PNG with transparent background, minimum 200×200 px)
- Your agent photo (headshot, minimum 400×400 px)

---

## Step 1: Create a New Document

1. Open Affinity Photo/Designer
2. **File > New** (or `Ctrl + N`)
3. Choose **Print > A4** (2480 × 3508 px) for flyers, or **Web > Instagram Post** (1080 × 1080 px) for social templates
4. Set DPI to **300** for print, **144** for digital
5. Colour format: **RGB/8** for digital, **CMYK/8** for print
6. Click **Create**

---

## Step 2: Add Brand Swatches

1. Open the **Swatches** panel (**View > Studio > Swatches**)
2. Click the panel menu (hamburger icon) → **Add Swatch from Colour**
3. Enter each colour:

| Colour | Hex | Usage |
|--------|-----|-------|
| Charcoal | `#2D2D2D` | Headlines, footer backgrounds, primary text |
| Cream | `#F5F0E8` | Page backgrounds, card backgrounds |
| Terracotta | `#C26A4A` | Badges, CTA buttons, accent highlights |
| Olive | `#7B8D5D` | Icons, checkmarks, stat numbers, nature associations |
| Gold | `#C9A84C` | Prices, premium badges, achievement accents |

4. Save the palette: Swatches panel menu → **Save Swatches** → Name it `real-estate-brand`
5. In future documents: Swatches panel menu → **Load Swatches** → pick the saved file

**Pro tip:** Add tints by clicking the colour in Swatches → **Add Tint** → choose 20%, 40%, 60% opacity versions for backgrounds.

---

## Step 3: Set Up Text Styles

1. Open the **Text Styles** panel (**View > Studio > Text Styles**)
2. Click **Create New Style** for each:

| Style Name | Font | Size | Weight | Colour | Leading |
|------------|------|------|--------|--------|---------|
| `Heading-1` | Playfair Display | 36 pt | Bold | Charcoal | 110% |
| `Heading-2` | Playfair Display | 28 pt | Bold | Charcoal | 110% |
| `Subheading` | Playfair Display | 22 pt | Italic | Terracotta | 120% |
| `Body` | Lato | 14 pt | Regular | Charcoal | 140% |
| `Body-Bold` | Lato | 14 pt | Bold | Charcoal | 140% |
| `Caption` | Lato | 11 pt | Regular | Charcoal | 130% |
| `Price` | Playfair Display | 30 pt | Bold | Gold | 100% |
| `Badge-Text` | Lato | 10 pt | Bold | Charcoal | 100% |

3. For each style:
   - Double-click the style name to rename
   - Right-click → **Edit** → set font, size, colour, leading
   - Right-click → **Apply Style** to selected text

**Install missing fonts:** Download Playfair Display and Lato from Google Fonts ([fonts.google.com](https://fonts.google.com)). Install the `.ttf` files, then restart Affinity.

---

## Step 4: Create Reusable Assets

1. Draw commonly used elements (badge rectangle, stats icon, CTA button)
2. Select the element → **View > Studio > Assets**
3. Click **Add from Selection** (or drag into Assets panel)
4. Organise into categories:

| Category | Assets |
|----------|--------|
| Badges | Gold badge (rect, 300×90 px, `#C9A84C`), Terracotta badge, Olive badge |
| Buttons | CTA button (Terracotta bg, 40 px padding, rounded 8 px) |
| Icons | Stat icon base (80×80 px, Olive, rounded 10 px) |
| Footer | Agent footer bar (2480×180 px, Charcoal) |

5. In future documents: Assets panel menu → **Export/Import Assets** to share across all your templates.

---

## Step 5: Import Logo & Headshot

1. **File > Place** (`Ctrl + Shift + P`) → select your logo PNG
2. Position it, resize as needed
3. Lock the layer: **Layer > Lock** (`Ctrl + L`)
4. Repeat for your headshot photo
5. Save as an Asset (Step 4) for one-click placement in future documents

---

## Step 6: Save as Template

1. **File > Save as Template**
2. Name it: `African Real Estate Agent Flyer`
3. Tick: **Include swatches**, **Include text styles**, **Include assets**
4. Next time: **File > New from Template** to start instantly

---

## Affinity vs Canva — Key Differences

| Feature | Canva | Affinity |
|---------|-------|----------|
| Cost | Free/Pro ($13/mo) | One-time purchase ($70) |
| Offline | Internet required | Fully offline |
| Brand Kit | Pro feature | Free (Swatches + Styles) |
| Master pages | Not supported | **Supported** (like PowerPoint slide master) |
| Symbols | Not supported | **Supported** (linked copies update globally) |
| Batch export | Manual | **File > Export > Batch** |
| DPI control | Limited | Full control |
| CMYK print | Pro only | Full support |
| Plugins/scripts | Limited | Full scripting (macros + batch jobs) |

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Can't find Playfair Display | Download from Google Fonts, install `.ttf`, restart Affinity |
| Colours look different on screen | Use RGB/8 for digital, CMYK/8 for print. Our hex codes are for RGB. |
| Swatches not saving | Ensure you click **Save Swatches** (not just add to document palette) |
| Text styles not applying | Select text layer first, then double-click the style |
| Logo appears pixelated | Re-export at minimum 200×200 px, PNG with transparent background |
| Can't find Assets panel | **View > Studio > Assets** or reset studio: **View > Studio > Reset Studio** |

---

Next: Open the [Affinity Template Build Guide](./Template-Build-Guide-Affinity.md) to build your first flyer, or return to the main [QUICK-START.md](./QUICK-START.md).
