# Day 5 — Mortgage Advice

## Post Type
Educational / financing guidance

## Caption Templates

**Template 1 — Options overview**
Thinking about a mortgage in {{Country}}? Here's what you need to know:

🏦 **Commercial banks** — Traditional mortgages, 15–20 year terms
🤝 **Cooperative societies** — Lower rates, member-based
🏠 **Rent-to-own** — Move in now, own later
💼 **Employer schemes** — Some companies offer housing support
📦 **Developer financing** — Direct payment plans from builders

Every option has pros and cons. The right one depends on YOUR situation. Let's find it together.

**Template 2 — Pre-approval power**
Before you fall in love with a property, get pre-approved. Here's why:
- You'll know exactly what you can afford
- Sellers take you more seriously
- You can close faster
- No last-minute financing heartbreak

Pre-approval = peace of mind. DM me and I'll connect you with trusted mortgage advisors.

**Template 3 — Myth vs fact**
Myth: You need a perfect credit score to get a mortgage in Africa.

Fact: Many banks and cooperative societies work with first-time buyers who have modest credit history. The key is having a stable income, a solid down payment, and the right guidance.

Don't let myths stop you from owning your dream home.

## CTA
- DM me "MORTGAGE" for a free consultation
- Save this post for your financial planning
- Tag someone who's thinking about buying

## Suggested Hashtags
#MortgageAdvice #HomeFinancing #AfricanRealEstate #FirstTimeBuyer #LagosMortgage #NairobiHomes #AccraProperties #RealEstateFinance #PropertyInvestment #MortgageTips

## Image Recommendation
Photo of documents, calculator, and a pen on a desk — or a screenshot of a mortgage calculator result. Alternatively, a photo of you wearing professional attire, holding a tablet.

## Story Idea
**"Mortgage Myth Buster"** — 5-slide story. Each slide has a common myth (e.g., "I need 50% deposit"). Swipe up to reveal the truth. End with "DM me if you have questions about your situation."

## Reel Idea
**45-sec "3 Mortgage Options You Didn't Know Existed"** — Direct-to-camera. Hold up 3 fingers. Option 1: Rent-to-own. Option 2: Developer financing. Option 3: Cooperative mortgages. Brisk pace, friendly tone. Caption text on screen for each option.
