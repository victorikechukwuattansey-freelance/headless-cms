# Video 7: Using AI for Property Listings

> **Length:** 20–30 minutes
> **Level:** All levels
> **Prerequisites:** Free ChatGPT account (chat.openai.com), Canva account

---

## Learning Objectives

By the end of this video, the viewer will be able to:

1. Use ChatGPT to write property listings, descriptions, and captions
2. Use AI to generate social media posts and content ideas
3. Use Canva AI (Magic Studio) to edit images and create graphics
4. Use AI tools to translate and localize content for different audiences
5. Build a content creation workflow that saves 10+ hours per week

---

## Script Outline

### Hook (0:00–0:30)

"What if you could write a week of captions in 5 minutes? What if you could remove a background from a property photo in one click? AI tools can do this right now, and they're free."

### Introduction (0:30–1:30)

- AI is not replacing agents — it's replacing agents who don't use AI
- The tools we'll cover: ChatGPT, Canva AI, and others
- Nothing is technical — if you can type, you can use AI

### Main Content

#### Part 1: Writing Property Listings with ChatGPT (1:30–8:00)

1. **The perfect prompt formula:**
   - Role: "You are a luxury real estate copywriter"
   - Context: "Write a listing for a 3-bedroom duplex in Lekki Phase 1"
   - Details: "1,500 sqm, modern kitchen, rooftop terrace, 3 car parking"
   - Target audience: "Professionals aged 30–45, first-time buyers in Lagos"
   - Format: "200 words, include 5 key features as bullet points"
2. **Example prompt (copy-paste):**
   ```
   You are a luxury real estate copywriter specializing in Nigerian properties.
   Write a listing for a 3-bedroom duplex in Lekki Phase 1.
   Features: 1,500 sqm floor area, modern fitted kitchen, imported Italian tiles,
   rooftop terrace with lagoon view, 3-car parking, 24-hour security, generator + inverter.
   Target audience: young professionals aged 30–45 buying their first home in Lagos.
   Format: 200 words with a bold headline, 3 body paragraphs, and 5 bulleted features.
   End with a call to action encouraging a viewing.
   ```
3. **Refining AI output:**
   - "Make it shorter" / "Make it more emotional" / "Add luxury adjectives"
   - "Rewrite for Instagram caption (max 150 characters)"
   - "Translate this to Nigerian Pidgin English"
4. **Screen recording:** Write a full property listing in 2 minutes with ChatGPT

#### Part 2: Social Media Captions & Content Ideas (8:00–13:00)

1. **Generate 30 days of post ideas:**
   ```
   You are a real estate social media manager. Generate 30 content ideas
   for a real estate agent in Lagos. Include a mix of: property tips,
   market insights, listings, behind-the-scenes, and client stories.
   Format as a table with: Day, Theme, Post Topic, Caption Draft, Hashtags.
   ```
2. **Use AI for content repurposing:**
   - Paste a property listing → "Turn this into 3 Instagram stories"
   - Paste a blog post → "Rewrite this as a 60-second TikTok script"
   - Paste a testimonial → "Create a 5-post testimonial series"
3. **Captions in your brand voice:**
   - Tell ChatGPT: "Rewrite this caption in a [friendly/professional/luxury] tone"
   - Save your "brand voice" prompt and reuse it

#### Part 3: Canva AI — Magic Studio (13:00–18:00)

1. **Magic Eraser:** Remove unwanted objects from property photos
   - Example: Remove a trash bin, car, or person from a listing photo
2. **Magic Expand:** Extend or reframe images
3. **Background Remover:** One-click remove background (Canva Pro)
   - Perfect for: Creating clean property cutouts for carousel ads
4. **Magic Write:** AI copywriting inside Canva
   - Select text box → Magic Write → "Write a caption about this luxury apartment"
5. **Text to Image:** Generate custom images
   - "A modern living room with African art, warm lighting, beige sofa"
   - Use for: blog headers, social media posts when you don't have a photo
6. **Screen recording:** Magic Eraser a property photo + Magic Write a caption

#### Part 4: Advanced AI Workflows (18:00–23:00)

1. **AI photo enhancement:**
   - Remini (app): Enhance blurry property photos
   - Palette.fm: Colorize old or faded photos
   - Clipdrop: Remove/replace backgrounds
2. **AI video tools:**
   - Opus Clip: Turn long property tour videos into short clips
   - CapCut AI: Auto-captions, AI editing
3. **AI voiceover:**
   - ElevenLabs: Generate professional voiceover for property videos
   - Use case: "Read this property description in a calm, professional voice"
4. **Workflow automation:**
   - ChatGPT → writes 5 captions
   - Canva AI → generates 5 matching graphics
   - Meta Business Suite → schedules all 5 posts
   - Total time: 30 minutes for a week of content

#### Part 5: Ethics & Best Practices (23:00–27:00)

1. **Always review AI output** — never post AI content unedited
2. **Add your personal touch** — AI lacks local market nuance
3. **Disclose AI use** on client projects only if required
4. **Don't use AI for:**
   - Legal documents (contracts, agreements)
   - Client communication without review
   - Price recommendations (use market data, not AI guesses)
5. **AI is an assistant, not a replacement** — you are still the expert

### Key Takeaways (27:00–30:00)

1. ChatGPT can write a property listing in 30 seconds — but you must edit it
2. Canva AI can fix photos that would otherwise be unusable
3. AI tools save 10+ hours per week in content creation
4. The best AI prompt is specific: role + context + format
5. AI enhances your expertise — it doesn't replace your judgment

### CTA

- "Write your next property listing with ChatGPT using the prompt template"
- Next video: "Turning Leads into Clients"

---

## Practical Exercise

**Assignment:** Use ChatGPT to write 5 property listings for your current listings. Use Canva Magic Eraser on one property photo. Generate 7 days of social media captions with AI. Schedule them.

**Submission:** The ChatGPT prompt you used + screenshots of Canva AI edits + the 7 captions

---

## AI Tools Quick Reference

| Tool | Purpose | Price |
|---|---|---|
| ChatGPT | Writing, captions, ideas | Free / $20 Pro |
| Canva Magic Studio | Image editing, AI writing | Free / Pro ($12/mo) |
| Remini | Photo enhancement | Free / Paid |
| Opus Clip | Video to short clips | Free / Paid |
| ElevenLabs | AI voiceover | Free / $5/mo |
| Clipdrop | Background removal | Free / Paid |
| CapCut | Video editing + AI | Free |
| Palette.fm | Photo colorization | Free / Paid |

## Resource Links

- ChatGPT: https://chat.openai.com
- Canva AI: https://www.canva.com/magic-studio
- Remini: https://remini.ai
- Opus Clip: https://opus.pro
- ElevenLabs: https://elevenlabs.io
- Clipdrop: https://clipdrop.co
