FOLDER 1 � Mockups & Visuals
Use these images in your promotional content (social media posts, blog articles, YouTube thumbnails, etc.)

FILES:
- cover-square.png (1080x1080) � Main product cover, use as primary promotional image
- cover-gumroad.png (2048x1152) � Alternate cover for Gumroad/blog headers
- preview-flyer-grid.png (1080x1080) � Shows all 8 property flyer designs
- preview-mockups.png (1080x1080) � Phone mockups showcasing social media templates
- preview-modules.png (1080x1080) � All 10 product modules in a grid

Tip: cover-square.png works best for Instagram posts and Facebook ad creatives.
